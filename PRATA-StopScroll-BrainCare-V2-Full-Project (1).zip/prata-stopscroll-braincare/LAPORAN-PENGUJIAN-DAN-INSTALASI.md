# Laporan Pengujian, Arsitektur Pembatasan & Panduan Build/Instalasi
**Aplikasi**: PRATA StopScroll BrainCare V2  
**Package Name**: `com.prata.stopscroll.braincare` (Debug: `com.prata.stopscroll.braincare.debug`)  
**Versi**: `2.0.0` (`versionCode = 2`)  
**Target SDK / Min SDK**: `compileSdk = 35`, `targetSdk = 35`, `minSdk = 26` (Android 8.0+)

## 1. Penjelasan Teknis: Tiga Mekanisme Pembatasan di Android

Sesuai kebijakan keamanan sistem operasi Android, aplikasi pengguna biasa tidak diizinkan memanggil *force-stop* level kernel (`ActivityManager.forceStopPackage`) atau mematikan proses aplikasi pihak ketiga secara paksa tanpa akses *root* atau *Device Owner*. Oleh karena itu, **PRATA StopScroll BrainCare V2** mengimplementasikan pembatasan keras yang sah, stabil, dan aman melalui kombinasi dua mekanisme resmi Android:

| Mekanisme | Cara Kerja di PRATA V2 | Kelebihan & Batasan |
| :--- | :--- | :--- |
| **1. Pengalihan ke Home Screen (`GLOBAL_ACTION_HOME`)** | Saat jumlah konten pendek mencapai batas harian/per-aplikasi pada **Mode Blokir** atau **Mode Ketat**, `ScrollAccessibilityService` memanggil `performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)` secara otomatis untuk mengeluarkan pengguna dari aplikasi target ke layar utama Android. | Menghentikan pemutaran video dan *autoplay* secara instan. Dilengkapi *cooldown* anti-loop `2500 ms` (`AUTO_EXIT_COOLDOWN_MS`) dan daftar pengecualian paket darurat/sistem (`com.android.settings`, `com.google.android.dialer`, `com.android.emergency`, dll.). |
| **2. Perisai Overlay Layar Penuh (`TYPE_ACCESSIBILITY_OVERLAY`)** | `FloatingOverlayManager` menampilkan jendela pembatas interaktif di atas aplikasi target ketika batas tercapai atau ketika `GLOBAL_ACTION_HOME` dibatasi oleh kustomisasi ROM perangkat. | Menutupi feed video pendek agar tidak dapat digulir lebih lanjut dan menyediakan tombol **Keluar dari Aplikasi Sekarang**, **Buka Dashboard PRATA**, serta opsi tunda sadar 5 detik (khusus **Mode Blokir**). |
| **3. Menghentikan Proses di Level Sistem (`forceStopPackage`)** | **Tidak digunakan** karena memerlukan *permission* `FORCE_STOP_PACKAGES` yang hanya diberikan kepada aplikasi sistem/signature OEM. | PRATA tidak menggunakan API tersembunyi, *exploit*, atau *root* agar aplikasi tetap aman, stabil, dan patuh terhadap kebijakan keamanan Android. |

## 2. Tiga Mode Pembatasan yang Tersedia

1. **Mode Pengingat (`REMINDER`)**:
   - Menampilkan peringatan visual pada *Floating Counter* dan mengirim notifikasi saat ambang peringatan (mis. 80%) dan batas maksimum (100%) tercapai tanpa menutup aplikasi.
2. **Mode Blokir (`FOCUS`)**:
   - Saat batas tercapai, menyimpan statistik ke Room, mengubah status ke `LIMIT_REACHED` → `BLOCKING_ACTIVE`, menampilkan layar pembatas pada aplikasi target, dan mengarahkan pengguna keluar ke *Home screen* (`GLOBAL_ACTION_HOME`). Pengguna masih dapat menunda selama 5 menit setelah melewati hitungan mundur pernapasan sadar 5 detik.
3. **Mode Ketat (`STRICT`)**:
   - Meminta persetujuan eksplisit dari pengguna sebelum diaktifkan.
   - Saat batas tercapai, mengarahkan pengguna keluar dari aplikasi target (`GLOBAL_ACTION_HOME`), menonaktifkan opsi tunda cepat pada overlay, dan setiap kali pengguna mencoba membuka kembali aplikasi target selama batas masih aktif, PRATA langsung mempertahankan pembatas serta mengarahkan kembali ke *Home screen* (dengan jeda teknis 2,5 detik agar tidak terjadi kedipan layar).
   - **Cara Menonaktifkan Mode Ketat**: Buka aplikasi **PRATA StopScroll BrainCare → Pengaturan → Sistem Batas & Mode Pembatasan → pilih Mode Pengingat/Mode Blokir**, atau matikan layanan melalui **Pengaturan Android → Aksesibilitas → PRATA StopScroll**.

## 3. Matriks Hasil Pengujian V2

| Komponen / Skenario Uji | Kategori Hasil | Detail Verifikasi |
| :--- | :--- | :--- |
| **Deduplikasi Konten & Normalisasi Signature** | **LULUS** | Diuji pada `DeduplicationTest` & `DetectionAccuracyGroundTruthTest`: perubahan angka *like* (`45.1K` → `45.2K`), *scroll* berulang dalam `<850 ms`, dan *scroll* balik ke video sebelumnya tidak menambah hitungan. |
| **Akurasi Multi-Aplikasi (Ground-Truth 28 Event)** | **LULUS** | `TP = 14`, `TN = 14`, `FP = 0`, `FN = 0` (`Precision = 100%`, `Recall = 100%`) pada simulasi sinyal UI TikTok, Instagram Reels, YouTube Shorts, Facebook Reels, Snapchat Spotlight, komentar, dan WhatsApp. |
| **Limit Harian, Per-Aplikasi & Status `LIMIT_REACHED`** | **LULUS** | Diuji pada `TrackingStateMachineAndOverlayTest`: peringatan aktif pada 80% dan `LIMIT_REACHED` / `BLOCKING_ACTIVE` aktif tepat pada 100%. |
| **Mekanisme Keluar Otomatis (`GLOBAL_ACTION_HOME`) & Anti-Loop Cooldown** | **LULUS** | Diuji pada `TrackingStateMachineAndOverlayTest` & `PrataJvmTestRunner`: `shouldPerformGlobalHomeExit` bernilai `true` saat batas tercapai, menahan panggilan ulang dalam jendela `2500 ms`, dan tidak pernah memblokir `com.android.settings` atau aplikasi telepon/darurat. |
| **Reset Harian Sadar Zona Waktu & Proteksi Jam Sistem** | **LULUS** | Diuji pada `DateUtilsTest`: mendukung `ZoneId.systemDefault()` dan mendeteksi pemunduran jam sistem (`isSystemClockTamperedOrRolledBack`). |
| **Pencabutan Izin & Pemulihan State** | **LULUS** | Saat izin aksesibilitas dicabut, state langsung beralih ke `PERMISSION_MISSING` dan seluruh overlay ditutup. |
| **Validitas Seluruh Aset Visual VectorDrawable & XML** | **LULUS** | 30 file XML (`AndroidManifest.xml`, `res/drawable/*.xml`, `res/values/*.xml`, `res/xml/*.xml`) dan 82 file Kotlin terverifikasi 100% bebas referensi rusak. |
| **Build Binary APK melalui Gradle di Sandbox Lokal** | **BELUM DIUJI DI SANDBOX** | Sandbox VM tidak memiliki koneksi internet keluar (`services.gradle.org` diblokir) dan tidak memiliki paket `kotlinc` / `platforms;android-35`. Workflow `.github/workflows/build.yml` telah disiapkan penuh. |
| **Interaksi Fisik Overlay & `GLOBAL_ACTION_HOME` di Atas Aplikasi Pihak Ketiga Nyata** | **MEMERLUKAN PERANGKAT FISIK** | Pengujian perilaku visual `TYPE_ACCESSIBILITY_OVERLAY` dan respons `GLOBAL_ACTION_HOME` pada berbagai ROM OEM (OneUI, HyperOS, ColorOS) memerlukan perangkat Android fisik. |

## 4. Instruksi Build APK (`prata-stopscroll-braincare-debug.apk`) & Instalasi

### Opsi A — Build Otomatis via GitHub Actions (Tanpa Instal SDK Lokal)
1. Ekstrak file `PRATA-StopScroll-BrainCare-V2-Full-Project.zip`.
2. Masuk ke folder `prata-stopscroll-braincare` (sudah memiliki commit Git V2 siap pakai) dan *push* ke repository GitHub Anda:
   ```bash
   cd prata-stopscroll-braincare
   git remote add origin https://github.com/<USERNAME_ANDA>/<NAMA_REPO_ANDA>.git
   git push -u origin main
   ```
3. Buka tab **Actions** di repository GitHub Anda, pilih workflow **Build PRATA StopScroll BrainCare V2 APK**, lalu tunggu hingga berstatus **Success** (atau klik **Run workflow**).
4. Unduh file **`PRATA-StopScroll-BrainCare-APK`** pada bagian **Artifacts** untuk mendapatkan `prata-stopscroll-braincare-debug.apk`.

### Opsi B — Build Lokal via Android Studio / Terminal
1. Pastikan **JDK 17** dan **Android SDK Platform 35** terinstal.
2. Jalankan perintah berikut di root folder `prata-stopscroll-braincare`:
   ```bash
   ./gradlew testDebugUnitTest assembleDebug
   ```
3. Ambil file APK yang dihasilkan di:
   `app/build/outputs/apk/debug/prata-stopscroll-braincare-debug.apk`

### Panduan Instalasi di Perangkat Android (Android 8.0 – Android 15)
1. Pindahkan `prata-stopscroll-braincare-debug.apk` ke perangkat Android Anda dan ketuk untuk menginstal (atau jalankan `adb install -r app/build/outputs/apk/debug/prata-stopscroll-braincare-debug.apk`).
2. Pada **Android 13 / 14 / 15**, jika layanan Aksesibilitas menampilkan pesan *"Pengaturan Terbatas"* (*Restricted Settings*):
   - Buka **Pengaturan HP → Aplikasi → PRATA StopScroll BrainCare**.
   - Ketuk menu **titik tiga (⋮)** di pojok kanan atas → pilih **Izinkan pengaturan terbatas** (*Allow restricted settings*).
3. Buka **Pengaturan HP → Aksesibilitas → Aplikasi Terinstal → PRATA StopScroll BrainCare**, lalu aktifkan layanan agar deteksi konten pendek, *Floating Counter*, dan pembatasan otomatis dapat bekerja.
