package com.prata.stopscroll.braincare

import com.prata.stopscroll.braincare.util.Constants
import org.junit.Assert.*
import org.junit.Test

class DeduplicationTest {

    @Test
    fun targetAppRecognition_identifiesCorrectApps() {
        assertTrue(Constants.TARGET_APPS.containsKey("com.instagram.android"))
        assertTrue(Constants.TARGET_APPS.containsKey("com.google.android.youtube"))
        assertTrue(Constants.TARGET_APPS.containsKey("com.zhiliaoapp.musically"))
        assertTrue(Constants.TARGET_APPS.containsKey("com.facebook.katana"))
        assertTrue(Constants.TARGET_APPS.containsKey("com.snapchat.android"))
    }

    @Test
    fun nonTargetApp_isRejected() {
        assertFalse(Constants.TARGET_APPS.containsKey("com.whatsapp"))
        assertFalse(Constants.TARGET_APPS.containsKey("com.android.settings"))
        assertFalse(Constants.TARGET_APPS.containsKey("com.spotify.music"))
    }

    @Test
    fun deduplicationCooldown_enforcesMinimumInterval() {
        val cooldown = Constants.DEDUP_COOLDOWN_MS
        assertEquals(850L, cooldown)

        val firstEventTime = 1000L
        val rapidSecondEventTime = 1400L // 400ms delta (within cooldown)
        val validThirdEventTime = 1900L // 900ms delta (after cooldown)

        val isRapidBlocked = (rapidSecondEventTime - firstEventTime) < cooldown
        val isValidAllowed = (validThirdEventTime - firstEventTime) >= cooldown

        assertTrue(isRapidBlocked)
        assertTrue(isValidAllowed)
    }

    @Test
    fun contentHash_detectsIdenticalNodes() {
        val contentA = "Reel Creator @user123 Caption Awesome Video"
        val contentB = "Reel Creator @user123 Caption Awesome Video"
        val contentC = "Reel Creator @different Caption New Video"

        val hashA = contentA.hashCode()
        val hashB = contentB.hashCode()
        val hashC = contentC.hashCode()

        assertEquals(hashA, hashB)
        assertNotEquals(hashA, hashC)
    }
}
