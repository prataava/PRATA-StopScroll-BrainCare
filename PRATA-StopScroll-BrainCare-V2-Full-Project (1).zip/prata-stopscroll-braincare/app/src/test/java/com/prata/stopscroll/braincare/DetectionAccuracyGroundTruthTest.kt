package com.prata.stopscroll.braincare

import com.prata.stopscroll.braincare.domain.detection.AccessibilitySignalInput
import com.prata.stopscroll.braincare.domain.detection.ShortContentDetectionEngine
import com.prata.stopscroll.braincare.domain.state.ContentDeduplicationState
import com.prata.stopscroll.braincare.domain.state.DetectionConfidence
import com.prata.stopscroll.braincare.util.Constants
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * Ground-truth evaluation test suite for ShortContentDetectionEngine (Requirements C & L).
 * Measures True Positives, False Positives, True Negatives, False Negatives, Precision, and Recall
 * across realistic multi-app event streams.
 */
class DetectionAccuracyGroundTruthTest {

    private lateinit var engine: ShortContentDetectionEngine

    data class LabeledEventCase(
        val label: String,
        val signal: AccessibilitySignalInput,
        val expectedShouldCount: Boolean
    )

    @Before
    fun setUp() {
        engine = ShortContentDetectionEngine()
    }

    @Test
    fun oneContentTransition_producesExactlyOneCount_andIgnoresDuplicateAnimations() {
        // 1. Open TikTok short-form feed (Window state change -> baseline established, count = 0)
        val openEvent = AccessibilitySignalInput(
            packageName = Constants.PKG_TIKTOK,
            eventType = 32, // TYPE_WINDOW_STATE_CHANGED
            timestampMs = 1_000L,
            className = "androidx.viewpager.widget.ViewPager",
            visibleViewIds = listOf("com.zhiliaoapp.musically:id/viewpager", "com.zhiliaoapp.musically:id/video_player"),
            visibleTexts = listOf("For You", "@creator_one", "Belajar Kotlin Android #coding", "12.4K"),
            hasVerticalPagerNode = true
        )
        val r0 = engine.evaluateSignal(openEvent, trackingEnabled = true)
        assertFalse("Initial window open should establish baseline, not increment scroll count", r0.shouldIncrementCount)
        assertTrue("Should detect short-form context", r0.isShortFormContext)

        // 2. User scrolls to next TikTok video (Verified transition -> count +1)
        val scrollNext = AccessibilitySignalInput(
            packageName = Constants.PKG_TIKTOK,
            eventType = 4096, // TYPE_VIEW_SCROLLED
            timestampMs = 3_500L,
            className = "androidx.viewpager.widget.ViewPager",
            scrollDeltaY = 1400,
            toIndex = 1,
            visibleViewIds = listOf("com.zhiliaoapp.musically:id/viewpager", "com.zhiliaoapp.musically:id/video_player"),
            visibleTexts = listOf("For You", "@creator_two", "Tips fokus kerja tanpa distraksi", "45.1K"),
            hasVerticalPagerNode = true
        )
        val r1 = engine.evaluateSignal(scrollNext, trackingEnabled = true)
        assertTrue("Valid vertical transition to new video must count once", r1.shouldIncrementCount)
        assertEquals(DetectionConfidence.HIGH_CONFIDENCE, r1.confidence)

        // 3. Repeated scroll event / like animation on the SAME video (1200ms later, like count changes 45.1K -> 45.2K)
        val likeAnimationEvent = scrollNext.copy(
            timestampMs = 5_000L,
            visibleTexts = listOf("For You", "@creator_two", "Tips fokus kerja tanpa distraksi", "45.2K")
        )
        val r2 = engine.evaluateSignal(likeAnimationEvent, trackingEnabled = true)
        assertFalse("Like count animation on same video must NOT increment count", r2.shouldIncrementCount)
        assertEquals(ContentDeduplicationState.CONTENT_COUNTED, r2.deduplicationState)
    }

    @Test
    fun openingCommentsOrMenus_doesNotIncrementCount() {
        // Establish Instagram Reels context
        val reelScroll1 = AccessibilitySignalInput(
            packageName = Constants.PKG_INSTAGRAM,
            eventType = 4096,
            timestampMs = 10_000L,
            scrollDeltaY = 1200,
            toIndex = 1,
            visibleViewIds = listOf("com.instagram.android:id/clips_viewer_view_pager", "com.instagram.android:id/clips_video_container"),
            visibleTexts = listOf("Reels", "@insta_author", "Morning workout routine"),
            hasVerticalPagerNode = true
        )
        val firstRes = engine.evaluateSignal(reelScroll1, trackingEnabled = true)
        assertTrue(firstRes.shouldIncrementCount)

        // User opens comments sheet and scrolls through comments
        val commentScroll = AccessibilitySignalInput(
            packageName = Constants.PKG_INSTAGRAM,
            eventType = 4096,
            timestampMs = 12_500L,
            scrollDeltaY = 900,
            toIndex = 5,
            visibleViewIds = listOf(
                "com.instagram.android:id/clips_viewer_view_pager",
                "com.instagram.android:id/layout_comment_thread",
                "com.instagram.android:id/row_comment_textview"
            ),
            visibleTexts = listOf("Komentar", "@commenter_1", "Keren banget videonya!", "Tambahkan komentar..."),
            hasVerticalPagerNode = true
        )
        val commentRes = engine.evaluateSignal(commentScroll, trackingEnabled = true)
        assertFalse("Scrolling inside comment drawer must NOT increment short content count", commentRes.shouldIncrementCount)
        assertTrue("Comment overlay flag must be true", commentRes.isCommentOrOverlayOpen)
        assertEquals(ContentDeduplicationState.UI_OVERLAY_OR_COMMENT_OPEN, commentRes.deduplicationState)
    }

    @Test
    fun groundTruthDataset_precisionAndRecallEvaluation() {
        val dataset = listOf(
            // Case 1: TikTok initial window open -> false (baseline)
            LabeledEventCase(
                "TikTok open baseline",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_TIKTOK,
                    eventType = 32,
                    timestampMs = 1000L,
                    visibleViewIds = listOf("viewpager", "video_player"),
                    visibleTexts = listOf("For You", "@user_a", "Video pertama hari ini"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = false
            ),
            // Case 2: TikTok scroll to Video 2 -> true
            LabeledEventCase(
                "TikTok scroll to video 2",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_TIKTOK,
                    eventType = 4096,
                    timestampMs = 3000L,
                    scrollDeltaY = 1200,
                    toIndex = 1,
                    visibleViewIds = listOf("viewpager", "video_player"),
                    visibleTexts = listOf("For You", "@user_b", "Resep kopi susu gula aren"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = true
            ),
            // Case 3: Rapid bounce within 400ms cooldown -> false
            LabeledEventCase(
                "TikTok rapid duplicate bounce",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_TIKTOK,
                    eventType = 4096,
                    timestampMs = 3400L,
                    scrollDeltaY = 400,
                    toIndex = 1,
                    visibleViewIds = listOf("viewpager", "video_player"),
                    visibleTexts = listOf("For You", "@user_b", "Resep kopi susu gula aren"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = false
            ),
            // Case 4: TikTok comment drawer scroll -> false
            LabeledEventCase(
                "TikTok comment scroll",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_TIKTOK,
                    eventType = 4096,
                    timestampMs = 5500L,
                    scrollDeltaY = 800,
                    toIndex = 4,
                    visibleViewIds = listOf("viewpager", "comment_list"),
                    visibleTexts = listOf("Komentar", "@netizen1", "Setuju banget kak"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = false
            ),
            // Case 5: TikTok scroll to Video 3 -> true
            LabeledEventCase(
                "TikTok scroll to video 3",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_TIKTOK,
                    eventType = 4096,
                    timestampMs = 8000L,
                    scrollDeltaY = 1350,
                    toIndex = 2,
                    visibleViewIds = listOf("viewpager", "video_player"),
                    visibleTexts = listOf("For You", "@user_c", "Review laptop programming 2026"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = true
            ),
            // Case 6: Switch to WhatsApp -> false
            LabeledEventCase(
                "Switch to WhatsApp chat scroll",
                AccessibilitySignalInput(
                    packageName = "com.whatsapp",
                    eventType = 4096,
                    timestampMs = 11000L,
                    scrollDeltaY = 1000,
                    visibleViewIds = listOf("conversation_list"),
                    visibleTexts = listOf("Budi", "Halo apa kabar?")
                ),
                expectedShouldCount = false
            ),
            // Case 7: YouTube Home long-form browse -> false
            LabeledEventCase(
                "YouTube Home browse feed",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_YOUTUBE,
                    eventType = 4096,
                    timestampMs = 14000L,
                    scrollDeltaY = 900,
                    visibleViewIds = listOf("browse_feed_recycler"),
                    visibleTexts = listOf("Beranda", "Podcast 2 Jam Full")
                ),
                expectedShouldCount = false
            ),
            // Case 8: YouTube Shorts Video 1 scroll -> true
            LabeledEventCase(
                "YouTube Shorts video 1",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_YOUTUBE,
                    eventType = 4096,
                    timestampMs = 17000L,
                    scrollDeltaY = 1400,
                    toIndex = 1,
                    visibleViewIds = listOf("reel_recycler", "shorts_player"),
                    visibleTexts = listOf("Shorts", "@yt_creator_1", "Eksperimen sains singkat"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = true
            ),
            // Case 9: YouTube Shorts Video 2 scroll -> true
            LabeledEventCase(
                "YouTube Shorts video 2",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_YOUTUBE,
                    eventType = 4096,
                    timestampMs = 20000L,
                    scrollDeltaY = 1400,
                    toIndex = 2,
                    visibleViewIds = listOf("reel_recycler", "shorts_player"),
                    visibleTexts = listOf("Shorts", "@yt_creator_2", "Tips produktivitas pagi"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = true
            ),
            // Case 10: Instagram Reels Video 1 scroll -> true
            LabeledEventCase(
                "Instagram Reels video 1",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_INSTAGRAM,
                    eventType = 4096,
                    timestampMs = 24000L,
                    scrollDeltaY = 1300,
                    toIndex = 1,
                    visibleViewIds = listOf("clips_viewer_view_pager", "clips_video_container"),
                    visibleTexts = listOf("Reels", "@ig_creator_1", "cinematic travel reel"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = true
            ),
            // Case 11: Facebook Reels Video 1 scroll -> true
            LabeledEventCase(
                "Facebook Reels video 1",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_FACEBOOK,
                    eventType = 4096,
                    timestampMs = 28000L,
                    scrollDeltaY = 1300,
                    toIndex = 1,
                    visibleViewIds = listOf("fb_shorts_viewer", "reels_viewer"),
                    visibleTexts = listOf("Reels", "@fb_creator_1", "kuliner malam jakarta"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = true
            ),
            // Case 12: Snapchat Spotlight Video 1 scroll -> true
            LabeledEventCase(
                "Snapchat Spotlight video 1",
                AccessibilitySignalInput(
                    packageName = Constants.PKG_SNAPCHAT,
                    eventType = 4096,
                    timestampMs = 32000L,
                    scrollDeltaY = 1300,
                    toIndex = 1,
                    visibleViewIds = listOf("spotlight_player", "spotlight_view_pager"),
                    visibleTexts = listOf("Spotlight", "@snap_creator_1", "funny cat jump"),
                    hasVerticalPagerNode = true
                ),
                expectedShouldCount = true
            )
        )

        var tp = 0
        var fp = 0
        var tn = 0
        var fn = 0

        for (case in dataset) {
            val result = engine.evaluateSignal(case.signal, trackingEnabled = true)
            if (case.expectedShouldCount && result.shouldIncrementCount) tp++
            else if (!case.expectedShouldCount && result.shouldIncrementCount) fp++
            else if (!case.expectedShouldCount && !result.shouldIncrementCount) tn++
            else if (case.expectedShouldCount && !result.shouldIncrementCount) fn++
        }

        val precision = if (tp + fp > 0) tp.toDouble() / (tp + fp) else 0.0
        val recall = if (tp + fn > 0) tp.toDouble() / (tp + fn) else 0.0

        assertEquals("False positives must be 0", 0, fp)
        assertEquals("False negatives must be 0", 0, fn)
        assertEquals(7, tp)
        assertEquals(5, tn)
        assertEquals(1.0, precision, 0.001)
        assertEquals(1.0, recall, 0.001)
    }
}
