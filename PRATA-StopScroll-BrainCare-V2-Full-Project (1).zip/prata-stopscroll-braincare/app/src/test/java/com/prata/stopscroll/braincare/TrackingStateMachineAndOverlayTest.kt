package com.prata.stopscroll.braincare

import com.prata.stopscroll.braincare.domain.limit.FocusScheduleConfig
import com.prata.stopscroll.braincare.domain.limit.HardLimitManager
import com.prata.stopscroll.braincare.domain.state.ContentDeduplicationState
import com.prata.stopscroll.braincare.domain.state.DetectionConfidence
import com.prata.stopscroll.braincare.domain.state.LimitEnforcementPolicy
import com.prata.stopscroll.braincare.domain.state.SystemTrackingState
import com.prata.stopscroll.braincare.domain.state.TrackingStateMachine
import com.prata.stopscroll.braincare.util.Constants
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * Unit tests verifying TrackingStateMachine transitions, Floating Counter visibility rules,
 * Hard Scroll Limit enforcement policies (Mode Pengingat, Mode Blokir, Mode Ketat),
 * Automatic Force-Exit (`GLOBAL_ACTION_HOME`) with anti-loop cooldown, emergency/system exemptions,
 * and permission revocation handling (Sections 3, 4, 6).
 */
class TrackingStateMachineAndOverlayTest {

    private lateinit var stateMachine: TrackingStateMachine
    private lateinit var limitManager: HardLimitManager

    @Before
    fun setUp() {
        stateMachine = TrackingStateMachine()
        limitManager = HardLimitManager()
        limitManager.resetAutoExitCooldown()
        stateMachine.onServiceOrPermissionStateChanged(
            isAccessibilityGranted = true,
            isOverlayGranted = true,
            isServiceRunning = true,
            isTrackingEnabled = true
        )
        stateMachine.syncLimitsAndCounts(
            todayShortCount = 20,
            dailyLimit = 100,
            warningThresholdPercent = 0.8f,
            enforcementPolicy = LimitEnforcementPolicy.FOCUS
        )
    }

    @Test
    fun floatingCounter_showsInTargetShortForm_hidesInNonTarget_andRestoresOnReturn() {
        stateMachine.onForegroundAppChanged(
            packageName = Constants.PKG_TIKTOK,
            isTargetApp = true,
            appName = "TikTok"
        )
        assertEquals(SystemTrackingState.TARGET_APP_ACTIVE, stateMachine.snapshot.value.systemState)
        assertFalse(stateMachine.snapshot.value.isFloatingOverlayVisible)

        stateMachine.onShortContentContextEvaluated(
            isShortFormContext = true,
            isCommentOrMenuOpen = false,
            confidence = DetectionConfidence.HIGH_CONFIDENCE,
            dedupState = ContentDeduplicationState.ACTIVE_CONTENT_IDENTIFIED
        )
        assertTrue(stateMachine.snapshot.value.isFloatingOverlayVisible)

        stateMachine.onForegroundAppChanged(
            packageName = "com.whatsapp",
            isTargetApp = false,
            appName = null
        )
        assertEquals(SystemTrackingState.TARGET_APP_INACTIVE, stateMachine.snapshot.value.systemState)
        assertFalse(stateMachine.snapshot.value.isFloatingOverlayVisible)

        stateMachine.onForegroundAppChanged(
            packageName = Constants.PKG_TIKTOK,
            isTargetApp = true,
            appName = "TikTok"
        )
        stateMachine.onShortContentContextEvaluated(
            isShortFormContext = true,
            isCommentOrMenuOpen = false,
            confidence = DetectionConfidence.HIGH_CONFIDENCE,
            dedupState = ContentDeduplicationState.ACTIVE_CONTENT_IDENTIFIED
        )
        assertTrue(stateMachine.snapshot.value.isFloatingOverlayVisible)
    }

    @Test
    fun limitWarningAndHardLimitBlocking_triggerAtExactThresholds_andPersistOnReopen() {
        stateMachine.onForegroundAppChanged(Constants.PKG_INSTAGRAM, true, "Instagram Reels")
        stateMachine.onShortContentContextEvaluated(
            isShortFormContext = true,
            isCommentOrMenuOpen = false,
            confidence = DetectionConfidence.HIGH_CONFIDENCE,
            dedupState = ContentDeduplicationState.CONTENT_COUNTED
        )

        // Warning at 80 / 100
        stateMachine.onVerifiedContentCounted(
            newTodayCount = 80,
            newAppCount = 30,
            contentSignature = "ig#reel80",
            timestampMs = 5000L
        )
        assertEquals(SystemTrackingState.LIMIT_WARNING, stateMachine.snapshot.value.systemState)
        assertFalse(stateMachine.snapshot.value.isBlockingOverlayVisible)

        // Limit reached at 100 / 100 in Mode Blokir (FOCUS) -> BLOCKING_ACTIVE
        stateMachine.onVerifiedContentCounted(
            newTodayCount = 100,
            newAppCount = 50,
            contentSignature = "ig#reel100",
            timestampMs = 8000L
        )
        assertEquals(SystemTrackingState.BLOCKING_ACTIVE, stateMachine.snapshot.value.systemState)
        assertTrue(stateMachine.snapshot.value.isBlockingOverlayVisible)

        // Switch away to Home / WhatsApp -> hides overlay while outside target app
        stateMachine.onForegroundAppChanged("com.whatsapp", false, null)
        assertFalse(stateMachine.snapshot.value.isBlockingOverlayVisible)

        // Reopen target app in Mode Ketat (STRICT) -> immediately activates BLOCKING_ACTIVE even before scrolling
        stateMachine.syncLimitsAndCounts(
            todayShortCount = 100,
            dailyLimit = 100,
            enforcementPolicy = LimitEnforcementPolicy.STRICT
        )
        stateMachine.onForegroundAppChanged(Constants.PKG_INSTAGRAM, true, "Instagram Reels")
        assertEquals(SystemTrackingState.BLOCKING_ACTIVE, stateMachine.snapshot.value.systemState)
        assertTrue(stateMachine.snapshot.value.isBlockingOverlayVisible)
    }

    @Test
    fun autoForceExitToHome_triggersWhenLimitReached_enforcesCooldown_andProtectsEmergencyApps() {
        val scheduleOff = FocusScheduleConfig(enabled = false)

        // 1. Limit reached (100/100) in Mode Blokir (FOCUS) at t = 10_000ms -> shouldPerformGlobalHomeExit = true
        val decision1 = limitManager.evaluateLimits(
            todayTotalCount = 100,
            totalDailyLimit = 100,
            activePackage = Constants.PKG_TIKTOK,
            activeAppName = "TikTok",
            activeAppTodayCount = 60,
            perAppLimits = emptyMap(),
            todayUsageMs = 1_200_000L,
            dailyDurationLimitMinutes = 0,
            warningThresholdPercent = 0.8f,
            policy = LimitEnforcementPolicy.FOCUS,
            focusSchedule = scheduleOff,
            warningAlreadyShown = true,
            limitAlreadyReached = false,
            userOverrodeToday = false,
            snoozeUntilTimestampMs = 0L,
            autoExitConsentGranted = true,
            isAccessibilityServiceActive = true,
            isTargetInForeground = true,
            nowTimestampMs = 10_000L
        )
        assertTrue(decision1.isLimitReached)
        assertTrue(decision1.shouldShowBlockingOverlay)
        assertTrue("First limit reach must trigger automatic GLOBAL_ACTION_HOME", decision1.shouldPerformGlobalHomeExit)

        // 2. Rapid second event 500ms later (t = 10_500ms) -> blocked by 2500ms anti-loop cooldown!
        val decisionRapid = limitManager.evaluateLimits(
            todayTotalCount = 100,
            totalDailyLimit = 100,
            activePackage = Constants.PKG_TIKTOK,
            activeAppName = "TikTok",
            activeAppTodayCount = 60,
            perAppLimits = emptyMap(),
            todayUsageMs = 1_200_000L,
            dailyDurationLimitMinutes = 0,
            warningThresholdPercent = 0.8f,
            policy = LimitEnforcementPolicy.STRICT,
            focusSchedule = scheduleOff,
            warningAlreadyShown = true,
            limitAlreadyReached = true,
            userOverrodeToday = false,
            snoozeUntilTimestampMs = 0L,
            autoExitConsentGranted = true,
            isAccessibilityServiceActive = true,
            isTargetInForeground = true,
            nowTimestampMs = 10_500L
        )
        assertTrue(decisionRapid.shouldShowBlockingOverlay)
        assertFalse("Rapid event within 2500ms cooldown must NOT re-trigger GLOBAL_ACTION_HOME loop", decisionRapid.shouldPerformGlobalHomeExit)

        // 3. User re-opens TikTok 4 seconds later (t = 14_000ms) in Mode Ketat -> re-triggers exit!
        val decisionReopen = limitManager.evaluateLimits(
            todayTotalCount = 100,
            totalDailyLimit = 100,
            activePackage = Constants.PKG_TIKTOK,
            activeAppName = "TikTok",
            activeAppTodayCount = 60,
            perAppLimits = emptyMap(),
            todayUsageMs = 1_200_000L,
            dailyDurationLimitMinutes = 0,
            warningThresholdPercent = 0.8f,
            policy = LimitEnforcementPolicy.STRICT,
            focusSchedule = scheduleOff,
            warningAlreadyShown = true,
            limitAlreadyReached = true,
            userOverrodeToday = false,
            snoozeUntilTimestampMs = 0L,
            autoExitConsentGranted = true,
            isAccessibilityServiceActive = true,
            isTargetInForeground = true,
            nowTimestampMs = 14_000L
        )
        assertTrue("Re-opening target app after cooldown in Strict Mode must trigger exit again", decisionReopen.shouldPerformGlobalHomeExit)

        // 4. Protected System Settings / Emergency Dialer must NEVER be blocked or exited
        val settingsDecision = limitManager.evaluateLimits(
            todayTotalCount = 150,
            totalDailyLimit = 100,
            activePackage = "com.android.settings",
            activeAppName = "Settings",
            activeAppTodayCount = 0,
            perAppLimits = emptyMap(),
            todayUsageMs = 1_200_000L,
            dailyDurationLimitMinutes = 0,
            warningThresholdPercent = 0.8f,
            policy = LimitEnforcementPolicy.STRICT,
            focusSchedule = scheduleOff,
            warningAlreadyShown = true,
            limitAlreadyReached = true,
            userOverrodeToday = false,
            snoozeUntilTimestampMs = 0L,
            nowTimestampMs = 20_000L
        )
        assertFalse(settingsDecision.shouldShowBlockingOverlay)
        assertFalse(settingsDecision.shouldPerformGlobalHomeExit)
    }

    @Test
    fun permissionRevocation_immediatelyStopsTrackingAndHidesOverlays() {
        stateMachine.onForegroundAppChanged(Constants.PKG_YOUTUBE, true, "YouTube Shorts")
        stateMachine.onShortContentContextEvaluated(
            isShortFormContext = true,
            isCommentOrMenuOpen = false,
            confidence = DetectionConfidence.HIGH_CONFIDENCE,
            dedupState = ContentDeduplicationState.CONTENT_COUNTED
        )
        assertTrue(stateMachine.snapshot.value.isFloatingOverlayVisible)

        stateMachine.onServiceOrPermissionStateChanged(
            isAccessibilityGranted = false,
            isOverlayGranted = false,
            isServiceRunning = false,
            isTrackingEnabled = true
        )
        assertEquals(SystemTrackingState.PERMISSION_MISSING, stateMachine.snapshot.value.systemState)
        assertFalse(stateMachine.snapshot.value.isFloatingOverlayVisible)
        assertFalse(stateMachine.snapshot.value.isBlockingOverlayVisible)
    }

    @Test
    fun focusSchedule_overnightAndDaytimeWindowEvaluation() {
        val overnightSchedule = FocusScheduleConfig(
            enabled = true,
            startHour = 22,
            startMinute = 0,
            endHour = 6,
            endMinute = 0
        )
        assertTrue(overnightSchedule.isActiveAt(23, 15))
        assertTrue(overnightSchedule.isActiveAt(1, 30))
        assertFalse(overnightSchedule.isActiveAt(14, 0))

        val perAppJson = limitManager.serializePerAppLimits(mapOf(Constants.PKG_TIKTOK to 40))
        val parsed = limitManager.parsePerAppLimits(perAppJson)
        assertEquals(40, parsed[Constants.PKG_TIKTOK])
    }
}
