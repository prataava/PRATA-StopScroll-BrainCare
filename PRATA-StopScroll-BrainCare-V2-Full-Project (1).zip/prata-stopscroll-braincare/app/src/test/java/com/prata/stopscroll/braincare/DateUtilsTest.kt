package com.prata.stopscroll.braincare

import com.prata.stopscroll.braincare.util.DateUtils
import org.junit.Assert.*
import org.junit.Test

class DateUtilsTest {

    @Test
    fun todayFormat_matchesPattern() {
        val today = DateUtils.today()
        assertTrue(today.matches(Regex("""\d{4}-\d{2}-\d{2}""")))
    }

    @Test
    fun currentHour_withinRange() {
        val hour = DateUtils.currentHour()
        assertTrue(hour in 0..23)
    }

    @Test
    fun formatDuration_correctFormatting() {
        assertEquals("45s", DateUtils.formatDuration(45_000L))
        assertEquals("2m 30s", DateUtils.formatDuration(150_000L))
        assertEquals("1h 15m", DateUtils.formatDuration(4500_000L))
    }

    @Test
    fun formatMinutes_correctFormatting() {
        assertEquals("25m", DateUtils.formatMinutes(25))
        assertEquals("1h", DateUtils.formatMinutes(60))
        assertEquals("1h 30m", DateUtils.formatMinutes(90))
    }

    @Test
    fun getHourLabel_formattedWithPaddedZero() {
        assertEquals("00:00", DateUtils.getHourLabel(0))
        assertEquals("09:00", DateUtils.getHourLabel(9))
        assertEquals("23:00", DateUtils.getHourLabel(23))
    }

    @Test
    fun clockTamperDetection_detectsBackwardSystemClockManipulation() {
        val prevWall = 1_700_000_000_000L
        val prevElapsed = 10_000_000L

        // Normal progression (+60 seconds on both wall and monotonic clock)
        assertFalse(
            DateUtils.isSystemClockTamperedOrRolledBack(
                previousWallClockMs = prevWall,
                currentWallClockMs = prevWall + 60_000L,
                previousElapsedRealtimeMs = prevElapsed,
                currentElapsedRealtimeMs = prevElapsed + 60_000L
            )
        )

        // User rolled system clock backward by 3 hours while monotonic clock advanced 1 minute
        assertTrue(
            DateUtils.isSystemClockTamperedOrRolledBack(
                previousWallClockMs = prevWall,
                currentWallClockMs = prevWall - (3 * 3600_000L),
                previousElapsedRealtimeMs = prevElapsed,
                currentElapsedRealtimeMs = prevElapsed + 60_000L
            )
        )
    }
}
