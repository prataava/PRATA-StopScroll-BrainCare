package com.prata.stopscroll.braincare.ui.insights

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prata.stopscroll.braincare.data.local.dao.AppCount
import com.prata.stopscroll.braincare.data.local.dao.AppStatisticsAggregate
import com.prata.stopscroll.braincare.data.local.dao.HourlyCount
import com.prata.stopscroll.braincare.data.local.entity.BehaviorInsight
import com.prata.stopscroll.braincare.data.local.entity.DailyStatistics
import com.prata.stopscroll.braincare.data.local.entity.ShortContentDetection
import com.prata.stopscroll.braincare.data.repository.AIRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.UsageRepositoryImpl
import com.prata.stopscroll.braincare.domain.ai.BehaviorAnalyzer
import com.prata.stopscroll.braincare.domain.ai.HabitAlgorithm
import com.prata.stopscroll.braincare.domain.ai.PredictionEngine
import com.prata.stopscroll.braincare.util.DateUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class TimeRange(val label: String, val days: Int) {
    TODAY("Harian", 1),
    WEEK("Mingguan (7H)", 7),
    MONTH("Bulanan (30H)", 30)
}

data class InsightsUiState(
    val selectedRange: TimeRange = TimeRange.TODAY,
    val hourlyCounts: List<HourlyCount> = emptyList(),
    val dailyStats: List<DailyStatistics> = emptyList(),
    val appBreakdown: List<AppCount> = emptyList(),
    val recentDetections: List<ShortContentDetection> = emptyList(),
    val insights: List<BehaviorInsight> = emptyList(),
    val prediction: PredictionEngine.ScrollPrediction? = null,
    val weeklyBaseline: HabitAlgorithm.HabitBaseline? = null,
    val totalCount: Int = 0,
    val dailyAverage: Int = 0,
    val totalFocusMinutes: Int = 0,
    val daysUnderLimit: Int = 0,
    val isLoading: Boolean = false
)

@HiltViewModel
class InsightsViewModel @Inject constructor(
    private val usageRepository: UsageRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl,
    private val aiRepository: AIRepositoryImpl,
    private val behaviorAnalyzer: BehaviorAnalyzer,
    private val predictionEngine: PredictionEngine,
    private val habitAlgorithm: HabitAlgorithm
) : ViewModel() {

    private val _uiState = MutableStateFlow(InsightsUiState())
    val uiState: StateFlow<InsightsUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    fun setTimeRange(range: TimeRange) {
        _uiState.update { it.copy(selectedRange = range) }
        loadData()
    }

    fun loadData() {
        val range = _uiState.value.selectedRange
        val today = DateUtils.today()
        val startDate = DateUtils.daysAgo(range.days - 1)

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            val hourly = if (range == TimeRange.TODAY) {
                usageRepository.getHourlyCountForDate(today)
            } else {
                usageRepository.getHourlyDistributionRange(startDate, today).firstOrNull() ?: emptyList()
            }

            val todayCount = usageRepository.getShortContentCountForDate(today)
            val daily = statsRepository.getDailyStatsRange(startDate, today).firstOrNull() ?: emptyList()

            val total = if (range == TimeRange.TODAY) {
                todayCount
            } else {
                daily.filter { it.date != today }.sumOf { it.totalShortContent } + todayCount
            }

            val activeDaysCount = if (range == TimeRange.TODAY) 1 else (daily.count { it.totalShortContent > 0 || it.date == today }).coerceAtLeast(1)
            val avg = total / activeDaysCount

            val focusMins = statsRepository.getTotalFocusMinutesRange(startDate, today) ?: 0
            val underLimit = statsRepository.getDaysUnderLimit(startDate, today)

            // Per-app distribution across range
            val todayApps = usageRepository.getContentCountByAppForDate(today)
            val appDistribution = if (range == TimeRange.TODAY) {
                todayApps
            } else {
                val agg: List<AppStatisticsAggregate> =
                    statsRepository.getAggregatedAppStats(startDate, today).firstOrNull() ?: emptyList()
                if (agg.isNotEmpty()) {
                    agg.map { AppCount(it.packageName, it.appName, it.shortContentCount) }
                } else {
                    todayApps
                }
            }

            val detections = usageRepository.getShortContentByDate(today).firstOrNull()?.take(25) ?: emptyList()
            val pred = predictionEngine.predictTodayLimitExceedance()
            val baseline = habitAlgorithm.calculateBaseline()

            behaviorAnalyzer.analyzeAndGenerateInsights()
            val insightsList = aiRepository.getRecentInsights(10).firstOrNull() ?: emptyList()

            _uiState.update {
                it.copy(
                    hourlyCounts = hourly,
                    dailyStats = daily,
                    appBreakdown = appDistribution,
                    recentDetections = detections,
                    insights = insightsList,
                    prediction = pred,
                    weeklyBaseline = baseline,
                    totalCount = total,
                    dailyAverage = avg,
                    totalFocusMinutes = focusMins,
                    daysUnderLimit = underLimit,
                    isLoading = false
                )
            }
        }
    }
}
