package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "questionnaire_responses")
data class QuestionnaireResponse(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // GOALS, HABITS, TRIGGERS, TARGETS, EVALUATION
    val questionKey: String,
    val answerValue: String, // JSON encoded
    val answeredAt: Long = System.currentTimeMillis(),
    val version: Int = 1
)
