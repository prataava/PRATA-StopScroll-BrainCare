package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.UserGoals
import kotlinx.coroutines.flow.Flow

@Dao
interface UserGoalsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrReplace(goals: UserGoals)

    @Update
    suspend fun update(goals: UserGoals)

    @Query("SELECT * FROM user_goals WHERE id = 1")
    suspend fun get(): UserGoals?

    @Query("SELECT * FROM user_goals WHERE id = 1")
    fun observe(): Flow<UserGoals?>

    @Query("UPDATE user_goals SET dailyLimit = :limit, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updateDailyLimit(limit: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE user_goals SET approach = :approach, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updateApproach(approach: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE user_goals SET perAppLimits = :perAppLimitsJson, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updatePerAppLimits(perAppLimitsJson: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE user_goals SET focusGoalMinutes = :minutes, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updateFocusGoal(minutes: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE user_goals SET detailLevel = :level, updatedAt = :updatedAt WHERE id = 1")
    suspend fun updateDetailLevel(level: String, updatedAt: Long = System.currentTimeMillis())
}
