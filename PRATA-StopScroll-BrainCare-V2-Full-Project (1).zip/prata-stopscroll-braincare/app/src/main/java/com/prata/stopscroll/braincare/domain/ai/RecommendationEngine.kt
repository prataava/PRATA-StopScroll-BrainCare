package com.prata.stopscroll.braincare.domain.ai

import com.prata.stopscroll.braincare.data.local.entity.AIRecommendation
import com.prata.stopscroll.braincare.data.repository.AIRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.UsageRepositoryImpl
import com.prata.stopscroll.braincare.util.DateUtils
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RecommendationEngine @Inject constructor(
    private val aiRepository: AIRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl,
    private val usageRepository: UsageRepositoryImpl
) {

    suspend fun generateRecommendationsIfNeeded(): List<AIRecommendation> {
        val today = DateUtils.today()
        val currentCount = usageRepository.getShortContentCountForDate(today)
        val dailyLimit = statsRepository.getOrCreateDailyLimit(today).totalLimit

        val pending = aiRepository.getPendingRecommendations().firstOrNull() ?: emptyList()
        if (pending.isNotEmpty()) {
            return pending
        }

        // Check already dismissed types in the last 3 days so we don't spam the user
        val dismissed = aiRepository.getRecommendationsByStatus("DISMISSED").firstOrNull() ?: emptyList()
        val dismissedTypes = dismissed.map { it.type }.toSet()

        val newRecommendations = mutableListOf<AIRecommendation>()

        // Recommendation 1: High usage -> Focus Mode
        if (currentCount >= dailyLimit * 0.7 && !dismissedTypes.contains("FOCUS_MODE")) {
            val rec = AIRecommendation(
                type = "FOCUS_MODE",
                title = "Aktifkan Focus Mode 25 Menit",
                description = "Kamu sudah mencapai ${((currentCount.toFloat() / dailyLimit) * 100).toInt()}% batas scrolling hari ini. Mulai sesi fokus untuk mengistirahatkan pikiran.",
                reasoning = "Data menunjukkan scrolling intensif hari ini ($currentCount konten). Sesi fokus membantu mengembalikan konsentrasi."
            )
            aiRepository.saveRecommendation(rec)
            newRecommendations.add(rec)
        }

        // Recommendation 2: Bedtime Doomscrolling Prevention
        val currentHour = DateUtils.currentHour()
        if ((currentHour >= 21 || currentHour <= 2) && currentCount > 20 && !dismissedTypes.contains("BEDTIME_ROUTINE")) {
            val rec = AIRecommendation(
                type = "BEDTIME_ROUTINE",
                title = "Jadwalkan Bebas Layar Sebelum Tidur",
                description = "Scrolling larut malam menunda waktu tidur dan mengganggu kualitas istirahat. Taruh perangkat 30 menit sebelum tidur.",
                reasoning = "Terdeteksi aktivitas konten pendek pada jam tidur ($currentHour:00)."
            )
            aiRepository.saveRecommendation(rec)
            newRecommendations.add(rec)
        }

        // Recommendation 3: Habitual App Opening -> Move App Icon
        val topApps = usageRepository.getContentCountByAppForDate(today)
        val highestApp = topApps.maxByOrNull { it.count }
        if (highestApp != null && highestApp.count > 35 && !dismissedTypes.contains("MOVE_APP")) {
            val rec = AIRecommendation(
                type = "MOVE_APP",
                title = "Pindahkan Ikon ${highestApp.appName}",
                description = "Pindahkan ikon ${highestApp.appName} keluar dari layar utama ke dalam folder tersembunyi untuk mengurangi bukaan impulsif.",
                reasoning = "${highestApp.appName} adalah sumber scrolling tertinggi (${highestApp.count} konten hari ini)."
            )
            aiRepository.saveRecommendation(rec)
            newRecommendations.add(rec)
        }

        return newRecommendations
    }

    suspend fun acceptRecommendation(id: Long) {
        aiRepository.updateRecommendationStatus(id, "ACCEPTED")
    }

    suspend fun dismissRecommendation(id: Long) {
        aiRepository.updateRecommendationStatus(id, "DISMISSED")
    }
}
