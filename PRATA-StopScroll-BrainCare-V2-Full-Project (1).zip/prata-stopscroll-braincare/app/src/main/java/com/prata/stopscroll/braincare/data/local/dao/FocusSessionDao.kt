package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.FocusSession
import kotlinx.coroutines.flow.Flow

@Dao
interface FocusSessionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: FocusSession): Long

    @Update
    suspend fun update(session: FocusSession)

    @Delete
    suspend fun delete(session: FocusSession)

    @Query("SELECT * FROM focus_sessions WHERE id = :id")
    suspend fun getById(id: Long): FocusSession?

    @Query("SELECT * FROM focus_sessions WHERE endTime IS NULL ORDER BY startTime DESC LIMIT 1")
    suspend fun getActiveSession(): FocusSession?

    @Query("SELECT * FROM focus_sessions WHERE endTime IS NULL ORDER BY startTime DESC LIMIT 1")
    fun observeActiveSession(): Flow<FocusSession?>

    @Query("SELECT * FROM focus_sessions WHERE date = :date ORDER BY startTime DESC")
    fun getByDate(date: String): Flow<List<FocusSession>>

    @Query("SELECT SUM(actualDurationMinutes) FROM focus_sessions WHERE date = :date AND completed = 1")
    fun getCompletedMinutesByDate(date: String): Flow<Int?>

    @Query("SELECT COUNT(*) FROM focus_sessions WHERE date = :date AND completed = 1")
    fun getCompletedCountByDate(date: String): Flow<Int>

    @Query("SELECT SUM(actualDurationMinutes) FROM focus_sessions WHERE date BETWEEN :startDate AND :endDate AND completed = 1")
    suspend fun getTotalFocusMinutesRange(startDate: String, endDate: String): Int?

    @Query("UPDATE focus_sessions SET interruptionCount = interruptionCount + 1 WHERE id = :id")
    suspend fun incrementInterruption(id: Long)

    @Query("DELETE FROM focus_sessions WHERE date < :beforeDate")
    suspend fun deleteOlderThan(beforeDate: String)
}
