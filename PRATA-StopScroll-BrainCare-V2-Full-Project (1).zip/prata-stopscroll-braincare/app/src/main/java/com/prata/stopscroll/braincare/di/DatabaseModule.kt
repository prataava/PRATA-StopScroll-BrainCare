package com.prata.stopscroll.braincare.di

import android.content.Context
import androidx.room.Room
import com.prata.stopscroll.braincare.data.datastore.UserSettingsDataStore
import com.prata.stopscroll.braincare.data.local.PrataDatabase
import com.prata.stopscroll.braincare.data.local.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun providePrataDatabase(@ApplicationContext context: Context): PrataDatabase {
        return Room.databaseBuilder(
            context,
            PrataDatabase::class.java,
            PrataDatabase.DATABASE_NAME
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    @Provides
    fun provideUsageSessionDao(db: PrataDatabase): UsageSessionDao = db.usageSessionDao()

    @Provides
    fun provideShortContentDao(db: PrataDatabase): ShortContentDao = db.shortContentDao()

    @Provides
    fun provideDailyStatsDao(db: PrataDatabase): DailyStatsDao = db.dailyStatsDao()

    @Provides
    fun provideAppStatsDao(db: PrataDatabase): AppStatsDao = db.appStatsDao()

    @Provides
    fun provideUserGoalsDao(db: PrataDatabase): UserGoalsDao = db.userGoalsDao()

    @Provides
    fun provideDailyLimitDao(db: PrataDatabase): DailyLimitDao = db.dailyLimitDao()

    @Provides
    fun provideFocusSessionDao(db: PrataDatabase): FocusSessionDao = db.focusSessionDao()

    @Provides
    fun provideNotificationDao(db: PrataDatabase): NotificationDao = db.notificationDao()

    @Provides
    fun provideQuestionnaireDao(db: PrataDatabase): QuestionnaireDao = db.questionnaireDao()

    @Provides
    fun provideInsightDao(db: PrataDatabase): InsightDao = db.insightDao()

    @Provides
    fun provideAIConversationDao(db: PrataDatabase): AIConversationDao = db.aiConversationDao()

    @Provides
    fun provideAIRecommendationDao(db: PrataDatabase): AIRecommendationDao = db.aiRecommendationDao()

    @Provides
    fun provideChallengeDao(db: PrataDatabase): ChallengeDao = db.challengeDao()

    @Provides
    @Singleton
    fun provideUserSettingsDataStore(@ApplicationContext context: Context): UserSettingsDataStore {
        return UserSettingsDataStore(context)
    }
}
