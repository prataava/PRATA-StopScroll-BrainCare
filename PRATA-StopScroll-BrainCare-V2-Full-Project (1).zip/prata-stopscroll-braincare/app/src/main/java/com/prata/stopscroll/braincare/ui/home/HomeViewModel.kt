package com.prata.stopscroll.braincare.ui.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prata.stopscroll.braincare.data.local.dao.AppCount
import com.prata.stopscroll.braincare.data.local.entity.AIRecommendation
import com.prata.stopscroll.braincare.data.local.entity.BehaviorInsight
import com.prata.stopscroll.braincare.data.local.entity.FocusSession
import com.prata.stopscroll.braincare.data.local.entity.ShortContentDetection
import com.prata.stopscroll.braincare.data.repository.AIRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.ChallengeRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.PreferencesRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.UsageRepositoryImpl
import com.prata.stopscroll.braincare.domain.ai.RecommendationEngine
import com.prata.stopscroll.braincare.domain.limit.HardLimitManager
import com.prata.stopscroll.braincare.domain.state.LimitEnforcementPolicy
import com.prata.stopscroll.braincare.domain.state.SystemTrackingState
import com.prata.stopscroll.braincare.domain.state.TrackingStateMachine
import com.prata.stopscroll.braincare.service.MonitoringService
import com.prata.stopscroll.braincare.service.ScrollAccessibilityService
import com.prata.stopscroll.braincare.util.DateUtils
import com.prata.stopscroll.braincare.util.PermissionUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val todayShortCount: Int = 0,
    val dailyLimit: Int = 100,
    val limitReached: Boolean = false,
    val limitWarningShown: Boolean = false,
    val systemState: SystemTrackingState = SystemTrackingState.IDLE,
    val enforcementPolicy: LimitEnforcementPolicy = LimitEnforcementPolicy.FOCUS,
    val perAppLimits: Map<String, Int> = emptyMap(),
    val appBreakdown: List<AppCount> = emptyList(),
    val recentDetections: List<ShortContentDetection> = emptyList(),
    val streakDays: Int = 0,
    val todayFocusMinutes: Int = 0,
    val isTrackingEnabled: Boolean = true,
    val isFloatingCounterEnabled: Boolean = true,
    val isAccessibilityActive: Boolean = false,
    val isOverlayGranted: Boolean = false,
    val reducedMotion: Boolean = false,
    val recentInsight: BehaviorInsight? = null,
    val pendingRecommendations: List<AIRecommendation> = emptyList(),
    val todayUsageMs: Long = 0L
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val usageRepository: UsageRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl,
    private val preferencesRepository: PreferencesRepositoryImpl,
    private val aiRepository: AIRepositoryImpl,
    private val challengeRepository: ChallengeRepositoryImpl,
    private val recommendationEngine: RecommendationEngine,
    private val trackingStateMachine: TrackingStateMachine,
    private val hardLimitManager: HardLimitManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        observeReactiveStreams()
        loadData()
    }

    private fun observeReactiveStreams() {
        val today = DateUtils.today()

        // Observe live short content count & app distribution from Room (Single Source of Truth)
        viewModelScope.launch {
            combine(
                usageRepository.getShortContentCountByDate(today),
                usageRepository.getAppDistribution(today),
                usageRepository.getShortContentByDate(today),
                statsRepository.observeDailyLimit(today),
                statsRepository.getCompletedFocusMinutesByDate(today)
            ) { count, apps, detections, limitObj, focusMins ->
                Quintuple(count, apps, detections.take(15), limitObj, focusMins ?: 0)
            }.collectLatest { (count, apps, detections, limitObj, focusMins) ->
                val effectiveLimit = limitObj?.totalLimit ?: _uiState.value.dailyLimit
                _uiState.update { current ->
                    current.copy(
                        todayShortCount = count,
                        dailyLimit = effectiveLimit,
                        limitReached = limitObj?.limitReached ?: (count >= effectiveLimit),
                        limitWarningShown = limitObj?.warningShown ?: false,
                        appBreakdown = apps,
                        recentDetections = detections,
                        todayFocusMinutes = focusMins
                    )
                }
            }
        }

        // Observe preferences & state machine
        viewModelScope.launch {
            combine(
                preferencesRepository.trackingEnabled,
                preferencesRepository.floatingCounterEnabled,
                preferencesRepository.limitEnforcementPolicy,
                preferencesRepository.reducedMotion,
                trackingStateMachine.snapshot
            ) { tracking, floating, policyStr, reducedMotion, snapshot ->
                Quintuple(tracking, floating, policyStr, reducedMotion, snapshot)
            }.collectLatest { (tracking, floating, policyStr, reducedMotion, snapshot) ->
                _uiState.update { current ->
                    current.copy(
                        isTrackingEnabled = tracking,
                        isFloatingCounterEnabled = floating,
                        enforcementPolicy = LimitEnforcementPolicy.fromKey(policyStr),
                        reducedMotion = reducedMotion,
                        systemState = snapshot.systemState
                    )
                }
            }
        }

        viewModelScope.launch {
            preferencesRepository.observeGoals().collectLatest { goals ->
                _uiState.update {
                    it.copy(perAppLimits = hardLimitManager.parsePerAppLimits(goals.perAppLimits))
                }
            }
        }
    }

    fun loadData() {
        val today = DateUtils.today()

        viewModelScope.launch {
            val isAccessEnabled = PermissionUtils.isAccessibilityServiceEnabled(context) || ScrollAccessibilityService.isRunning
            val isOverlayEnabled = PermissionUtils.isOverlayPermissionGranted(context) || isAccessEnabled

            val limitObj = statsRepository.getOrCreateDailyLimit(today)
            val todayCount = usageRepository.getShortContentCountForDate(today)
            statsRepository.setDailyCount(today, todayCount)

            val activeChallenge = challengeRepository.getActiveChallenge()
            val maxDailyStreak = statsRepository.getMaxStreak().firstOrNull() ?: 0
            val effectiveStreak = maxOf(activeChallenge?.currentStreak ?: 0, maxDailyStreak)

            val recommendations = recommendationEngine.generateRecommendationsIfNeeded()
            val recentInsights = aiRepository.getRecentInsights(1).firstOrNull()

            trackingStateMachine.onServiceOrPermissionStateChanged(
                isAccessibilityGranted = isAccessEnabled,
                isOverlayGranted = isOverlayEnabled,
                isServiceRunning = ScrollAccessibilityService.isRunning || isAccessEnabled,
                isTrackingEnabled = _uiState.value.isTrackingEnabled
            )
            trackingStateMachine.syncLimitsAndCounts(
                todayShortCount = todayCount,
                dailyLimit = limitObj.totalLimit
            )

            _uiState.update { current ->
                current.copy(
                    todayShortCount = todayCount,
                    dailyLimit = limitObj.totalLimit,
                    limitReached = limitObj.limitReached || todayCount >= limitObj.totalLimit,
                    limitWarningShown = limitObj.warningShown,
                    streakDays = effectiveStreak,
                    isAccessibilityActive = isAccessEnabled,
                    isOverlayGranted = isOverlayEnabled,
                    recentInsight = recentInsights?.firstOrNull(),
                    pendingRecommendations = recommendations
                )
            }
        }
    }

    fun toggleTracking() {
        viewModelScope.launch {
            val current = _uiState.value.isTrackingEnabled
            val newStatus = !current
            preferencesRepository.setTrackingEnabled(newStatus)
            if (newStatus) {
                try {
                    MonitoringService.start(context)
                } catch (_: Exception) {}
            } else {
                try {
                    MonitoringService.stop(context)
                } catch (_: Exception) {}
            }
            loadData()
        }
    }

    fun toggleFloatingCounter() {
        viewModelScope.launch {
            val next = !_uiState.value.isFloatingCounterEnabled
            preferencesRepository.setFloatingCounterEnabled(next)
        }
    }

    fun updateDailyLimitConfirmed(newLimit: Int) {
        viewModelScope.launch {
            val today = DateUtils.today()
            statsRepository.updateDailyLimit(today, newLimit)
            preferencesRepository.updateDailyLimit(newLimit)
            loadData()
        }
    }

    fun recordFocusSession(actualMinutes: Int, interruptions: Int) {
        viewModelScope.launch {
            val today = DateUtils.today()
            val session = FocusSession(
                startTime = System.currentTimeMillis() - (actualMinutes * 60 * 1000L),
                endTime = System.currentTimeMillis(),
                plannedDurationMinutes = actualMinutes,
                actualDurationMinutes = actualMinutes,
                completed = true,
                interruptionCount = interruptions,
                date = today
            )
            statsRepository.recordFocusSession(session)
            loadData()
        }
    }

    fun acceptRecommendation(id: Long) {
        viewModelScope.launch {
            recommendationEngine.acceptRecommendation(id)
            loadData()
        }
    }

    fun dismissRecommendation(id: Long) {
        viewModelScope.launch {
            recommendationEngine.dismissRecommendation(id)
            loadData()
        }
    }

    private data class Quintuple<A, B, C, D, E>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D,
        val fifth: E
    )
}
