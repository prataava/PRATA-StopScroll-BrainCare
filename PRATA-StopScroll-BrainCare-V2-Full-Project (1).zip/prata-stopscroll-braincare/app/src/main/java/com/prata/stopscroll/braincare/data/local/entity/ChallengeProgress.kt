package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "challenge_progress")
data class ChallengeProgress(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val challengeType: String, // SEVEN_DAY, THIRTY_DAY, CUSTOM
    val startDate: String,
    val endDate: String,
    val targetDailyLimit: Int,
    val daysCompleted: Int = 0,
    val daysFailed: Int = 0,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val isActive: Boolean = true,
    val completedAt: Long? = null
)
