package com.prata.stopscroll.braincare.worker

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.prata.stopscroll.braincare.di.ServiceEntryPoint
import com.prata.stopscroll.braincare.util.DateUtils
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Exports PRATA StopScroll BrainCare statistics and history to CSV, PDF, or JSON Backup (Requirement I).
 */
class DataExportWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val format = inputData.getString(KEY_FORMAT)?.uppercase() ?: "CSV"
        val entryPoint = EntryPointAccessors.fromApplication(
            applicationContext,
            ServiceEntryPoint::class.java
        )

        val statsRepo = entryPoint.statsRepository()
        val usageRepo = entryPoint.usageRepository()
        val prefsRepo = entryPoint.preferencesRepository()

        val today = DateUtils.today()
        val start90 = DateUtils.daysAgo(90)
        val allStats = statsRepo.getDailyStatsRange(start90, today).firstOrNull() ?: emptyList()
        val allSessions = usageRepo.getRecentSessions(300).firstOrNull() ?: emptyList()
        val todayDetections = usageRepo.getShortContentByDate(today).firstOrNull() ?: emptyList()
        val goals = prefsRepo.getOrCreateGoals()

        try {
            val exportDir = File(applicationContext.filesDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()

            val timestamp = System.currentTimeMillis()
            val ext = when (format) {
                "PDF" -> "pdf"
                "JSON", "BACKUP" -> "json"
                else -> "csv"
            }
            val fileName = if (format == "BACKUP") {
                "prata_braincare_backup_latest.json"
            } else {
                "prata_braincare_export_$timestamp.$ext"
            }
            val targetFile = File(exportDir, fileName)

            when (format) {
                "JSON", "BACKUP" -> {
                    val json = JSONObject().apply {
                        put("schemaVersion", 2)
                        put("exportedAt", timestamp)
                        put("exportedDate", today)
                        put("app", "PRATA StopScroll BrainCare")
                        put("userGoals", JSONObject().apply {
                            put("dailyLimit", goals.dailyLimit)
                            put("perAppLimits", goals.perAppLimits)
                            put("focusGoalMinutes", goals.focusGoalMinutes)
                            put("approach", goals.approach)
                        })

                        val statsArray = JSONArray()
                        allStats.forEach { stat ->
                            statsArray.put(JSONObject().apply {
                                put("date", stat.date)
                                put("totalShortContent", stat.totalShortContent)
                                put("totalUsageMs", stat.totalUsageMs)
                                put("totalSessions", stat.totalSessions)
                                put("focusMinutes", stat.focusMinutes)
                                put("streakDay", stat.streakDay)
                                put("limitReached", stat.limitReached)
                                put("limitValue", stat.limitValue ?: goals.dailyLimit)
                            })
                        }
                        put("dailyStats", statsArray)

                        val sessionsArray = JSONArray()
                        allSessions.forEach { session ->
                            sessionsArray.put(JSONObject().apply {
                                put("appName", session.appName)
                                put("packageName", session.packageName)
                                put("startTime", session.startTime)
                                put("endTime", session.endTime ?: session.startTime)
                                put("durationMs", session.durationMs)
                                put("shortContentCount", session.shortContentCount)
                                put("date", session.date)
                            })
                        }
                        put("sessions", sessionsArray)
                    }
                    targetFile.writeText(json.toString(2))
                }

                "PDF" -> {
                    generatePdfReport(
                        targetFile = targetFile,
                        today = today,
                        dailyLimit = goals.dailyLimit,
                        allStats = allStats,
                        todayDetectionsCount = todayDetections.size
                    )
                }

                else -> {
                    // CSV export
                    val sb = StringBuilder()
                    sb.append("Date,TotalShortContent,UsageDurationMs,TotalSessions,FocusMinutes,StreakDay,LimitReached,LimitValue\n")
                    allStats.forEach { stat ->
                        sb.append(
                            "${stat.date},${stat.totalShortContent},${stat.totalUsageMs}," +
                                    "${stat.totalSessions},${stat.focusMinutes},${stat.streakDay}," +
                                    "${stat.limitReached},${stat.limitValue ?: goals.dailyLimit}\n"
                        )
                    }
                    targetFile.writeText(sb.toString())
                }
            }

            Result.success(workDataOf(KEY_OUTPUT_PATH to targetFile.absolutePath))
        } catch (e: Exception) {
            Result.failure()
        }
    }

    private fun generatePdfReport(
        targetFile: File,
        today: String,
        dailyLimit: Int,
        allStats: List<com.prata.stopscroll.braincare.data.local.entity.DailyStatistics>,
        todayDetectionsCount: Int
    ) {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 standard
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E1E1E")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E8854A")
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2D2D2D")
            textSize = 11f
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E0D6CC")
            strokeWidth = 1f
        }

        var y = 50f
        canvas.drawText("PRATA StopScroll BrainCare — Laporan Digital Wellbeing", 40f, y, titlePaint)
        y += 22f
        canvas.drawText("Tanggal Cetak: $today  •  Batas Harian Aktif: $dailyLimit konten pendek", 40f, y, accentPaint)
        y += 16f
        canvas.drawLine(40f, y, 555f, y, linePaint)

        y += 26f
        val totalRecent = allStats.sumOf { it.totalShortContent }
        val avgRecent = if (allStats.isNotEmpty()) totalRecent / allStats.size else todayDetectionsCount
        val daysUnderLimit = allStats.count { !it.limitReached }
        val totalFocusMins = allStats.sumOf { it.focusMinutes }

        canvas.drawText("Ringkasan Eksekutif (${allStats.size} Hari Tercatat):", 40f, y, accentPaint)
        y += 20f
        canvas.drawText("• Konten Pendek Hari Ini ($today): $todayDetectionsCount video", 48f, y, bodyPaint)
        y += 18f
        canvas.drawText("• Total Konten Terdeteksi: $totalRecent video (Rata-rata: $avgRecent / hari)", 48f, y, bodyPaint)
        y += 18f
        canvas.drawText("• Hari Dalam Batas Aman: $daysUnderLimit dari ${allStats.size} hari", 48f, y, bodyPaint)
        y += 18f
        canvas.drawText("• Total Durasi Sesi Fokus: $totalFocusMins menit", 48f, y, bodyPaint)

        y += 28f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 24f
        canvas.drawText("Riwayat Harian Terbaru (Maksimal 20 Hari Terakhir)", 40f, y, accentPaint)
        y += 20f

        canvas.drawText("Tanggal", 48f, y, bodyPaint)
        canvas.drawText("Konten Pendek", 160f, y, bodyPaint)
        canvas.drawText("Batas", 270f, y, bodyPaint)
        canvas.drawText("Fokus (m)", 350f, y, bodyPaint)
        canvas.drawText("Status", 440f, y, bodyPaint)
        y += 8f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 18f

        allStats.sortedByDescending { it.date }.take(20).forEach { stat ->
            if (y < 790f) {
                canvas.drawText(stat.date, 48f, y, bodyPaint)
                canvas.drawText("${stat.totalShortContent}", 160f, y, bodyPaint)
                canvas.drawText("${stat.limitValue ?: dailyLimit}", 270f, y, bodyPaint)
                canvas.drawText("${stat.focusMinutes}", 350f, y, bodyPaint)
                val statusStr = if (stat.limitReached) "Melewati Batas" else "Terkendali"
                canvas.drawText(statusStr, 440f, y, bodyPaint)
                y += 18f
            }
        }

        pdfDocument.finishPage(page)
        FileOutputStream(targetFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
    }

    companion object {
        const val KEY_FORMAT = "key_format"
        const val KEY_OUTPUT_PATH = "key_output_path"
    }
}
