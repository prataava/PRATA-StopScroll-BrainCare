package com.prata.stopscroll.braincare.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "prata_settings")

/**
 * Comprehensive DataStore wrapper for user settings, floating overlay customization,
 * limit enforcement policy, auto-exit consent, exempted apps, focus schedules, and daily reset integrity.
 */
@Singleton
class UserSettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore: DataStore<Preferences> = context.dataStore

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val TRACKING_ENABLED = booleanPreferencesKey("tracking_enabled")
        val SELECTED_APPS = stringSetPreferencesKey("selected_apps")
        val EXEMPTED_APPS = stringSetPreferencesKey("exempted_apps")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val AI_CLOUD_ENABLED = booleanPreferencesKey("ai_cloud_enabled")
        val AI_CLOUD_CONSENT = booleanPreferencesKey("ai_cloud_consent")
        val AI_CLOUD_ENDPOINT = stringPreferencesKey("ai_cloud_endpoint")
        val DARK_MODE = stringPreferencesKey("dark_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val DATA_RETENTION_DAYS = intPreferencesKey("data_retention_days")

        // Floating Counter Settings (Requirement D & I)
        val FLOATING_COUNTER_ENABLED = booleanPreferencesKey("floating_counter_enabled")
        val FLOATING_COUNTER_SIZE = stringPreferencesKey("floating_counter_size") // small, medium, large
        val FLOATING_COUNTER_SHOW_MASCOT = booleanPreferencesKey("floating_counter_show_mascot")
        val FLOATING_COUNTER_EXPANDED_DEFAULT = booleanPreferencesKey("floating_counter_expanded_default")
        val FLOATING_COUNTER_POS_X = intPreferencesKey("floating_counter_pos_x")
        val FLOATING_COUNTER_POS_Y = intPreferencesKey("floating_counter_pos_y")
        val FLOATING_COUNTER_ANIMATION = booleanPreferencesKey("floating_counter_animation")

        // Hard Limit, Auto-Exit Consent, Schedule & Break Reminder Settings (Section 3)
        val LIMIT_ENFORCEMENT_POLICY = stringPreferencesKey("limit_enforcement_policy") // reminder, focus, strict
        val AUTO_EXIT_CONSENT_GRANTED = booleanPreferencesKey("auto_exit_consent_granted")
        val STRICT_MODE_CONSENT_GRANTED = booleanPreferencesKey("strict_mode_consent_granted")
        val WARNING_THRESHOLD_PERCENT = floatPreferencesKey("warning_threshold_percent")
        val DAILY_DURATION_LIMIT_MINUTES = intPreferencesKey("daily_duration_limit_minutes")
        val FOCUS_SCHEDULE_ENABLED = booleanPreferencesKey("focus_schedule_enabled")
        val FOCUS_SCHEDULE_START_HOUR = intPreferencesKey("focus_schedule_start_hour")
        val FOCUS_SCHEDULE_END_HOUR = intPreferencesKey("focus_schedule_end_hour")
        val BREAK_REMINDER_ENABLED = booleanPreferencesKey("break_reminder_enabled")
        val BREAK_REMINDER_INTERVAL = intPreferencesKey("break_reminder_interval")
        val SNOOZE_UNTIL_TIMESTAMP_MS = longPreferencesKey("snooze_until_timestamp_ms")

        // Daily Reset & Clock Integrity (Requirement G)
        val LAST_ACTIVE_DATE = stringPreferencesKey("last_active_date")
        val LAST_WALL_CLOCK_MS = longPreferencesKey("last_wall_clock_ms")
        val LAST_ELAPSED_REALTIME_MS = longPreferencesKey("last_elapsed_realtime_ms")
    }

    // ─── Onboarding & Tracking ───────────────────────────────────────────
    val onboardingCompleted: Flow<Boolean> = dataStore.data.map { it[Keys.ONBOARDING_COMPLETED] ?: false }
    suspend fun setOnboardingCompleted(completed: Boolean) {
        dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    val trackingEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.TRACKING_ENABLED] ?: true }
    suspend fun setTrackingEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.TRACKING_ENABLED] = enabled }
    }

    // ─── Selected & Exempted Apps ────────────────────────────────────────
    val selectedApps: Flow<Set<String>> = dataStore.data.map { it[Keys.SELECTED_APPS] ?: emptySet() }
    suspend fun setSelectedApps(apps: Set<String>) {
        dataStore.edit { it[Keys.SELECTED_APPS] = apps }
    }

    suspend fun addSelectedApp(packageName: String) {
        dataStore.edit { prefs ->
            val current = prefs[Keys.SELECTED_APPS] ?: emptySet()
            prefs[Keys.SELECTED_APPS] = current + packageName
        }
    }

    suspend fun removeSelectedApp(packageName: String) {
        dataStore.edit { prefs ->
            val current = prefs[Keys.SELECTED_APPS] ?: emptySet()
            prefs[Keys.SELECTED_APPS] = current - packageName
        }
    }

    val exemptedApps: Flow<Set<String>> = dataStore.data.map { it[Keys.EXEMPTED_APPS] ?: emptySet() }
    suspend fun toggleExemptedApp(packageName: String) {
        dataStore.edit { prefs ->
            val current = prefs[Keys.EXEMPTED_APPS] ?: emptySet()
            prefs[Keys.EXEMPTED_APPS] = if (current.contains(packageName)) current - packageName else current + packageName
        }
    }

    // ─── Notifications & AI Cloud ────────────────────────────────────────
    val notificationsEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.NOTIFICATIONS_ENABLED] ?: true }
    suspend fun setNotificationsEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    val aiCloudEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.AI_CLOUD_ENABLED] ?: false }
    suspend fun setAiCloudEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.AI_CLOUD_ENABLED] = enabled }
    }

    val aiCloudConsent: Flow<Boolean> = dataStore.data.map { it[Keys.AI_CLOUD_CONSENT] ?: false }
    suspend fun setAiCloudConsent(consent: Boolean) {
        dataStore.edit { it[Keys.AI_CLOUD_CONSENT] = consent }
    }

    val aiCloudEndpoint: Flow<String> = dataStore.data.map { it[Keys.AI_CLOUD_ENDPOINT] ?: "" }
    suspend fun setAiCloudEndpoint(endpoint: String) {
        dataStore.edit { it[Keys.AI_CLOUD_ENDPOINT] = endpoint }
    }

    // ─── Appearance & Accessibility ──────────────────────────────────────
    val darkMode: Flow<String> = dataStore.data.map { it[Keys.DARK_MODE] ?: "system" }
    suspend fun setDarkMode(mode: String) {
        dataStore.edit { it[Keys.DARK_MODE] = mode }
    }

    val language: Flow<String> = dataStore.data.map { it[Keys.LANGUAGE] ?: "id" }
    suspend fun setLanguage(lang: String) {
        dataStore.edit { it[Keys.LANGUAGE] = lang }
    }

    val reducedMotion: Flow<Boolean> = dataStore.data.map { it[Keys.REDUCED_MOTION] ?: false }
    suspend fun setReducedMotion(reduced: Boolean) {
        dataStore.edit { it[Keys.REDUCED_MOTION] = reduced }
    }

    val dataRetentionDays: Flow<Int> = dataStore.data.map { it[Keys.DATA_RETENTION_DAYS] ?: 90 }
    suspend fun setDataRetentionDays(days: Int) {
        dataStore.edit { it[Keys.DATA_RETENTION_DAYS] = days }
    }

    // ─── Floating Counter Customization ──────────────────────────────────
    val floatingCounterEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.FLOATING_COUNTER_ENABLED] ?: true }
    suspend fun setFloatingCounterEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.FLOATING_COUNTER_ENABLED] = enabled }
    }

    val floatingCounterSize: Flow<String> = dataStore.data.map { it[Keys.FLOATING_COUNTER_SIZE] ?: "medium" }
    suspend fun setFloatingCounterSize(size: String) {
        dataStore.edit { it[Keys.FLOATING_COUNTER_SIZE] = size }
    }

    val floatingCounterShowMascot: Flow<Boolean> = dataStore.data.map { it[Keys.FLOATING_COUNTER_SHOW_MASCOT] ?: true }
    suspend fun setFloatingCounterShowMascot(show: Boolean) {
        dataStore.edit { it[Keys.FLOATING_COUNTER_SHOW_MASCOT] = show }
    }

    val floatingCounterExpandedDefault: Flow<Boolean> = dataStore.data.map { it[Keys.FLOATING_COUNTER_EXPANDED_DEFAULT] ?: false }
    suspend fun setFloatingCounterExpandedDefault(expanded: Boolean) {
        dataStore.edit { it[Keys.FLOATING_COUNTER_EXPANDED_DEFAULT] = expanded }
    }

    val floatingCounterPosX: Flow<Int> = dataStore.data.map { it[Keys.FLOATING_COUNTER_POS_X] ?: 24 }
    val floatingCounterPosY: Flow<Int> = dataStore.data.map { it[Keys.FLOATING_COUNTER_POS_Y] ?: 220 }
    suspend fun setFloatingCounterPosition(x: Int, y: Int) {
        dataStore.edit {
            it[Keys.FLOATING_COUNTER_POS_X] = x
            it[Keys.FLOATING_COUNTER_POS_Y] = y
        }
    }

    val floatingCounterAnimation: Flow<Boolean> = dataStore.data.map { it[Keys.FLOATING_COUNTER_ANIMATION] ?: true }
    suspend fun setFloatingCounterAnimation(enabled: Boolean) {
        dataStore.edit { it[Keys.FLOATING_COUNTER_ANIMATION] = enabled }
    }

    // ─── Hard Limit, Auto-Exit Consent, Focus Schedule & Break Reminders ─
    val limitEnforcementPolicy: Flow<String> = dataStore.data.map { it[Keys.LIMIT_ENFORCEMENT_POLICY] ?: "focus" }
    suspend fun setLimitEnforcementPolicy(policy: String) {
        dataStore.edit { it[Keys.LIMIT_ENFORCEMENT_POLICY] = policy }
    }

    val autoExitConsentGranted: Flow<Boolean> = dataStore.data.map { it[Keys.AUTO_EXIT_CONSENT_GRANTED] ?: true }
    suspend fun setAutoExitConsentGranted(granted: Boolean) {
        dataStore.edit { it[Keys.AUTO_EXIT_CONSENT_GRANTED] = granted }
    }

    val strictModeConsentGranted: Flow<Boolean> = dataStore.data.map { it[Keys.STRICT_MODE_CONSENT_GRANTED] ?: false }
    suspend fun setStrictModeConsentGranted(granted: Boolean) {
        dataStore.edit { it[Keys.STRICT_MODE_CONSENT_GRANTED] = granted }
    }

    val warningThresholdPercent: Flow<Float> = dataStore.data.map { it[Keys.WARNING_THRESHOLD_PERCENT] ?: 0.8f }
    suspend fun setWarningThresholdPercent(percent: Float) {
        dataStore.edit { it[Keys.WARNING_THRESHOLD_PERCENT] = percent.coerceIn(0.5f, 0.95f) }
    }

    val dailyDurationLimitMinutes: Flow<Int> = dataStore.data.map { it[Keys.DAILY_DURATION_LIMIT_MINUTES] ?: 0 }
    suspend fun setDailyDurationLimitMinutes(minutes: Int) {
        dataStore.edit { it[Keys.DAILY_DURATION_LIMIT_MINUTES] = minutes.coerceAtLeast(0) }
    }

    val focusScheduleEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.FOCUS_SCHEDULE_ENABLED] ?: false }
    val focusScheduleStartHour: Flow<Int> = dataStore.data.map { it[Keys.FOCUS_SCHEDULE_START_HOUR] ?: 22 }
    val focusScheduleEndHour: Flow<Int> = dataStore.data.map { it[Keys.FOCUS_SCHEDULE_END_HOUR] ?: 6 }
    suspend fun setFocusSchedule(enabled: Boolean, startHour: Int, endHour: Int) {
        dataStore.edit {
            it[Keys.FOCUS_SCHEDULE_ENABLED] = enabled
            it[Keys.FOCUS_SCHEDULE_START_HOUR] = startHour.coerceIn(0, 23)
            it[Keys.FOCUS_SCHEDULE_END_HOUR] = endHour.coerceIn(0, 23)
        }
    }

    val breakReminderEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.BREAK_REMINDER_ENABLED] ?: true }
    val breakReminderInterval: Flow<Int> = dataStore.data.map { it[Keys.BREAK_REMINDER_INTERVAL] ?: 25 }
    suspend fun setBreakReminder(enabled: Boolean, intervalCount: Int) {
        dataStore.edit {
            it[Keys.BREAK_REMINDER_ENABLED] = enabled
            it[Keys.BREAK_REMINDER_INTERVAL] = intervalCount.coerceIn(10, 100)
        }
    }

    val snoozeUntilTimestampMs: Flow<Long> = dataStore.data.map { it[Keys.SNOOZE_UNTIL_TIMESTAMP_MS] ?: 0L }
    suspend fun setSnoozeUntilTimestampMs(timestampMs: Long) {
        dataStore.edit { it[Keys.SNOOZE_UNTIL_TIMESTAMP_MS] = timestampMs }
    }

    // ─── Daily Reset & Clock Tracking ────────────────────────────────────
    val lastActiveDate: Flow<String> = dataStore.data.map { it[Keys.LAST_ACTIVE_DATE] ?: "" }
    val lastWallClockMs: Flow<Long> = dataStore.data.map { it[Keys.LAST_WALL_CLOCK_MS] ?: 0L }
    val lastElapsedRealtimeMs: Flow<Long> = dataStore.data.map { it[Keys.LAST_ELAPSED_REALTIME_MS] ?: 0L }

    suspend fun updateClockCheckpoint(dateStr: String, wallClockMs: Long, elapsedRealtimeMs: Long) {
        dataStore.edit {
            it[Keys.LAST_ACTIVE_DATE] = dateStr
            it[Keys.LAST_WALL_CLOCK_MS] = wallClockMs
            it[Keys.LAST_ELAPSED_REALTIME_MS] = elapsedRealtimeMs
        }
    }
}
