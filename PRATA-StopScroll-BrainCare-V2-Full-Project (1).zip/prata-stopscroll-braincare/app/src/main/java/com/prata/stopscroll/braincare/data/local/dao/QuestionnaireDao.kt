package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.QuestionnaireResponse
import kotlinx.coroutines.flow.Flow

@Dao
interface QuestionnaireDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(response: QuestionnaireResponse): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(responses: List<QuestionnaireResponse>)

    @Update
    suspend fun update(response: QuestionnaireResponse)

    @Delete
    suspend fun delete(response: QuestionnaireResponse)

    @Query("SELECT * FROM questionnaire_responses WHERE category = :category ORDER BY answeredAt DESC")
    fun getByCategory(category: String): Flow<List<QuestionnaireResponse>>

    @Query("SELECT * FROM questionnaire_responses WHERE questionKey = :questionKey ORDER BY version DESC LIMIT 1")
    suspend fun getLatestByKey(questionKey: String): QuestionnaireResponse?

    @Query("SELECT * FROM questionnaire_responses ORDER BY answeredAt DESC")
    fun getAll(): Flow<List<QuestionnaireResponse>>

    @Query("SELECT * FROM questionnaire_responses WHERE category = :category AND version = (SELECT MAX(version) FROM questionnaire_responses WHERE category = :category)")
    fun getLatestByCategory(category: String): Flow<List<QuestionnaireResponse>>

    @Query("SELECT DISTINCT category FROM questionnaire_responses")
    fun getCompletedCategories(): Flow<List<String>>

    @Query("DELETE FROM questionnaire_responses WHERE category = :category")
    suspend fun deleteByCategory(category: String)
}
