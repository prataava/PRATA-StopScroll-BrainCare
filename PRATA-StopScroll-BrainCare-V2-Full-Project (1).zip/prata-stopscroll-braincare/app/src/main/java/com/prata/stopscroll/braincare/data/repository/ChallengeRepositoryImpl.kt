package com.prata.stopscroll.braincare.data.repository

import com.prata.stopscroll.braincare.data.local.dao.ChallengeDao
import com.prata.stopscroll.braincare.data.local.entity.ChallengeProgress
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository managing challenge creation, progress tracking,
 * and streak management.
 */
@Singleton
class ChallengeRepositoryImpl @Inject constructor(
    private val challengeDao: ChallengeDao
) {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ─── Challenge CRUD ──────────────────────────────────────────────────

    suspend fun createChallenge(
        challengeType: String,
        durationDays: Int,
        targetDailyLimit: Int
    ): Long {
        val today = Calendar.getInstance()
        val startDate = dateFormat.format(today.time)
        today.add(Calendar.DAY_OF_YEAR, durationDays - 1)
        val endDate = dateFormat.format(today.time)

        val challenge = ChallengeProgress(
            challengeType = challengeType,
            startDate = startDate,
            endDate = endDate,
            targetDailyLimit = targetDailyLimit
        )
        return challengeDao.insert(challenge)
    }

    suspend fun getChallenge(id: Long): ChallengeProgress? =
        challengeDao.getById(id)

    suspend fun updateChallenge(challenge: ChallengeProgress) =
        challengeDao.update(challenge)

    suspend fun deleteChallenge(challenge: ChallengeProgress) =
        challengeDao.delete(challenge)

    // ─── Active Challenges ───────────────────────────────────────────────

    fun getActiveChallenges(): Flow<List<ChallengeProgress>> =
        challengeDao.getActiveChallenges()

    suspend fun getActiveChallenge(): ChallengeProgress? =
        challengeDao.getActiveChallenge()

    fun observeActiveChallenge(): Flow<ChallengeProgress?> =
        challengeDao.observeActiveChallenge()

    fun getAllChallenges(): Flow<List<ChallengeProgress>> =
        challengeDao.getAll()

    fun getCompletedChallenges(): Flow<List<ChallengeProgress>> =
        challengeDao.getCompleted()

    // ─── Progress Tracking ───────────────────────────────────────────────

    /**
     * Records a successful day in the challenge, incrementing the streak.
     * Also updates the best streak if the current streak is now the highest.
     */
    suspend fun recordDayCompleted(challengeId: Long) {
        challengeDao.incrementDayCompleted(challengeId)
        // Fetch updated challenge to check if best streak should be updated
        val challenge = challengeDao.getById(challengeId) ?: return
        challengeDao.updateBestStreakIfHigher(challengeId, challenge.currentStreak)

        // Check if challenge is fully completed
        val totalDays = challenge.daysCompleted + challenge.daysFailed
        val startCal = Calendar.getInstance().apply {
            time = dateFormat.parse(challenge.startDate) ?: return
        }
        val endCal = Calendar.getInstance().apply {
            time = dateFormat.parse(challenge.endDate) ?: return
        }
        val challengeDays = ((endCal.timeInMillis - startCal.timeInMillis) / (24 * 60 * 60 * 1000)).toInt() + 1
        if (totalDays >= challengeDays) {
            challengeDao.markCompleted(challengeId)
        }
    }

    /**
     * Records a failed day in the challenge, resetting the current streak to zero.
     */
    suspend fun recordDayFailed(challengeId: Long) {
        challengeDao.incrementDayFailed(challengeId)
        // Check if challenge is fully completed
        val challenge = challengeDao.getById(challengeId) ?: return
        val totalDays = challenge.daysCompleted + challenge.daysFailed
        val startCal = Calendar.getInstance().apply {
            time = dateFormat.parse(challenge.startDate) ?: return
        }
        val endCal = Calendar.getInstance().apply {
            time = dateFormat.parse(challenge.endDate) ?: return
        }
        val challengeDays = ((endCal.timeInMillis - startCal.timeInMillis) / (24 * 60 * 60 * 1000)).toInt() + 1
        if (totalDays >= challengeDays) {
            challengeDao.markCompleted(challengeId)
        }
    }

    suspend fun markChallengeCompleted(challengeId: Long) =
        challengeDao.markCompleted(challengeId)

    // ─── Stats ───────────────────────────────────────────────────────────

    fun getOverallBestStreak(): Flow<Int?> =
        challengeDao.getOverallBestStreak()

    /**
     * Calculates the completion percentage for a challenge.
     * Returns a value between 0f and 1f.
     */
    fun calculateProgress(challenge: ChallengeProgress): Float {
        val totalDays = challenge.daysCompleted + challenge.daysFailed
        if (totalDays == 0) return 0f
        val startCal = Calendar.getInstance().apply {
            time = dateFormat.parse(challenge.startDate) ?: return 0f
        }
        val endCal = Calendar.getInstance().apply {
            time = dateFormat.parse(challenge.endDate) ?: return 0f
        }
        val challengeDays = ((endCal.timeInMillis - startCal.timeInMillis) / (24 * 60 * 60 * 1000)).toInt() + 1
        return if (challengeDays > 0) totalDays.toFloat() / challengeDays else 0f
    }

    /**
     * Calculates the success rate for a challenge.
     * Returns a value between 0f and 1f.
     */
    fun calculateSuccessRate(challenge: ChallengeProgress): Float {
        val totalDays = challenge.daysCompleted + challenge.daysFailed
        return if (totalDays > 0) challenge.daysCompleted.toFloat() / totalDays else 0f
    }
}
