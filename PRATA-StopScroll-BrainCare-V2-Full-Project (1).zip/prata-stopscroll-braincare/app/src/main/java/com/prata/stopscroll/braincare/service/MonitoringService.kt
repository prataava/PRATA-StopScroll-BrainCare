package com.prata.stopscroll.braincare.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.prata.stopscroll.braincare.di.ServiceEntryPoint
import com.prata.stopscroll.braincare.util.Constants
import com.prata.stopscroll.braincare.util.DateUtils
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.*

class MonitoringService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var updateJob: Job? = null

    private val entryPoint: ServiceEntryPoint by lazy {
        EntryPointAccessors.fromApplication(
            applicationContext,
            ServiceEntryPoint::class.java
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startMonitoringForeground()
            }
        }
        return START_STICKY
    }

    private fun startMonitoringForeground() {
        val notifHelper = entryPoint.notificationHelper()
        val initialNotif = notifHelper.buildMonitoringNotification(0, Constants.DEFAULT_DAILY_LIMIT)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                0
            }
            ServiceCompat.startForeground(
                this,
                Constants.NOTIF_ID_MONITORING,
                initialNotif,
                fgsType
            )
        } else {
            startForeground(Constants.NOTIF_ID_MONITORING, initialNotif)
        }

        startPeriodicNotificationUpdates()
    }

    private fun startPeriodicNotificationUpdates() {
        updateJob?.cancel()
        updateJob = serviceScope.launch {
            while (isActive) {
                try {
                    val today = DateUtils.today()
                    val count = entryPoint.usageRepository().getShortContentCountForDate(today)
                    val limit = entryPoint.statsRepository().getOrCreateDailyLimit(today).totalLimit

                    val notif = entryPoint.notificationHelper().buildMonitoringNotification(count, limit)
                    val notifManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    notifManager.notify(Constants.NOTIF_ID_MONITORING, notif)
                } catch (_: Exception) {
                }
                delay(15_000L) // Refresh every 15 seconds
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        updateJob?.cancel()
        serviceScope.cancel()
    }

    companion object {
        const val ACTION_START = "com.prata.stopscroll.braincare.action.START_MONITORING"
        const val ACTION_STOP = "com.prata.stopscroll.braincare.action.STOP_MONITORING"

        fun start(context: Context) {
            val intent = Intent(context, MonitoringService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, MonitoringService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
