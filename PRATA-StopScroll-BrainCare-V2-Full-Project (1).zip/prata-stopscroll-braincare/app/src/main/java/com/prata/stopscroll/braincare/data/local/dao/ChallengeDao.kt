package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.ChallengeProgress
import kotlinx.coroutines.flow.Flow

@Dao
interface ChallengeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(challenge: ChallengeProgress): Long

    @Update
    suspend fun update(challenge: ChallengeProgress)

    @Delete
    suspend fun delete(challenge: ChallengeProgress)

    @Query("SELECT * FROM challenge_progress WHERE id = :id")
    suspend fun getById(id: Long): ChallengeProgress?

    @Query("SELECT * FROM challenge_progress WHERE isActive = 1 ORDER BY startDate DESC")
    fun getActiveChallenges(): Flow<List<ChallengeProgress>>

    @Query("SELECT * FROM challenge_progress WHERE isActive = 1 ORDER BY startDate DESC LIMIT 1")
    suspend fun getActiveChallenge(): ChallengeProgress?

    @Query("SELECT * FROM challenge_progress WHERE isActive = 1 ORDER BY startDate DESC LIMIT 1")
    fun observeActiveChallenge(): Flow<ChallengeProgress?>

    @Query("SELECT * FROM challenge_progress ORDER BY startDate DESC")
    fun getAll(): Flow<List<ChallengeProgress>>

    @Query("SELECT * FROM challenge_progress WHERE isActive = 0 ORDER BY completedAt DESC")
    fun getCompleted(): Flow<List<ChallengeProgress>>

    @Query("UPDATE challenge_progress SET daysCompleted = daysCompleted + 1, currentStreak = currentStreak + 1 WHERE id = :id")
    suspend fun incrementDayCompleted(id: Long)

    @Query("UPDATE challenge_progress SET daysFailed = daysFailed + 1, currentStreak = 0 WHERE id = :id")
    suspend fun incrementDayFailed(id: Long)

    @Query("UPDATE challenge_progress SET bestStreak = :streak WHERE id = :id AND bestStreak < :streak")
    suspend fun updateBestStreakIfHigher(id: Long, streak: Int)

    @Query("UPDATE challenge_progress SET isActive = 0, completedAt = :completedAt WHERE id = :id")
    suspend fun markCompleted(id: Long, completedAt: Long = System.currentTimeMillis())

    @Query("SELECT MAX(bestStreak) FROM challenge_progress")
    fun getOverallBestStreak(): Flow<Int?>
}
