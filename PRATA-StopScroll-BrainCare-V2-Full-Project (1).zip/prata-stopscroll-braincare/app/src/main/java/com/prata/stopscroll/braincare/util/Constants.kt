package com.prata.stopscroll.braincare.util

object Constants {
    // Target Application Package Names
    const val PKG_INSTAGRAM = "com.instagram.android"
    const val PKG_INSTAGRAM_LITE = "com.instagram.lite"
    const val PKG_YOUTUBE = "com.google.android.youtube"
    const val PKG_FACEBOOK = "com.facebook.katana"
    const val PKG_FACEBOOK_LITE = "com.facebook.lite"
    const val PKG_TIKTOK = "com.zhiliaoapp.musically"
    const val PKG_TIKTOK_ALT = "com.ss.android.ugc.trill"
    const val PKG_TIKTOK_LITE = "com.zhiliaoapp.musically.go"
    const val PKG_SNAPCHAT = "com.snapchat.android"

    // Target Apps Map: PackageName -> Display Name
    val TARGET_APPS = mapOf(
        PKG_TIKTOK to "TikTok",
        PKG_TIKTOK_ALT to "TikTok",
        PKG_TIKTOK_LITE to "TikTok Lite",
        PKG_INSTAGRAM to "Instagram Reels",
        PKG_INSTAGRAM_LITE to "Instagram Lite",
        PKG_YOUTUBE to "YouTube Shorts",
        PKG_FACEBOOK to "Facebook Reels",
        PKG_FACEBOOK_LITE to "Facebook Lite",
        PKG_SNAPCHAT to "Snapchat Spotlight"
    )

    // Primary selectable packages for UI lists (deduplicated display entries)
    val PRIMARY_SELECTABLE_APPS = linkedMapOf(
        PKG_TIKTOK to "TikTok",
        PKG_INSTAGRAM to "Instagram Reels",
        PKG_YOUTUBE to "YouTube Shorts",
        PKG_FACEBOOK to "Facebook Reels",
        PKG_SNAPCHAT to "Snapchat Spotlight"
    )

    // Content Types
    const val TYPE_REEL = "REEL"
    const val TYPE_SHORT = "SHORT"
    const val TYPE_TIKTOK = "TIKTOK"
    const val TYPE_SPOTLIGHT = "SPOTLIGHT"
    const val TYPE_UNKNOWN = "UNKNOWN"

    // Deduplication & Tracking Tuning
    const val DEDUP_COOLDOWN_MS = 850L
    const val MIN_CONTENT_VIEW_TIME_MS = 1500L
    const val DEFAULT_DAILY_LIMIT = 100
    const val WARNING_THRESHOLD_PERCENT = 0.8f // 80% of limit
    const val DEFAULT_BREAK_REMINDER_COUNT = 25 // Remind every 25 short videos

    // Notification Channels
    const val CHANNEL_MONITORING = "prata_channel_monitoring"
    const val CHANNEL_ALERTS = "prata_channel_alerts"
    const val CHANNEL_INSIGHTS = "prata_channel_insights"
    const val CHANNEL_FOCUS = "prata_channel_focus"

    // Notification IDs
    const val NOTIF_ID_MONITORING = 1001
    const val NOTIF_ID_LIMIT_WARNING = 1002
    const val NOTIF_ID_LIMIT_REACHED = 1003
    const val NOTIF_ID_INSIGHT = 1004
    const val NOTIF_ID_FOCUS = 1005
    const val NOTIF_ID_BREAK_REMINDER = 1006

    // WorkManager Unique Work Names
    const val WORK_DAILY_RESET = "prata_daily_reset_work"
    const val WORK_INSIGHT_GEN = "prata_insight_gen_work"

    // Preferences & Limits Defaults
    const val DEFAULT_FOCUS_MINUTES = 25
    const val DEFAULT_BREAK_MINUTES = 5
    const val SNOOZE_DURATION_MS = 5 * 60 * 1000L // 5 minutes mindful extension
}
