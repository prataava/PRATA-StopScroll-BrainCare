package com.prata.stopscroll.braincare.domain.ai

import com.prata.stopscroll.braincare.data.repository.AIRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.PreferencesRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.UsageRepositoryImpl
import com.prata.stopscroll.braincare.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Privacy-first AI Coach engine for PRATA StopScroll BrainCare (Requirement H).
 *
 * - Never embeds secret API keys in the APK.
 * - Never transmits data to external cloud providers without explicit user opt-in consent.
 * - Provides a rich, deterministic Local Analytics AI Coach powered by real Room database records
 *   when cloud provider is unconfigured or offline.
 */
@Singleton
class AIProviderManager @Inject constructor(
    private val usageRepository: UsageRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl,
    private val preferencesRepository: PreferencesRepositoryImpl,
    private val aiRepository: AIRepositoryImpl,
    private val behaviorAnalyzer: BehaviorAnalyzer,
    private val habitAlgorithm: HabitAlgorithm,
    private val predictionEngine: PredictionEngine
) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .build()

    data class CloudProviderStatus(
        val isCloudEnabled: Boolean,
        val hasUserConsent: Boolean,
        val isEndpointConfigured: Boolean,
        val statusLabel: String
    )

    suspend fun getCloudStatus(): CloudProviderStatus {
        val enabled = preferencesRepository.aiCloudEnabled.first()
        val consent = preferencesRepository.aiCloudConsent.first()
        val endpoint = preferencesRepository.aiCloudEndpoint.first()
        val configured = endpoint.isNotBlank()

        val label = when {
            !enabled || !consent -> "Mode Analitik Lokal Aktif • 100% Data di Perangkat"
            !configured -> "AI Cloud Aktif (Endpoint Belum Dikonfigurasi • Menggunakan Analitik Lokal)"
            else -> "AI Cloud Terhubung (Dengan Persetujuan Pengguna)"
        }
        return CloudProviderStatus(
            isCloudEnabled = enabled,
            hasUserConsent = consent,
            isEndpointConfigured = configured,
            statusLabel = label
        )
    }

    suspend fun getResponseForQuery(
        conversationId: Long,
        userQuery: String,
        cloudEndpoint: String? = null,
        cloudApiKey: String? = null,
        cloudModel: String = "gemini-1.5-flash"
    ): String {
        val today = DateUtils.today()
        val currentCount = usageRepository.getShortContentCountForDate(today)
        val dailyLimitObj = statsRepository.getOrCreateDailyLimit(today)
        val dailyLimit = dailyLimitObj.totalLimit
        val topApps = usageRepository.getContentCountByAppForDate(today)
        val baseline = habitAlgorithm.calculateBaseline()
        val prediction = predictionEngine.predictTodayLimitExceedance()

        val cloudConsent = preferencesRepository.aiCloudConsent.first()
        val cloudEnabled = preferencesRepository.aiCloudEnabled.first()
        val configuredEndpoint = cloudEndpoint ?: preferencesRepository.aiCloudEndpoint.first()

        // Only send data to external AI cloud if user explicitly consented AND configured endpoint + key
        if (cloudEnabled && cloudConsent && !configuredEndpoint.isNullOrBlank() && !cloudApiKey.isNullOrBlank()) {
            try {
                return callCloudProvider(
                    userQuery = userQuery,
                    todayCount = currentCount,
                    dailyLimit = dailyLimit,
                    endpoint = configuredEndpoint,
                    apiKey = cloudApiKey,
                    model = cloudModel
                )
            } catch (e: Exception) {
                val localResponse = generateLocalAIResponse(userQuery, currentCount, dailyLimit, topApps, baseline, prediction)
                return "*(Provider AI Cloud tidak merespons: ${e.localizedMessage ?: "offline"} — Beralih ke Analitik Lokal PRATA)*\n\n$localResponse"
            }
        }

        return generateLocalAIResponse(userQuery, currentCount, dailyLimit, topApps, baseline, prediction)
    }

    private suspend fun generateLocalAIResponse(
        query: String,
        currentCount: Int,
        dailyLimit: Int,
        topApps: List<com.prata.stopscroll.braincare.data.local.dao.AppCount>,
        baseline: HabitAlgorithm.HabitBaseline,
        prediction: PredictionEngine.ScrollPrediction
    ): String {
        val lower = query.lowercase()
        val percentUsed = if (dailyLimit > 0) ((currentCount.toFloat() / dailyLimit) * 100).toInt() else 0

        return when {
            lower.contains("hari ini") || lower.contains("berapa") || lower.contains("statistik") -> {
                val appBreakdown = if (topApps.isNotEmpty()) {
                    topApps.joinToString("\n") { app ->
                        val share = if (currentCount > 0) ((app.count.toFloat() / currentCount) * 100).toInt() else 0
                        "• **${app.appName}**: ${app.count} konten ($share%)"
                    }
                } else {
                    "• Belum ada konten pendek yang terdeteksi hari ini."
                }
                """
                📊 **Analisis Data Nyata Hari Ini (${DateUtils.today()})**
                • Total Konten Pendek: **$currentCount** dari batas **$dailyLimit** ($percentUsed%)
                • Status Batas: ${if (currentCount >= dailyLimit) "🛑 Batas Harian Tercapai" else if (percentUsed >= 80) "⚠️ Mendekati Batas" else "✅ Masih Dalam Batas Aman"}

                📱 **Aplikasi Paling Banyak Digunakan**:
                $appBreakdown

                🔮 **Proyeksi Akhir Hari**:
                ${prediction.explanation}
                """.trimIndent()
            }

            lower.contains("aplikasi") || lower.contains("paling banyak") || lower.contains("dominan") -> {
                if (topApps.isEmpty()) {
                    "Hari ini belum ada aplikasi video pendek yang tercatat di database. Saat kamu menggunakan TikTok, Instagram Reels, atau YouTube Shorts, PRATA akan menghitung distribusi setiap aplikasi secara akurat."
                } else {
                    val top = topApps.first()
                    val share = if (currentCount > 0) ((top.count.toFloat() / currentCount) * 100).toInt() else 100
                    val listText = topApps.joinToString("\n") { "• **${it.appName}**: ${it.count} video" }
                    """
                    📱 **Analisis Aplikasi Dominan**
                    Aplikasi yang paling banyak menyita perhatianmu hari ini adalah **${top.appName}** dengan **${top.count} konten pendek** ($share% dari total scrolling hari ini).

                    **Rincian Lengkap Hari Ini**:
                    $listText

                    💡 **Saran Personal**:
                    Tetapkan batas spesifik aplikasi untuk **${top.appName}** sebesar **${(top.count * 0.8f).toInt().coerceAtLeast(15)} konten/hari** di menu Pengaturan agar konsumsinyatidak mendominasi waktu fokusmu.
                    """.trimIndent()
                }
            }

            lower.contains("jam") || lower.contains("kapan") || lower.contains("waktu") || lower.contains("aktif") -> {
                val peakInfo = if (baseline.peakHours.isNotEmpty()) {
                    baseline.peakHours.joinToString(", ") { DateUtils.getHourLabel(it) }
                } else {
                    "Belum cukup riwayat jam puncak hari ini"
                }
                """
                ⏰ **Analisis Waktu Paling Aktif**
                • Jam Puncak Scrolling: **$peakInfo**
                • Periode Risiko Utama: **${baseline.highRiskPeriod}**
                • Rata-rata Harian (Baseline): **${baseline.baselineDailyCount} konten/hari**

                💡 **Strategi Pencegahan**:
                Aktifkan **Jadwal Bebas Scrolling** 15 menit sebelum jam puncakmu ($peakInfo) agar PRATA mengaktifkan perisai fokus sebelum kebiasaan scrolling dimulai.
                """.trimIndent()
            }

            lower.contains("banding") || lower.contains("minggu") || lower.contains("tren") -> {
                val trendSign = if (baseline.weeklyChangePercent > 0) "+${baseline.weeklyChangePercent}%" else "${baseline.weeklyChangePercent}%"
                val trendVerdict = when {
                    baseline.previousWeekTotal == 0 -> "Minggu lalu belum memiliki catatan penuh untuk perbandingan."
                    baseline.weeklyChangePercent < -10 -> "Bagus sekali! Konsumsi konten pendekmu turun signifikan dibanding minggu lalu."
                    baseline.weeklyChangePercent > 10 -> "Perhatian: Konsumsi konten pendek minggu ini meningkat dibanding minggu lalu."
                    else -> "Pola scrolling minggu ini relatif stabil dibanding minggu lalu."
                }
                """
                📈 **Perbandingan Statistik Mingguan**
                • Total 7 Hari Terakhir: **${baseline.currentWeekTotal} konten**
                • Total 7 Hari Sebelumnya: **${baseline.previousWeekTotal} konten**
                • Perubahan Mingguan: **$trendSign**
                • Rata-rata Harian Saat Ini: **${baseline.baselineDailyCount} konten/hari**

                **Kesimpulan**:
                $trendVerdict
                """.trimIndent()
            }

            lower.contains("efektif") || lower.contains("pengingat") || lower.contains("evaluasi") || lower.contains("membantu") -> {
                """
                🎯 **Evaluasi Efektivitas Pengingat & Strategi**
                • Tingkat Kepatuhan Pengingat/Rekomendasi: **${baseline.reminderEffectivenessPercent}%** (${baseline.remindersAcceptedCount} tindakan positif dari ${baseline.remindersTotalCount} pencatatan)
                • Strategi Adaptif Saat Ini: **${baseline.adaptiveStrategyName}**

                **Rekomendasi Penyesuaian Strategi**:
                ${
                    if (baseline.reminderEffectivenessPercent >= 70) {
                        "Pengingat saat ini terbukti efektif membantumu berhenti! Kamu siap menurunkan target harian ke **${baseline.recommendedDailyTarget} konten/hari**."
                    } else {
                        "Kamu cukup sering melewati pengingat biasa. Saya menyarankan beralih ke **Mode Fokus** atau **Mode Ketat** di Pengaturan agar layar pembatas membantumu berhenti secara tegas saat batas tercapai."
                    }
                }
                """.trimIndent()
            }

            lower.contains("target") || lower.contains("batas") || lower.contains("rekomendasi") || lower.contains("strategi") -> {
                val topApp = topApps.firstOrNull()?.appName ?: "aplikasi video pendek"
                """
                🎯 **Rekomendasi Target & Strategi Personal**
                Berdasarkan rata-rata aktualmu (**${baseline.baselineDailyCount} konten/hari**) dan penggunaan hari ini (**$currentCount konten**):

                1. **Target Harian yang Disarankan**: Tetapkan batas **${baseline.recommendedDailyTarget} konten/hari** (penurunan bertahap 15% agar realistis dan tidak memicu efek balas dendam).
                2. **Kendalikan $topApp**: Gunakan fitur *Batas Per Aplikasi* dan aktifkan pengingat istirahat setiap **25 konten**.
                3. **Strategi Adaptif**: **${baseline.adaptiveStrategyName}**.
                """.trimIndent()
            }

            else -> {
                val topAppText = topApps.firstOrNull()?.let { "${it.appName} (${it.count} konten)" } ?: "belum ada aplikasi dominan"
                """
                Halo! Saya **PRATA AI Coach** (Mode Analitik Lokal • Data Nyata Database).

                📌 **Ringkasan Statusmu Saat Ini**:
                • Hari Ini: **$currentCount / $dailyLimit konten** ($percentUsed%)
                • Aplikasi Teratas: **$topAppText**
                • Jam Paling Aktif: **${if (baseline.peakHours.isNotEmpty()) baseline.peakHours.joinToString(", ") { DateUtils.getHourLabel(it) } else "Sedang dianalisis"}**
                • Target Rekomendasi: **${baseline.recommendedDailyTarget} konten/hari**
                • Efektivitas Pengingat: **${baseline.reminderEffectivenessPercent}%**

                Silakan pilih topik di bawah atau tanyakan tentang **jam aktif**, **perbandingan mingguan**, **evaluasi pengingat**, atau **rekomendasi target baru**!
                """.trimIndent()
            }
        }
    }

    private suspend fun callCloudProvider(
        userQuery: String,
        todayCount: Int,
        dailyLimit: Int,
        endpoint: String,
        apiKey: String,
        model: String
    ): String = withContext(Dispatchers.IO) {
        val payload = JSONObject().apply {
            put("model", model)
            val messages = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", "You are PRATA AI Coach, a digital wellbeing assistant. Current user stats: today's short content = $todayCount, daily limit = $dailyLimit. Give concise, encouraging, actionable digital wellbeing advice in Indonesian based strictly on these numbers.")
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", userQuery)
                })
            }
            put("messages", messages)
            put("max_tokens", 500)
            put("temperature", 0.7)
        }

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = httpClient.newCall(request).execute()
        val body = response.body?.string() ?: throw Exception("Empty response from AI provider")

        if (!response.isSuccessful) {
            throw Exception("HTTP ${response.code}")
        }

        val json = JSONObject(body)
        val choices = json.getJSONArray("choices")
        if (choices.length() > 0) {
            val message = choices.getJSONObject(0).getJSONObject("message")
            message.getString("content")
        } else {
            "Tidak dapat memproses jawaban dari penyedia AI."
        }
    }
}
