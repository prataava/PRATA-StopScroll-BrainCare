package com.prata.stopscroll.braincare.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.prata.stopscroll.braincare.domain.state.FloatingCounterSize
import com.prata.stopscroll.braincare.domain.state.LimitEnforcementPolicy
import com.prata.stopscroll.braincare.ui.components.getSocialAppIconRes
import com.prata.stopscroll.braincare.ui.theme.WarmOrange
import com.prata.stopscroll.braincare.ui.theme.WarmPink
import com.prata.stopscroll.braincare.util.Constants
import com.prata.stopscroll.braincare.util.PermissionUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var showStrictConsentDialog by remember { mutableStateOf(false) }
    var pendingLimitConfirm by remember { mutableStateOf<Int?>(null) }
    var draftDailyLimit by remember(uiState.dailyLimit) { mutableIntStateOf(uiState.dailyLimit) }
    var showTroubleshootingGuide by remember { mutableStateOf(false) }
    var showPerAppLimitsSection by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.checkPermissions()
    }

    // Explicit Consent Dialog for Mode Ketat (Section 3.D requirement)
    if (showStrictConsentDialog) {
        AlertDialog(
            onDismissRequest = { showStrictConsentDialog = false },
            title = { Text("Persetujuan Mode Ketat & Keluar Otomatis") },
            text = {
                Text(
                    "Dalam Mode Ketat:\n" +
                            "1. Saat batas tercapai, PRATA akan mengarahkanmu keluar dari aplikasi target ke Home screen (GLOBAL_ACTION_HOME) dan menampilkan layar pembatas.\n" +
                            "2. Jika kamu mencoba membuka kembali aplikasi target selama batas masih aktif, pembatas dan pengalihan keluar akan tetap dipertahankan.\n" +
                            "3. Panggilan darurat, telepon, dan Pengaturan Android tidak pernah diblokir.\n\n" +
                            "Cara Menonaktifkan Kapan Saja:\n" +
                            "• Buka aplikasi PRATA → Pengaturan → ubah ke Mode Pengingat/Mode Blokir, ATAU\n" +
                            "• Buka Pengaturan Android → Aksesibilitas → matikan layanan PRATA StopScroll."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateEnforcementPolicy(LimitEnforcementPolicy.STRICT)
                        showStrictConsentDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WarmOrange)
                ) {
                    Text("Saya Setuju & Aktifkan Mode Ketat")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStrictConsentDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    pendingLimitConfirm?.let { targetLimit ->
        AlertDialog(
            onDismissRequest = {
                pendingLimitConfirm = null
                draftDailyLimit = uiState.dailyLimit
            },
            title = { Text("Konfirmasi Perubahan Batas Harian") },
            text = {
                Text(
                    "Apakah kamu yakin ingin mengubah batas harian dari ${uiState.dailyLimit} menjadi $targetLimit konten pendek? Konfirmasi ini mencegah perubahan impulsif saat sedang scrolling."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateDailyLimit(targetLimit)
                        pendingLimitConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WarmOrange)
                ) {
                    Text("Ya, Simpan Batas")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pendingLimitConfirm = null
                        draftDailyLimit = uiState.dailyLimit
                    }
                ) {
                    Text("Batal")
                }
            }
        )
    }

    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text("Hapus Seluruh Data?") },
            text = { Text("Tindakan ini akan menghapus permanen semua riwayat scrolling, sesi fokus, insight, dan chat AI dari perangkatmu.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllData()
                        showClearConfirmDialog = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Ya, Hapus Semua")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Pengaturan, Pembatas & Privasi",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            uiState.exportSuccessMessage?.let { msg ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = msg, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            IconButton(onClick = { viewModel.dismissMessages() }) {
                                Icon(Icons.Filled.Close, contentDescription = "Close")
                            }
                        }
                    }
                }
            }

            uiState.diagnosticReport?.let { report ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Laporan Diagnostik Service",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                IconButton(onClick = { viewModel.dismissMessages() }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Close")
                                }
                            }
                            Text(text = report, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            uiState.dataClearedMessage?.let { msg ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = msg, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            IconButton(onClick = { viewModel.dismissMessages() }) {
                                Icon(Icons.Filled.Close, contentDescription = "Close")
                            }
                        }
                    }
                }
            }

            // ─── Section 1: Batas Harian & 3 Mode Pembatasan ─────────────────
            item {
                Text(
                    text = "Sistem Batas & Mode Pembatasan (Keluar Otomatis)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Batas Konten Pendek Harian",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "$draftDailyLimit video",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = WarmOrange
                            )
                        }

                        Slider(
                            value = draftDailyLimit.toFloat(),
                            onValueChange = { draftDailyLimit = it.toInt() },
                            onValueChangeFinished = {
                                if (draftDailyLimit != uiState.dailyLimit) {
                                    pendingLimitConfirm = draftDailyLimit
                                }
                            },
                            valueRange = 20f..300f,
                            steps = 27
                        )

                        HorizontalDivider()

                        Text(
                            text = "Pilih Mode Pembatasan Saat Limit Tercapai:",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )

                        LimitEnforcementPolicy.entries.forEach { policy ->
                            val selected = uiState.enforcementPolicy == policy
                            val onSelectPolicy = {
                                if (policy == LimitEnforcementPolicy.STRICT && !uiState.strictModeConsentGranted) {
                                    showStrictConsentDialog = true
                                } else {
                                    viewModel.updateEnforcementPolicy(policy)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectPolicy() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    RadioButton(
                                        selected = selected,
                                        onClick = { onSelectPolicy() }
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = policy.title,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = policy.description,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        // Auto-Exit to Home Screen Consent Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Arahkan Keluar Otomatis ke Home Screen",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                                )
                                Text(
                                    text = "Menjalankan GLOBAL_ACTION_HOME otomatis saat batas tercapai pada Mode Blokir / Mode Ketat.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = uiState.autoExitConsentGranted,
                                onCheckedChange = { viewModel.setAutoExitConsent(it) }
                            )
                        }

                        HorizontalDivider()

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Ambang Peringatan Dini", style = MaterialTheme.typography.bodyMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(0.7f to "70%", 0.8f to "80%", 0.9f to "90%").forEach { (pct, label) ->
                                    FilterChip(
                                        selected = kotlin.math.abs(uiState.warningThresholdPercent - pct) < 0.03f,
                                        onClick = { viewModel.updateWarningThreshold(pct) },
                                        label = { Text(label) }
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Batas Durasi Harian", style = MaterialTheme.typography.bodyMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(0 to "Nonaktif", 30 to "30m", 60 to "60m", 90 to "90m").forEach { (mins, label) ->
                                    FilterChip(
                                        selected = uiState.dailyDurationLimitMinutes == mins,
                                        onClick = { viewModel.updateDurationLimitMinutes(mins) },
                                        label = { Text(label) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ─── Section 2: Pengaturan Floating Counter Otomatis ─────────────
            item {
                Text(
                    text = "Indikator Floating Counter Otomatis",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Tampilkan Floating Counter Otomatis",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                                )
                                Text(
                                    text = "Muncul otomatis saat mendeteksi Reels, Shorts & TikTok, dan sembunyi di aplikasi lain.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = uiState.floatingCounterEnabled,
                                onCheckedChange = { viewModel.setFloatingCounterEnabled(it) }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Ukuran Indikator", style = MaterialTheme.typography.bodyMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FloatingCounterSize.entries.forEach { size ->
                                    FilterChip(
                                        selected = uiState.floatingCounterSize == size,
                                        onClick = { viewModel.setFloatingCounterSize(size) },
                                        label = { Text(size.label) }
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Tampilkan Ikon Maskot Otak PRATA", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = uiState.floatingCounterShowMascot,
                                onCheckedChange = { viewModel.setFloatingCounterShowMascot(it) }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Kurangi Animasi (Reduced Motion)", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = uiState.reducedMotion,
                                onCheckedChange = {
                                    viewModel.setReducedMotion(it)
                                    viewModel.setFloatingCounterAnimation(!it)
                                }
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.resetFloatingCounterPosition() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reset Posisi Floating Counter ke Default")
                        }
                    }
                }
            }

            // ─── Section 3: Jadwal Bebas Scrolling & Pengingat Istirahat ─────
            item {
                Text(
                    text = "Jadwal Fokus & Pengingat Istirahat",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Jadwal Bebas Scrolling Malam (${String.format("%02d:00", uiState.focusScheduleStartHour)} - ${String.format("%02d:00", uiState.focusScheduleEndHour)})",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                                )
                                Text(
                                    text = "Aktifkan pembatas otomatis selama jam istirahat tidur.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = uiState.focusScheduleEnabled,
                                onCheckedChange = {
                                    viewModel.updateFocusSchedule(it, uiState.focusScheduleStartHour, uiState.focusScheduleEndHour)
                                }
                            )
                        }

                        HorizontalDivider()

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Pengingat Istirahat Setiap ${uiState.breakReminderInterval} Video",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                                )
                                Text(
                                    text = "Ingatkan istirahat mata saat menonton berturut-turut.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = uiState.breakReminderEnabled,
                                onCheckedChange = {
                                    viewModel.updateBreakReminder(it, uiState.breakReminderInterval)
                                }
                            )
                        }
                    }
                }
            }

            // ─── Section 4: Aplikasi Target, Batas Per Aplikasi & Pengecualian
            item {
                Text(
                    text = "Aplikasi Target, Batas Per Aplikasi & Pengecualian",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Constants.PRIMARY_SELECTABLE_APPS.forEach { (pkg, name) ->
                            val perAppLim = uiState.perAppLimits[pkg] ?: 0
                            val isExempted = uiState.exemptedApps.contains(pkg)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Image(
                                            painter = painterResource(id = getSocialAppIconRes(pkg)),
                                            contentDescription = name,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Column {
                                            Text(text = name, style = MaterialTheme.typography.bodyLarge)
                                            val subLabel = when {
                                                isExempted -> "Dikecualikan sementara oleh pengguna"
                                                perAppLim > 0 -> "Batas khusus: $perAppLim video/hari"
                                                else -> "Mengikuti batas total harian"
                                            }
                                            Text(
                                                text = subLabel,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isExempted) WarmPink else WarmOrange
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = uiState.selectedApps.contains(pkg) && !isExempted,
                                        onCheckedChange = { viewModel.toggleAppSelection(pkg) }
                                    )
                                }

                                if (showPerAppLimitsSection) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf(0 to "Global", 30 to "30", 50 to "50", 80 to "80").forEach { (lim, lbl) ->
                                            FilterChip(
                                                selected = perAppLim == lim && !isExempted,
                                                onClick = { viewModel.updatePerAppLimit(pkg, lim) },
                                                label = { Text(lbl, style = MaterialTheme.typography.labelSmall) }
                                            )
                                        }
                                        FilterChip(
                                            selected = isExempted,
                                            onClick = { viewModel.toggleExemptedApp(pkg) },
                                            label = { Text("Kecualikan", style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                }
                            }
                        }

                        TextButton(
                            onClick = { showPerAppLimitsSection = !showPerAppLimitsSection },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text(if (showPerAppLimitsSection) "Sembunyikan Opsi Lanjutan" else "Atur Batas Per Aplikasi & Pengecualian")
                        }
                    }
                }
            }

            // ─── Section 5: Diagnostik Izin Sistem & Troubleshooting ──────────
            item {
                Text(
                    text = "Diagnostik Service & Troubleshooting Izin",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PermissionStatusRow(
                            title = "Accessibility Service (Deteksi, Overlay & Auto-Exit)",
                            isGranted = uiState.isAccessibilityGranted,
                            onFix = { PermissionUtils.openAccessibilitySettings(context) }
                        )

                        HorizontalDivider()

                        PermissionStatusRow(
                            title = "Usage Access (Durasi Penggunaan)",
                            isGranted = uiState.isUsageAccessGranted,
                            onFix = { PermissionUtils.openUsageStatsSettings(context) }
                        )

                        HorizontalDivider()

                        PermissionStatusRow(
                            title = "Notifikasi & Peringatan Batas",
                            isGranted = uiState.isNotificationGranted,
                            onFix = { PermissionUtils.openNotificationSettings(context) }
                        )

                        Button(
                            onClick = { viewModel.runServiceDiagnostics() },
                            colors = ButtonDefaults.buttonColors(containerColor = WarmOrange),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.BugReport, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Jalankan Diagnostik Status Service")
                        }

                        OutlinedButton(
                            onClick = { showTroubleshootingGuide = !showTroubleshootingGuide },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.HelpOutline, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (showTroubleshootingGuide) "Tutup Panduan Troubleshooting" else "Panduan Troubleshooting Izin Android 13–15")
                        }

                        AnimatedVisibility(visible = showTroubleshootingGuide) {
                            Column(
                                modifier = Modifier.padding(top = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Cara Mengatasi 'Pengaturan Terbatas' (Restricted Settings) di Android 13/14/15:",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = WarmPink
                                )
                                Text(
                                    text = "1. Buka Pengaturan HP → Aplikasi → PRATA StopScroll.\n" +
                                            "2. Ketuk ikon titik tiga (⋮) di pojok kanan atas halaman Info Aplikasi.\n" +
                                            "3. Pilih 'Izinkan pengaturan terbatas' (Allow restricted settings) dan verifikasi PIN/sidik jari.\n" +
                                            "4. Kembali ke Pengaturan → Aksesibilitas → Aplikasi Terinstal → Aktifkan PRATA StopScroll.\n" +
                                            "5. Matikan penghemat baterai ketat untuk PRATA agar service tidak dihentikan sistem.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // ─── Section 6: AI & Privasi Data ────────────────────────────────
            item {
                Text(
                    text = "AI & Privasi Data",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Persetujuan Mode AI Cloud (Opt-In)",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = if (uiState.aiCloudEnabled)
                                        "Aktif atas persetujuanmu (otomatis kembali ke analitik lokal jika provider belum dikonfigurasi)"
                                    else "Nonaktif • 100% pemrosesan AI berjalan lokal di perangkat tanpa mengirim data keluar",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = uiState.aiCloudEnabled,
                                onCheckedChange = { viewModel.setAiCloudEnabled(it) }
                            )
                        }
                    }
                }
            }

            // ─── Section 7: Ekspor (CSV/PDF) & Backup / Restore ───────────────
            item {
                Text(
                    text = "Ekspor Laporan (CSV & PDF) • Backup & Restore",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.exportData("CSV") },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.TableChart, contentDescription = "CSV")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Ekspor CSV")
                            }

                            OutlinedButton(
                                onClick = { viewModel.exportData("PDF") },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.PictureAsPdf, contentDescription = "PDF")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Ekspor PDF")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.exportData("BACKUP") },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.CloudDownload, contentDescription = "Backup")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Backup Data")
                            }

                            OutlinedButton(
                                onClick = { viewModel.restoreFromLatestBackup() },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.Restore, contentDescription = "Restore")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Restore Data")
                            }
                        }

                        Button(
                            onClick = { showClearConfirmDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = "Hapus")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Hapus Seluruh Data Lokal")
                        }
                    }
                }
            }

            // ─── About Section ───────────────────────────────────────────────
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "PRATA StopScroll BrainCare v2.0.0",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Package: com.prata.stopscroll.braincare\nArsitektur Local-First • Multi-Signal Scroll Detection • Live Floating Counter • Auto-Exit Hard Limit.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }
}

@Composable
fun PermissionStatusRow(
    title: String,
    isGranted: Boolean,
    onFix: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = if (isGranted) "Aktif & Terverifikasi" else "Belum Diaktifkan",
                style = MaterialTheme.typography.labelSmall,
                color = if (isGranted) Color(0xFF4CAF50) else MaterialTheme.colorScheme.error
            )
        }

        if (!isGranted) {
            TextButton(onClick = onFix) {
                Text("Aktifkan")
            }
        } else {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = "Granted",
                tint = Color(0xFF4CAF50),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
