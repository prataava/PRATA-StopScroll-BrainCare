package com.prata.stopscroll.braincare.ui.challenge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prata.stopscroll.braincare.data.local.entity.ChallengeProgress
import com.prata.stopscroll.braincare.data.repository.ChallengeRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.util.DateUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChallengeUiState(
    val activeChallenge: ChallengeProgress? = null,
    val completedChallenges: List<ChallengeProgress> = emptyList(),
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val totalFocusMinutes: Int = 0,
    val totalDaysUnderLimit: Int = 0,
    val todayCompleted: Boolean = false
)

@HiltViewModel
class ChallengeViewModel @Inject constructor(
    private val challengeRepository: ChallengeRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChallengeUiState())
    val uiState: StateFlow<ChallengeUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    fun loadData() {
        viewModelScope.launch {
            val today = DateUtils.today()
            val start30 = DateUtils.daysAgo(30)
            val active = challengeRepository.getActiveChallenge()
            val completed = challengeRepository.getCompletedChallenges().firstOrNull() ?: emptyList()
            val todayLimit = statsRepository.getOrCreateDailyLimit(today)
            val maxDailyStreak = statsRepository.getMaxStreak().firstOrNull() ?: 0
            val overallBest = challengeRepository.getOverallBestStreak().firstOrNull() ?: 0
            val focusMins = statsRepository.getTotalFocusMinutesRange(start30, today) ?: 0
            val daysUnder = statsRepository.getDaysUnderLimit(start30, today)

            _uiState.update {
                it.copy(
                    activeChallenge = active,
                    completedChallenges = completed,
                    currentStreak = maxOf(active?.currentStreak ?: 0, maxDailyStreak),
                    bestStreak = maxOf(active?.bestStreak ?: 0, overallBest, maxDailyStreak),
                    totalFocusMinutes = focusMins,
                    totalDaysUnderLimit = daysUnder,
                    todayCompleted = !todayLimit.limitReached
                )
            }
        }
    }

    fun startChallenge(type: String, durationDays: Int, targetDailyLimit: Int) {
        viewModelScope.launch {
            challengeRepository.createChallenge(
                challengeType = type,
                durationDays = durationDays,
                targetDailyLimit = targetDailyLimit
            )
            loadData()
        }
    }

    fun cancelActiveChallenge(challenge: ChallengeProgress) {
        viewModelScope.launch {
            challengeRepository.updateChallenge(challenge.copy(isActive = false))
            loadData()
        }
    }
}
