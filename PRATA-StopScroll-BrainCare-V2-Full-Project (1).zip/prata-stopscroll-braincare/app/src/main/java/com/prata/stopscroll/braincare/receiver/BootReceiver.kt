package com.prata.stopscroll.braincare.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.prata.stopscroll.braincare.di.ServiceEntryPoint
import com.prata.stopscroll.braincare.service.MonitoringService
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val pendingResult = goAsync()
            val scope = CoroutineScope(Dispatchers.IO)

            scope.launch {
                try {
                    val entryPoint = EntryPointAccessors.fromApplication(
                        context.applicationContext,
                        ServiceEntryPoint::class.java
                    )
                    val trackingEnabled = entryPoint.preferencesRepository().trackingEnabled.first()
                    if (trackingEnabled) {
                        MonitoringService.start(context.applicationContext)
                    }
                } catch (_: Exception) {
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
