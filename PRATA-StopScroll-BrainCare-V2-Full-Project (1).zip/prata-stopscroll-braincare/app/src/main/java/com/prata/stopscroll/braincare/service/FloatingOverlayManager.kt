package com.prata.stopscroll.braincare.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.prata.stopscroll.braincare.MainActivity
import com.prata.stopscroll.braincare.domain.state.FloatingCounterSize
import com.prata.stopscroll.braincare.domain.state.LimitEnforcementPolicy
import com.prata.stopscroll.braincare.domain.state.LiveTrackingSnapshot
import com.prata.stopscroll.braincare.domain.state.MascotMoodState
import com.prata.stopscroll.braincare.domain.state.SystemTrackingState
import com.prata.stopscroll.braincare.util.PermissionUtils
import kotlin.math.abs

/**
 * Manages both the live context-aware Floating Counter ("[Maskot PRATA] 78 / 100")
 * and the Hard Limit Full-Screen Blocking Overlay (Requirements D, E, F, J, K).
 *
 * Uses TYPE_ACCESSIBILITY_OVERLAY when attached to ScrollAccessibilityService
 * (with fallback to TYPE_APPLICATION_OVERLAY if overlay permission is granted).
 * Updates views in-place on the main thread to guarantee zero flickering during scroll events.
 */
class FloatingOverlayManager(
    private val serviceContext: Context,
    private val onPositionSaved: (x: Int, y: Int) -> Unit,
    private val onTemporaryHideRequested: () -> Unit,
    private val onExitTargetAppRequested: () -> Unit,
    private val onSnoozeConfirmed: () -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? =
        serviceContext.getSystemService(Context.WINDOW_SERVICE) as? WindowManager

    // Floating Counter Window Views
    private var floatingRootView: FrameLayout? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private var mascotView: PrataMascotCanvasView? = null
    private var countTextView: TextView? = null
    private var statusBadgeTextView: TextView? = null
    private var progressBar: ProgressBar? = null
    private var expandedDetailsLayout: LinearLayout? = null
    private var appDetailTextView: TextView? = null
    private var isFloatingAttached: Boolean = false
    private var lastDisplayedCount: Int = -1

    // Hard Limit Blocking Overlay Window Views
    private var blockingRootView: FrameLayout? = null
    private var blockingParams: WindowManager.LayoutParams? = null
    private var blockingMascotView: PrataMascotCanvasView? = null
    private var blockingTitleText: TextView? = null
    private var blockingSubtitleText: TextView? = null
    private var blockingCounterPillText: TextView? = null
    private var blockingPolicyBadgeText: TextView? = null
    private var snoozeButton: Button? = null
    private var isBlockingAttached: Boolean = false
    private var snoozeCountdownAnimator: ValueAnimator? = null
    private var isSnoozeUnlocked: Boolean = false

    // Customization state
    private var counterEnabled: Boolean = true
    private var counterSize: FloatingCounterSize = FloatingCounterSize.MEDIUM
    private var showMascot: Boolean = true
    private var enableAnimations: Boolean = true
    private var savedPosX: Int = 24
    private var savedPosY: Int = 220

    fun updatePreferences(
        enabled: Boolean,
        size: FloatingCounterSize,
        showMascotIcon: Boolean,
        animationsEnabled: Boolean,
        posX: Int,
        posY: Int
    ) {
        mainHandler.post {
            counterEnabled = enabled
            counterSize = size
            showMascot = showMascotIcon
            enableAnimations = animationsEnabled
            savedPosX = posX
            savedPosY = posY
            mascotView?.visibility = if (showMascot) View.VISIBLE else View.GONE
            applySizeScale()
        }
    }

    /**
     * Synchronizes both the floating counter and blocking overlay with the authoritative state machine snapshot.
     */
    fun renderSnapshot(snapshot: LiveTrackingSnapshot) {
        mainHandler.post {
            val shouldShowFloating = counterEnabled &&
                    snapshot.isFloatingOverlayVisible &&
                    snapshot.isTrackingEnabled &&
                    snapshot.isShortFormContext &&
                    snapshot.systemState != SystemTrackingState.TARGET_APP_INACTIVE &&
                    snapshot.systemState != SystemTrackingState.PERMISSION_MISSING &&
                    snapshot.systemState != SystemTrackingState.SERVICE_UNAVAILABLE

            if (shouldShowFloating) {
                showOrUpdateFloatingCounter(snapshot)
            } else {
                hideFloatingCounter()
            }

            val shouldShowBlocking = snapshot.isBlockingOverlayVisible &&
                    snapshot.isShortFormContext &&
                    snapshot.systemState == SystemTrackingState.BLOCKING_ACTIVE

            if (shouldShowBlocking) {
                showOrUpdateBlockingOverlay(snapshot)
            } else {
                hideBlockingOverlay()
            }
        }
    }

    private fun resolveOverlayWindowType(): Int {
        // When Context is an AccessibilityService, TYPE_ACCESSIBILITY_OVERLAY is always permitted
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            } catch (_: Exception) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            }
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun ensureFloatingViewCreated() {
        if (floatingRootView != null) return

        val dp = { value: Float ->
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                serviceContext.resources.displayMetrics
            ).toInt()
        }

        val root = FrameLayout(serviceContext)
        val cardContainer = LinearLayout(serviceContext).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22f).toFloat()
                setColor(Color.parseColor("#EE1E1E1E")) // Premium charcoal translucent
                setStroke(dp(1.5f), Color.parseColor("#E8854A"))
            }
            setPadding(dp(12f), dp(8f), dp(14f), dp(8f))
            elevation = dp(6f).toFloat()
        }

        // Top compact row: [PRATA Brain Mascot] 78 / 100
        val topRow = LinearLayout(serviceContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val mascot = PrataMascotCanvasView(serviceContext).apply {
            layoutParams = LinearLayout.LayoutParams(dp(28f), dp(28f)).apply {
                marginEnd = dp(8f)
            }
            visibility = if (showMascot) View.VISIBLE else View.GONE
        }
        mascotView = mascot
        topRow.addView(mascot)

        val textColumn = LinearLayout(serviceContext).apply {
            orientation = LinearLayout.VERTICAL
        }

        val counterLabel = TextView(serviceContext).apply {
            text = "0 / 100"
            setTextColor(Color.parseColor("#FFF8F0")) // Warm cream
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        countTextView = counterLabel
        textColumn.addView(counterLabel)

        val statusLabel = TextView(serviceContext).apply {
            text = "PRATA Aktif"
            setTextColor(Color.parseColor("#E07B8B")) // Mascot pink
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        }
        statusBadgeTextView = statusLabel
        textColumn.addView(statusLabel)

        topRow.addView(textColumn)
        cardContainer.addView(topRow)

        // Smooth slim progress bar
        val progress = ProgressBar(serviceContext, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 0
            layoutParams = LinearLayout.LayoutParams(dp(96f), dp(4f)).apply {
                topMargin = dp(5f)
            }
        }
        progressBar = progress
        cardContainer.addView(progress)

        // Expandable mini-controls section (shown when user taps the pill)
        val expandedBox = LinearLayout(serviceContext).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8f)
            }
        }

        val appInfoText = TextView(serviceContext).apply {
            setTextColor(Color.parseColor("#CCCCCC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            text = "Konten pendek terdeteksi"
        }
        appDetailTextView = appInfoText
        expandedBox.addView(appInfoText)

        val actionsRow = LinearLayout(serviceContext).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(6f)
            }
        }

        val hideBtn = TextView(serviceContext).apply {
            text = "Sembunyikan"
            setTextColor(Color.parseColor("#FFD4B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            background = GradientDrawable().apply {
                cornerRadius = dp(10f).toFloat()
                setColor(Color.parseColor("#33FFFFFF"))
            }
            setOnClickListener {
                onTemporaryHideRequested()
            }
        }

        val openAppBtn = TextView(serviceContext).apply {
            text = "Dashboard"
            setTextColor(Color.parseColor("#1E1E1E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(6f)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(10f).toFloat()
                setColor(Color.parseColor("#E8854A"))
            }
            setOnClickListener {
                openDashboardActivity()
            }
        }

        actionsRow.addView(hideBtn)
        actionsRow.addView(openAppBtn)
        expandedBox.addView(actionsRow)

        expandedDetailsLayout = expandedBox
        cardContainer.addView(expandedBox)
        root.addView(cardContainer)

        // Touch listener for smooth drag-and-move + tap to expand/collapse
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        cardContainer.setOnTouchListener { _, event ->
            val params = floatingParams ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > dp(6f) || abs(dy) > dp(6f)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = (initialX + dx).coerceAtLeast(0)
                        params.y = (initialY + dy).coerceAtLeast(dp(40f))
                        safeUpdateViewLayout(root, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        // Toggle mini vs expanded mode
                        val nextVis = if (expandedBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                        expandedBox.visibility = nextVis
                    } else {
                        // Snap horizontally to nearest screen edge so it doesn't block center video content
                        val screenWidth = serviceContext.resources.displayMetrics.widthPixels
                        val targetX = if (params.x + (root.width / 2) < screenWidth / 2) {
                            dp(12f)
                        } else {
                            (screenWidth - root.width - dp(12f)).coerceAtLeast(dp(12f))
                        }
                        params.x = targetX
                        safeUpdateViewLayout(root, params)
                        savedPosX = params.x
                        savedPosY = params.y
                        onPositionSaved(savedPosX, savedPosY)
                    }
                    true
                }
                else -> false
            }
        }

        floatingRootView = root
        applySizeScale()
    }

    private fun applySizeScale() {
        val root = floatingRootView ?: return
        val scale = counterSize.scaleFactor
        root.scaleX = scale
        root.scaleY = scale
    }

    private fun showOrUpdateFloatingCounter(snapshot: LiveTrackingSnapshot) {
        val wm = windowManager ?: return
        ensureFloatingViewCreated()
        val root = floatingRootView ?: return

        if (!isFloatingAttached) {
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                resolveOverlayWindowType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = savedPosX
                y = savedPosY
            }
            floatingParams = params
            try {
                wm.addView(root, params)
                isFloatingAttached = true
                if (enableAnimations) {
                    root.alpha = 0f
                    root.animate()
                        .alpha(1f)
                        .setDuration(220L)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                } else {
                    root.alpha = 1f
                }
            } catch (_: Exception) {
                // Fallback to TYPE_APPLICATION_OVERLAY if needed and granted
                if (PermissionUtils.isOverlayPermissionGranted(serviceContext) &&
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ) {
                    try {
                        params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        wm.addView(root, params)
                        isFloatingAttached = true
                    } catch (_: Exception) {
                    }
                }
            }
        }

        // Update values in-place without recreating window (zero flicker!)
        val newText = "${snapshot.todayShortCount} / ${snapshot.dailyLimit}"
        if (countTextView?.text?.toString() != newText) {
            countTextView?.text = newText
            if (enableAnimations && lastDisplayedCount >= 0 && snapshot.todayShortCount > lastDisplayedCount) {
                countTextView?.animate()
                    ?.scaleX(1.16f)
                    ?.scaleY(1.16f)
                    ?.setDuration(130L)
                    ?.withEndAction {
                        countTextView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(130L)?.start()
                    }
                    ?.start()
            }
            lastDisplayedCount = snapshot.todayShortCount
        }

        mascotView?.setMood(snapshot.mascotMood)

        val statusText = when (snapshot.systemState) {
            SystemTrackingState.LIMIT_REACHED, SystemTrackingState.BLOCKING_ACTIVE -> "Batas Tercapai!"
            SystemTrackingState.LIMIT_WARNING -> "Hampir Batas (${(snapshot.progressRatio * 100).toInt()}%)"
            SystemTrackingState.TRACKING_PAUSED -> "Tracking Dijeda"
            else -> snapshot.activeAppName ?: "PRATA Aktif"
        }
        statusBadgeTextView?.text = statusText
        statusBadgeTextView?.setTextColor(
            when (snapshot.mascotMood) {
                MascotMoodState.OVERLOADED -> Color.parseColor("#FF6B6B")
                MascotMoodState.TIRED -> Color.parseColor("#FFA726")
                MascotMoodState.FOCUSED -> Color.parseColor("#E07B8B")
                MascotMoodState.FRESH -> Color.parseColor("#81C784")
                MascotMoodState.RESTING -> Color.parseColor("#9E9E9E")
            }
        )

        val targetProgress = (snapshot.progressRatio * 1000).toInt().coerceIn(0, 1000)
        progressBar?.progress = targetProgress

        val perAppText = if (snapshot.activeAppDailyLimit != null && snapshot.activeAppDailyLimit > 0) {
            "${snapshot.activeAppName ?: "Aplikasi"}: ${snapshot.activeAppTodayCount}/${snapshot.activeAppDailyLimit} video"
        } else {
            "${snapshot.activeAppName ?: "Aplikasi"}: ${snapshot.activeAppTodayCount} video hari ini"
        }
        appDetailTextView?.text = "$perAppText\nStatus: ${snapshot.mascotMood.label}"
    }

    fun hideFloatingCounter() {
        val wm = windowManager ?: return
        val root = floatingRootView ?: return
        if (!isFloatingAttached) return

        try {
            wm.removeViewImmediate(root)
        } catch (_: Exception) {
        } finally {
            isFloatingAttached = false
        }
    }

    // ─── Hard Limit Blocking Overlay (Requirement E) ─────────────────────

    private fun ensureBlockingOverlayCreated() {
        if (blockingRootView != null) return

        val dp = { value: Float ->
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                serviceContext.resources.displayMetrics
            ).toInt()
        }

        val root = FrameLayout(serviceContext).apply {
            setBackgroundColor(Color.parseColor("#F4141414")) // Deep charcoal blocking shield
            isClickable = true
            isFocusable = true
        }

        val card = LinearLayout(serviceContext).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28f).toFloat()
                setColor(Color.parseColor("#1F1F1F"))
                setStroke(dp(2f), Color.parseColor("#E8854A"))
            }
            setPadding(dp(24f), dp(28f), dp(24f), dp(24f))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ).apply {
                marginStart = dp(24f)
                marginEnd = dp(24f)
            }
        }

        val policyBadge = TextView(serviceContext).apply {
            text = "MODE FOKUS PRATA"
            setTextColor(Color.parseColor("#141414"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12f), dp(4f), dp(12f), dp(4f))
            background = GradientDrawable().apply {
                cornerRadius = dp(12f).toFloat()
                setColor(Color.parseColor("#E8854A"))
            }
        }
        blockingPolicyBadgeText = policyBadge
        card.addView(policyBadge)

        val mascot = PrataMascotCanvasView(serviceContext).apply {
            layoutParams = LinearLayout.LayoutParams(dp(84f), dp(84f)).apply {
                topMargin = dp(16f)
                bottomMargin = dp(12f)
            }
            setMood(MascotMoodState.OVERLOADED)
        }
        blockingMascotView = mascot
        card.addView(mascot)

        val title = TextView(serviceContext).apply {
            text = "Batas Scrolling Tercapai!"
            setTextColor(Color.parseColor("#FFF8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        blockingTitleText = title
        card.addView(title)

        val counterPill = TextView(serviceContext).apply {
            text = "100 / 100 Konten Pendek"
            setTextColor(Color.parseColor("#FF94A5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14f), dp(6f), dp(14f), dp(6f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8f)
                bottomMargin = dp(10f)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(16f).toFloat()
                setColor(Color.parseColor("#33E07B8B"))
            }
        }
        blockingCounterPillText = counterPill
        card.addView(counterPill)

        val subtitle = TextView(serviceContext).apply {
            text = "Otakmu butuh istirahat dari dopamin cepat. Berhenti sekarang dan kembalikan fokusmu."
            setTextColor(Color.parseColor("#CCCCCC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            setPadding(dp(8f), 0, dp(8f), dp(20f))
        }
        blockingSubtitleText = subtitle
        card.addView(subtitle)

        // Primary Action: Exit Target App (Navigate Home)
        val exitBtn = Button(serviceContext).apply {
            text = "Keluar dari Aplikasi Sekarang"
            setTextColor(Color.parseColor("#141414"))
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            background = GradientDrawable().apply {
                cornerRadius = dp(16f).toFloat()
                setColor(Color.parseColor("#E8854A"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(48f)
            ).apply {
                bottomMargin = dp(10f)
            }
            setOnClickListener {
                onExitTargetAppRequested()
            }
        }
        card.addView(exitBtn)

        // Secondary Action: Open PRATA Dashboard
        val dashboardBtn = Button(serviceContext).apply {
            text = "Buka Dashboard PRATA"
            setTextColor(Color.parseColor("#FFF8F0"))
            isAllCaps = false
            background = GradientDrawable().apply {
                cornerRadius = dp(16f).toFloat()
                setColor(Color.parseColor("#2E2E2E"))
                setStroke(dp(1f), Color.parseColor("#E07B8B"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(46f)
            ).apply {
                bottomMargin = dp(10f)
            }
            setOnClickListener {
                openDashboardActivity()
            }
        }
        card.addView(dashboardBtn)

        // Conditional Snooze Button (Only visible in FOCUS policy, requires 5s mindful delay)
        val snoozeBtn = Button(serviceContext).apply {
            text = "Tunda 5 Menit (Ketuk untuk Konfirmasi Sadar)"
            setTextColor(Color.parseColor("#A0A0A0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            isAllCaps = false
            background = GradientDrawable().apply {
                cornerRadius = dp(14f).toFloat()
                setColor(Color.TRANSPARENT)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(42f)
            )
            setOnClickListener {
                handleMindfulSnoozeClick(this)
            }
        }
        snoozeButton = snoozeBtn
        card.addView(snoozeBtn)

        root.addView(card)
        blockingRootView = root
    }

    private fun handleMindfulSnoozeClick(button: Button) {
        if (isSnoozeUnlocked) {
            isSnoozeUnlocked = false
            onSnoozeConfirmed()
            return
        }
        if (snoozeCountdownAnimator?.isRunning == true) return

        snoozeCountdownAnimator = ValueAnimator.ofInt(5, 0).apply {
            duration = 5000L
            addUpdateListener { anim ->
                val sec = anim.animatedValue as Int
                if (sec > 0) {
                    button.text = "Tarik napas... Konfirmasi buka dalam ${sec}d"
                }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    isSnoozeUnlocked = true
                    button.text = "Ketuk Sekali Lagi untuk Tunda 5 Menit"
                    button.setTextColor(Color.parseColor("#FFD4B8"))
                }
            })
            start()
        }
    }

    private fun showOrUpdateBlockingOverlay(snapshot: LiveTrackingSnapshot) {
        val wm = windowManager ?: return
        ensureBlockingOverlayCreated()
        val root = blockingRootView ?: return

        if (!isBlockingAttached) {
            isSnoozeUnlocked = false
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                resolveOverlayWindowType(),
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }
            blockingParams = params
            try {
                wm.addView(root, params)
                isBlockingAttached = true
            } catch (_: Exception) {
                if (PermissionUtils.isOverlayPermissionGranted(serviceContext) &&
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ) {
                    try {
                        params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        wm.addView(root, params)
                        isBlockingAttached = true
                    } catch (_: Exception) {
                    }
                }
            }
        }

        blockingPolicyBadgeText?.text = snapshot.enforcementPolicy.title.uppercase()
        blockingTitleText?.text = snapshot.blockingReason ?: "Batas Scrolling Harian Tercapai!"
        blockingCounterPillText?.text = "${snapshot.todayShortCount} / ${snapshot.dailyLimit} Konten Pendek Hari Ini"

        if (snapshot.enforcementPolicy == LimitEnforcementPolicy.STRICT) {
            snoozeButton?.visibility = View.GONE
            blockingSubtitleText?.text =
                "Mode Ketat aktif: Konten berikutnya dikunci agar kamu tidak terjebak doomscrolling. Pilih Keluar dari Aplikasi atau buka Dashboard PRATA."
        } else {
            snoozeButton?.visibility = View.VISIBLE
            if (snoozeCountdownAnimator?.isRunning != true && !isSnoozeUnlocked) {
                snoozeButton?.text = "Tunda 5 Menit (Ketuk untuk Konfirmasi Sadar)"
            }
            blockingSubtitleText?.text =
                "Kamu telah mencapai batas scrolling di ${snapshot.activeAppName ?: "aplikasi ini"}. Istirahatkan mata dan pikiranmu sekarang."
        }
    }

    fun hideBlockingOverlay() {
        val wm = windowManager ?: return
        val root = blockingRootView ?: return
        if (!isBlockingAttached) return

        snoozeCountdownAnimator?.cancel()
        isSnoozeUnlocked = false
        try {
            wm.removeViewImmediate(root)
        } catch (_: Exception) {
        } finally {
            isBlockingAttached = false
        }
    }

    fun destroyAllOverlays() {
        mainHandler.post {
            hideFloatingCounter()
            hideBlockingOverlay()
        }
    }

    private fun openDashboardActivity() {
        try {
            val intent = Intent(serviceContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            serviceContext.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    private fun safeUpdateViewLayout(view: View, params: WindowManager.LayoutParams) {
        try {
            if (isFloatingAttached) {
                windowManager?.updateViewLayout(view, params)
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * Custom Canvas view rendering the original PRATA Brain Mascot in real time
 * with mood-responsive expressions (Fresh, Focused, Tired, Overloaded, Resting).
 */
class PrataMascotCanvasView(context: Context) : View(context) {

    private var mood: MascotMoodState = MascotMoodState.FRESH
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val path = Path()

    fun setMood(newMood: MascotMoodState) {
        if (mood != newMood) {
            mood = newMood
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.44f

        // Background halo
        paint.style = Paint.Style.FILL
        paint.color = when (mood) {
            MascotMoodState.FRESH -> Color.parseColor("#2681C784")
            MascotMoodState.FOCUSED -> Color.parseColor("#26E07B8B")
            MascotMoodState.TIRED -> Color.parseColor("#26E8854A")
            MascotMoodState.OVERLOADED -> Color.parseColor("#33EF5350")
            MascotMoodState.RESTING -> Color.parseColor("#269E9E9E")
        }
        canvas.drawCircle(cx, cy, r * 1.1f, paint)

        // Left & right brain lobes (Mascot Pink + Warm Orange accents)
        val brainColor = when (mood) {
            MascotMoodState.OVERLOADED -> Color.parseColor("#EF5350")
            MascotMoodState.TIRED -> Color.parseColor("#E8854A")
            MascotMoodState.RESTING -> Color.parseColor("#9E9E9E")
            else -> Color.parseColor("#E07B8B")
        }
        paint.color = brainColor
        rect.set(cx - r, cy - r * 0.82f, cx + r * 0.1f, cy + r * 0.82f)
        canvas.drawRoundRect(rect, r * 0.6f, r * 0.6f, paint)

        rect.set(cx - r * 0.1f, cy - r * 0.82f, cx + r, cy + r * 0.82f)
        canvas.drawRoundRect(rect, r * 0.6f, r * 0.6f, paint)

        // Brain gyri folds
        strokePaint.color = Color.parseColor("#44141414")
        strokePaint.strokeWidth = (r * 0.09f).coerceAtLeast(1.5f)
        canvas.drawLine(cx, cy - r * 0.72f, cx, cy + r * 0.72f, strokePaint)

        // Eyes
        paint.color = Color.parseColor("#1E1E1E")
        val eyeY = cy - r * 0.1f
        val eyeOffsetX = r * 0.36f
        val eyeRadius = (r * 0.12f).coerceAtLeast(2f)

        if (mood == MascotMoodState.OVERLOADED) {
            // Dizzy/Warning X eyes
            strokePaint.color = Color.parseColor("#FFF8F0")
            strokePaint.strokeWidth = (r * 0.11f).coerceAtLeast(2f)
            val d = eyeRadius * 0.9f
            canvas.drawLine(cx - eyeOffsetX - d, eyeY - d, cx - eyeOffsetX + d, eyeY + d, strokePaint)
            canvas.drawLine(cx - eyeOffsetX + d, eyeY - d, cx - eyeOffsetX - d, eyeY + d, strokePaint)
            canvas.drawLine(cx + eyeOffsetX - d, eyeY - d, cx + eyeOffsetX + d, eyeY + d, strokePaint)
            canvas.drawLine(cx + eyeOffsetX + d, eyeY - d, cx + eyeOffsetX - d, eyeY + d, strokePaint)
        } else {
            canvas.drawCircle(cx - eyeOffsetX, eyeY, eyeRadius, paint)
            canvas.drawCircle(cx + eyeOffsetX, eyeY, eyeRadius, paint)
        }

        // Mouth expression
        strokePaint.color = Color.parseColor("#1E1E1E")
        strokePaint.strokeWidth = (r * 0.1f).coerceAtLeast(1.8f)
        path.reset()
        when (mood) {
            MascotMoodState.FRESH, MascotMoodState.FOCUSED -> {
                rect.set(cx - r * 0.25f, cy + r * 0.05f, cx + r * 0.25f, cy + r * 0.42f)
                canvas.drawArc(rect, 15f, 150f, false, strokePaint)
            }
            MascotMoodState.TIRED, MascotMoodState.RESTING -> {
                canvas.drawLine(cx - r * 0.22f, cy + r * 0.28f, cx + r * 0.22f, cy + r * 0.28f, strokePaint)
            }
            MascotMoodState.OVERLOADED -> {
                strokePaint.color = Color.parseColor("#FFF8F0")
                rect.set(cx - r * 0.25f, cy + r * 0.2f, cx + r * 0.25f, cy + r * 0.55f)
                canvas.drawArc(rect, 195f, 150f, false, strokePaint)
            }
        }
    }
}
