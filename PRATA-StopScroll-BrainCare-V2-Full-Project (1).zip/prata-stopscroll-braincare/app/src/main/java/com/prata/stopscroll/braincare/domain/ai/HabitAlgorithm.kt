package com.prata.stopscroll.braincare.domain.ai

import com.prata.stopscroll.braincare.data.repository.AIRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.PreferencesRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.UsageRepositoryImpl
import com.prata.stopscroll.braincare.util.DateUtils
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HabitAlgorithm @Inject constructor(
    private val statsRepository: StatsRepositoryImpl,
    private val usageRepository: UsageRepositoryImpl,
    private val aiRepository: AIRepositoryImpl,
    private val preferencesRepository: PreferencesRepositoryImpl
) {

    data class HabitBaseline(
        val baselineDailyCount: Int,
        val currentWeekTotal: Int,
        val previousWeekTotal: Int,
        val weeklyChangePercent: Int,
        val peakHours: List<Int>,
        val highRiskPeriod: String,
        val reminderEffectivenessPercent: Int,
        val remindersAcceptedCount: Int,
        val remindersTotalCount: Int,
        val recommendedDailyTarget: Int,
        val adaptiveStrategyName: String,
        val isDataSufficient: Boolean
    )

    suspend fun calculateBaseline(): HabitBaseline {
        val today = DateUtils.today()
        val sevenDaysAgo = DateUtils.daysAgo(6)
        val fourteenDaysAgo = DateUtils.daysAgo(13)
        val prevWeekEnd = DateUtils.daysAgo(7)

        val currentWeekStats = statsRepository.getDailyStatsRange(sevenDaysAgo, today).firstOrNull() ?: emptyList()
        val prevWeekStats = statsRepository.getDailyStatsRange(fourteenDaysAgo, prevWeekEnd).firstOrNull() ?: emptyList()

        val todayLiveCount = usageRepository.getShortContentCountForDate(today)
        val currentWeekTotal = currentWeekStats.filter { it.date != today }.sumOf { it.totalShortContent } + todayLiveCount
        val previousWeekTotal = prevWeekStats.sumOf { it.totalShortContent }

        val weeklyChangePercent = if (previousWeekTotal > 0) {
            (((currentWeekTotal - previousWeekTotal).toFloat() / previousWeekTotal) * 100).toInt()
        } else {
            0
        }

        val allValidDays = (prevWeekStats + currentWeekStats).filter { it.totalShortContent > 0 }
        val isSufficient = allValidDays.size >= 2 || todayLiveCount > 0

        val avgCount = when {
            allValidDays.isNotEmpty() -> allValidDays.map { it.totalShortContent }.average().toInt()
            todayLiveCount > 0 -> todayLiveCount
            else -> preferencesRepository.getOrCreateGoals().dailyLimit
        }

        // Peak hours analysis across the last 7 days
        val rangeHourly = usageRepository.getHourlyDistributionRange(sevenDaysAgo, today).firstOrNull() ?: emptyList()
        val peakHours = rangeHourly.sortedByDescending { it.count }.take(3).map { it.hour }

        val highRiskPeriod = when {
            peakHours.isEmpty() -> "Belum ada jam puncak tercatat"
            peakHours.any { it in 21..23 || it in 0..2 } -> "Larut Malam (21:00 - 02:00) — Risiko Doomscrolling Sebelum Tidur"
            peakHours.any { it in 6..9 } -> "Pagi Hari (06:00 - 09:00) — Distraksi Awal Hari"
            peakHours.any { it in 12..14 } -> "Siang Hari (12:00 - 14:00) — Sela Istirahat Siang"
            else -> "Sore Hari (16:00 - 20:00) — Transisi Pulang Kerja/Belajar"
        }

        // Evaluate whether reminders and recommendations actually helped (Requirement H)
        val acceptedRecs = aiRepository.getRecommendationsByStatus("ACCEPTED").firstOrNull() ?: emptyList()
        val dismissedRecs = aiRepository.getRecommendationsByStatus("DISMISSED").firstOrNull() ?: emptyList()
        val recentNotifs = statsRepository.getRecentNotifications(50).firstOrNull() ?: emptyList()

        val notifAccepted = recentNotifs.count { it.userAction == "ACCEPTED" }
        val notifSnoozed = recentNotifs.count { it.userAction == "SNOOZED" || it.userAction == "DISMISSED" }

        val totalAccepted = acceptedRecs.size + notifAccepted
        val totalEvaluated = totalAccepted + dismissedRecs.size + notifSnoozed
        val effectivenessPercent = if (totalEvaluated > 0) {
            ((totalAccepted.toFloat() / totalEvaluated) * 100).toInt().coerceIn(0, 100)
        } else {
            // Estimate from days under limit
            val daysUnder = statsRepository.getDaysUnderLimit(sevenDaysAgo, today)
            val totalRecordedDays = currentWeekStats.size.coerceAtLeast(1)
            ((daysUnder.toFloat() / totalRecordedDays) * 100).toInt().coerceIn(0, 100)
        }

        // Progressive target suggestion: 10-15% reduction from baseline, clamped between 30 and 200
        val currentLimit = preferencesRepository.getOrCreateGoals().dailyLimit
        val suggestedTarget = if (avgCount > 0) {
            (avgCount * 0.85f).toInt().coerceIn(30, currentLimit)
        } else {
            (currentLimit * 0.9f).toInt().coerceAtLeast(30)
        }

        // Adaptive strategy based on user feedback & effectiveness
        val adaptiveStrategy = when {
            effectivenessPercent >= 70 -> "Strategi Progresif Bertahap (Pengingat Lembut + Sesi Fokus)"
            effectivenessPercent in 40..69 -> "Strategi Pembatas Terstruktur (Mode Fokus + Jadwal Malam)"
            else -> "Strategi Intervensi Ketat (Mode Ketat + Batas Per Aplikasi)"
        }

        return HabitBaseline(
            baselineDailyCount = avgCount,
            currentWeekTotal = currentWeekTotal,
            previousWeekTotal = previousWeekTotal,
            weeklyChangePercent = weeklyChangePercent,
            peakHours = peakHours,
            highRiskPeriod = highRiskPeriod,
            reminderEffectivenessPercent = effectivenessPercent,
            remindersAcceptedCount = totalAccepted,
            remindersTotalCount = totalEvaluated,
            recommendedDailyTarget = suggestedTarget,
            adaptiveStrategyName = adaptiveStrategy,
            isDataSufficient = isSufficient
        )
    }
}
