package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ai_recommendations")
data class AIRecommendation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // FOCUS_MODE, REDUCE_LIMIT, SCHEDULE_BREAK, etc.
    val title: String,
    val description: String,
    val reasoning: String,
    val status: String = "PENDING", // PENDING, ACCEPTED, DISMISSED, COMPLETED
    val createdAt: Long = System.currentTimeMillis(),
    val respondedAt: Long? = null,
    val effectivenessScore: Float? = null
)
