package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "app_statistics",
    indices = [
        Index(value = ["date", "packageName"], unique = true)
    ]
)
data class AppStatistics(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val packageName: String,
    val appName: String,
    val shortContentCount: Int = 0,
    val usageMs: Long = 0,
    val sessionCount: Int = 0
)
