package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.BehaviorInsight
import kotlinx.coroutines.flow.Flow

@Dao
interface InsightDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(insight: BehaviorInsight): Long

    @Update
    suspend fun update(insight: BehaviorInsight)

    @Delete
    suspend fun delete(insight: BehaviorInsight)

    @Query("SELECT * FROM behavior_insights WHERE id = :id")
    suspend fun getById(id: Long): BehaviorInsight?

    @Query("SELECT * FROM behavior_insights WHERE dismissed = 0 ORDER BY generatedAt DESC")
    fun getActive(): Flow<List<BehaviorInsight>>

    @Query("SELECT * FROM behavior_insights ORDER BY generatedAt DESC LIMIT :limit")
    fun getRecent(limit: Int): Flow<List<BehaviorInsight>>

    @Query("SELECT * FROM behavior_insights WHERE type = :type AND dismissed = 0 ORDER BY generatedAt DESC")
    fun getByType(type: String): Flow<List<BehaviorInsight>>

    @Query("SELECT * FROM behavior_insights WHERE confidence = :confidence AND dismissed = 0 ORDER BY generatedAt DESC")
    fun getByConfidence(confidence: String): Flow<List<BehaviorInsight>>

    @Query("UPDATE behavior_insights SET dismissed = 1 WHERE id = :id")
    suspend fun dismiss(id: Long)

    @Query("DELETE FROM behavior_insights WHERE generatedAt < :beforeTimestamp")
    suspend fun deleteOlderThan(beforeTimestamp: Long)
}
