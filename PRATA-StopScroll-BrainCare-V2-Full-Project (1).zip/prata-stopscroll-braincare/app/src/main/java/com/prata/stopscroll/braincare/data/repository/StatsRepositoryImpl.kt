package com.prata.stopscroll.braincare.data.repository

import com.prata.stopscroll.braincare.data.local.dao.AppStatsDao
import com.prata.stopscroll.braincare.data.local.dao.AppStatisticsAggregate
import com.prata.stopscroll.braincare.data.local.dao.DailyLimitDao
import com.prata.stopscroll.braincare.data.local.dao.DailyStatsDao
import com.prata.stopscroll.braincare.data.local.dao.FocusSessionDao
import com.prata.stopscroll.braincare.data.local.dao.NotificationDao
import com.prata.stopscroll.braincare.data.local.dao.UserGoalsDao
import com.prata.stopscroll.braincare.data.local.entity.AppStatistics
import com.prata.stopscroll.braincare.data.local.entity.DailyLimit
import com.prata.stopscroll.braincare.data.local.entity.DailyStatistics
import com.prata.stopscroll.braincare.data.local.entity.FocusSession
import com.prata.stopscroll.braincare.data.local.entity.NotificationRecord
import com.prata.stopscroll.braincare.util.DateUtils
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository managing daily/app statistics, daily limits, focus sessions,
 * and notification records.
 *
 * Ensures single-source-of-truth consistency across DailyStatistics, AppStatistics,
 * DailyLimit, and UserGoals (Requirement G).
 */
@Singleton
class StatsRepositoryImpl @Inject constructor(
    private val dailyStatsDao: DailyStatsDao,
    private val appStatsDao: AppStatsDao,
    private val dailyLimitDao: DailyLimitDao,
    private val focusSessionDao: FocusSessionDao,
    private val notificationDao: NotificationDao,
    private val userGoalsDao: UserGoalsDao
) {

    // ─── Daily Statistics ────────────────────────────────────────────────

    suspend fun getOrCreateDailyStats(date: String): DailyStatistics {
        val existing = dailyStatsDao.getByDate(date)
        if (existing != null) return existing
        val configuredLimit = userGoalsDao.get()?.dailyLimit ?: 100
        val stats = DailyStatistics(
            date = date,
            limitValue = configuredLimit
        )
        val id = dailyStatsDao.insert(stats)
        return stats.copy(id = id)
    }

    suspend fun updateDailyStats(stats: DailyStatistics) {
        dailyStatsDao.update(stats.copy(updatedAt = System.currentTimeMillis()))
    }

    fun observeDailyStats(date: String): Flow<DailyStatistics?> =
        dailyStatsDao.observeByDate(date)

    fun getDailyStatsRange(startDate: String, endDate: String): Flow<List<DailyStatistics>> =
        dailyStatsDao.getRange(startDate, endDate)

    fun getRecentDailyStats(limit: Int): Flow<List<DailyStatistics>> =
        dailyStatsDao.getRecent(limit)

    fun getMaxStreak(): Flow<Int?> =
        dailyStatsDao.getMaxStreak()

    suspend fun getAverageShortContent(startDate: String, endDate: String): Float? =
        dailyStatsDao.getAverageShortContent(startDate, endDate)

    suspend fun getAverageUsageMs(startDate: String, endDate: String): Float? =
        dailyStatsDao.getAverageUsageMs(startDate, endDate)

    suspend fun getTotalShortContentRange(startDate: String, endDate: String): Int? =
        dailyStatsDao.getTotalShortContentRange(startDate, endDate)

    suspend fun getDaysUnderLimit(startDate: String, endDate: String): Int =
        dailyStatsDao.getDaysUnderLimit(startDate, endDate)

    // ─── App Statistics ──────────────────────────────────────────────────

    suspend fun getOrCreateAppStats(date: String, packageName: String, appName: String): AppStatistics {
        return appStatsDao.getByPackageAndDate(packageName, date) ?: run {
            val stats = AppStatistics(date = date, packageName = packageName, appName = appName)
            val id = appStatsDao.insert(stats)
            stats.copy(id = id)
        }
    }

    suspend fun updateAppStats(stats: AppStatistics) {
        appStatsDao.update(stats)
    }

    fun getAppStatsByDate(date: String): Flow<List<AppStatistics>> =
        appStatsDao.getByDate(date)

    fun observeAppStats(packageName: String, date: String): Flow<AppStatistics?> =
        appStatsDao.observeByPackageAndDate(packageName, date)

    fun getAppStatsRange(packageName: String, startDate: String, endDate: String): Flow<List<AppStatistics>> =
        appStatsDao.getByPackageRange(packageName, startDate, endDate)

    fun getAggregatedAppStats(startDate: String, endDate: String): Flow<List<AppStatisticsAggregate>> =
        appStatsDao.getAggregatedByPackageRange(startDate, endDate)

    // ─── Daily Limits ────────────────────────────────────────────────────

    suspend fun getOrCreateDailyLimit(date: String, defaultLimit: Int? = null): DailyLimit {
        val existing = dailyLimitDao.getByDate(date)
        if (existing != null) return existing

        val userGoalLimit = defaultLimit ?: userGoalsDao.get()?.dailyLimit ?: 100
        val limit = DailyLimit(date = date, totalLimit = userGoalLimit)
        val id = dailyLimitDao.insert(limit)
        return if (id > 0) limit.copy(id = id) else (dailyLimitDao.getByDate(date) ?: limit)
    }

    fun observeDailyLimit(date: String): Flow<DailyLimit?> =
        dailyLimitDao.observeByDate(date)

    suspend fun incrementDailyCount(date: String) {
        getOrCreateDailyLimit(date)
        dailyLimitDao.incrementCount(date)
    }

    suspend fun setDailyCount(date: String, count: Int) {
        getOrCreateDailyLimit(date)
        dailyLimitDao.setCount(date, count)
    }

    suspend fun updateDailyLimit(date: String, newLimit: Int) {
        val existing = getOrCreateDailyLimit(date, newLimit)
        val reached = existing.currentCount >= newLimit
        dailyLimitDao.update(
            existing.copy(
                totalLimit = newLimit,
                limitReached = reached
            )
        )
        // Keep UserGoals and DailyStatistics in sync
        val goals = userGoalsDao.get()
        if (goals != null) {
            userGoalsDao.updateDailyLimit(newLimit)
        }
        val dailyStats = getOrCreateDailyStats(date)
        updateDailyStats(
            dailyStats.copy(
                limitValue = newLimit,
                limitReached = reached
            )
        )
    }

    suspend fun updateLimitWarningShown(date: String, shown: Boolean) {
        val existing = getOrCreateDailyLimit(date)
        dailyLimitDao.update(existing.copy(warningShown = shown))
    }

    suspend fun updateLimitReached(date: String, reached: Boolean) {
        val existing = getOrCreateDailyLimit(date)
        dailyLimitDao.update(existing.copy(limitReached = reached))
        val dailyStats = getOrCreateDailyStats(date)
        updateDailyStats(dailyStats.copy(limitReached = reached))
    }

    suspend fun markWarningShown(date: String) =
        dailyLimitDao.markWarningShown(date)

    suspend fun markLimitReached(date: String) =
        dailyLimitDao.markLimitReached(date)

    suspend fun markUserOverrode(date: String) =
        dailyLimitDao.markUserOverrode(date)

    /**
     * Synchronizes DailyLimit, DailyStatistics, and AppStatistics whenever a new short content
     * item or usage session is recorded so every UI component and service sees identical figures.
     */
    suspend fun syncStatsAfterDetection(
        date: String,
        packageName: String,
        appName: String,
        todayTotalShortCount: Int,
        appShortCount: Int,
        totalUsageMs: Long = 0L,
        appUsageMs: Long = 0L,
        totalSessions: Int = 1,
        appSessions: Int = 1
    ): DailyLimit {
        val limitObj = getOrCreateDailyLimit(date)
        val limitReachedNow = limitObj.limitReached || (limitObj.totalLimit > 0 && todayTotalShortCount >= limitObj.totalLimit)
        val updatedLimit = limitObj.copy(
            currentCount = todayTotalShortCount,
            limitReached = limitReachedNow
        )
        dailyLimitDao.update(updatedLimit)

        val dailyStats = getOrCreateDailyStats(date)
        updateDailyStats(
            dailyStats.copy(
                totalShortContent = todayTotalShortCount,
                totalUsageMs = maxOf(dailyStats.totalUsageMs, totalUsageMs),
                totalSessions = maxOf(dailyStats.totalSessions, totalSessions),
                limitReached = limitReachedNow,
                limitValue = updatedLimit.totalLimit
            )
        )

        val appStats = getOrCreateAppStats(date, packageName, appName)
        updateAppStats(
            appStats.copy(
                shortContentCount = appShortCount,
                usageMs = maxOf(appStats.usageMs, appUsageMs),
                sessionCount = maxOf(appStats.sessionCount, appSessions)
            )
        )

        return updatedLimit
    }

    // ─── Focus Sessions ──────────────────────────────────────────────────

    suspend fun recordFocusSession(session: FocusSession): Long {
        val id = focusSessionDao.insert(session)
        if (session.completed) {
            val dailyStats = getOrCreateDailyStats(session.date)
            updateDailyStats(
                dailyStats.copy(
                    focusMinutes = dailyStats.focusMinutes + session.actualDurationMinutes
                )
            )
        }
        return id
    }

    suspend fun startFocusSession(plannedMinutes: Int): Long {
        val now = System.currentTimeMillis()
        val session = FocusSession(
            startTime = now,
            plannedDurationMinutes = plannedMinutes,
            date = DateUtils.formatDate(now)
        )
        return focusSessionDao.insert(session)
    }

    suspend fun endFocusSession(sessionId: Long, completed: Boolean) {
        val session = focusSessionDao.getById(sessionId) ?: return
        val now = System.currentTimeMillis()
        val actualMinutes = ((now - session.startTime) / 60_000).toInt().coerceAtLeast(1)
        focusSessionDao.update(
            session.copy(
                endTime = now,
                actualDurationMinutes = actualMinutes,
                completed = completed
            )
        )
        if (completed) {
            val dailyStats = getOrCreateDailyStats(session.date)
            updateDailyStats(
                dailyStats.copy(
                    focusMinutes = dailyStats.focusMinutes + actualMinutes
                )
            )
        }
    }

    suspend fun getActiveFocusSession(): FocusSession? =
        focusSessionDao.getActiveSession()

    fun observeActiveFocusSession(): Flow<FocusSession?> =
        focusSessionDao.observeActiveSession()

    fun getFocusSessionsByDate(date: String): Flow<List<FocusSession>> =
        focusSessionDao.getByDate(date)

    fun getCompletedFocusMinutesByDate(date: String): Flow<Int?> =
        focusSessionDao.getCompletedMinutesByDate(date)

    fun getCompletedFocusCountByDate(date: String): Flow<Int> =
        focusSessionDao.getCompletedCountByDate(date)

    suspend fun getTotalFocusMinutesRange(startDate: String, endDate: String): Int? =
        focusSessionDao.getTotalFocusMinutesRange(startDate, endDate)

    suspend fun incrementFocusInterruption(sessionId: Long) =
        focusSessionDao.incrementInterruption(sessionId)

    // ─── Notification Records ────────────────────────────────────────────

    suspend fun recordNotification(
        type: String,
        title: String,
        message: String,
        userAction: String? = null
    ): Long {
        val now = System.currentTimeMillis()
        val record = NotificationRecord(
            type = type,
            title = title,
            message = message,
            sentAt = now,
            userAction = userAction,
            date = DateUtils.formatDate(now)
        )
        return notificationDao.insert(record)
    }

    suspend fun updateNotificationAction(notificationId: Long, action: String) =
        notificationDao.updateUserAction(notificationId, action)

    fun getRecentNotifications(limit: Int): Flow<List<NotificationRecord>> =
        notificationDao.getRecent(limit)

    fun getNotificationsByDate(date: String): Flow<List<NotificationRecord>> =
        notificationDao.getByDate(date)

    suspend fun getNotificationCountByTypeAndDate(type: String, date: String): Int =
        notificationDao.getCountByTypeAndDate(type, date)

    // ─── Data Retention (Preserves Historical Stats Within Window) ──────

    suspend fun cleanupOldData(retentionDays: Int) {
        val safeDays = retentionDays.coerceAtLeast(30)
        val cutoffDate = DateUtils.daysAgo(safeDays)
        dailyStatsDao.deleteOlderThan(cutoffDate)
        appStatsDao.deleteOlderThan(cutoffDate)
        dailyLimitDao.deleteOlderThan(cutoffDate)
        focusSessionDao.deleteOlderThan(cutoffDate)
        notificationDao.deleteOlderThan(cutoffDate)
    }

    fun todayDate(): String = DateUtils.today()
}
