package com.prata.stopscroll.braincare.service

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.prata.stopscroll.braincare.data.local.entity.ShortContentDetection
import com.prata.stopscroll.braincare.di.ServiceEntryPoint
import com.prata.stopscroll.braincare.domain.detection.AccessibilitySignalInput
import com.prata.stopscroll.braincare.domain.limit.FocusScheduleConfig
import com.prata.stopscroll.braincare.domain.limit.LimitCheckDecision
import com.prata.stopscroll.braincare.domain.state.FloatingCounterSize
import com.prata.stopscroll.braincare.domain.state.LimitEnforcementPolicy
import com.prata.stopscroll.braincare.util.Constants
import com.prata.stopscroll.braincare.util.DateUtils
import com.prata.stopscroll.braincare.util.PermissionUtils
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Core AccessibilityService for PRATA StopScroll BrainCare V2.
 *
 * Integrates:
 * 1. Multi-signal ShortContentDetectionEngine with deduplication state machine (Section 4)
 * 2. Context-aware FloatingOverlayManager for live counter & hard-limit blocking shield (Section 3 & 4)
 * 3. Safe automatic redirection to Home screen (`performGlobalAction(GLOBAL_ACTION_HOME)`) when limit is reached
 *    in Mode Blokir / Mode Ketat, with anti-loop cooldown and fallback overlay (Section 3.B, 3.C, 3.D)
 * 4. Deterministic TrackingStateMachine & atomic Room synchronization (Section 3 & 6)
 */
class ScrollAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var currentPackage: String? = null
    private var currentSessionId: Long? = null
    private var sessionContentCount: Int = 0
    private var temporaryHideJob: Job? = null

    // Cached reactive preferences
    @Volatile private var isTrackingEnabled: Boolean = true
    @Volatile private var enabledPackages: Set<String> = Constants.TARGET_APPS.keys
    @Volatile private var exemptedPackages: Set<String> = emptySet()
    @Volatile private var enforcementPolicy: LimitEnforcementPolicy = LimitEnforcementPolicy.FOCUS
    @Volatile private var autoExitConsentGranted: Boolean = true
    @Volatile private var warningThresholdPercent: Float = Constants.WARNING_THRESHOLD_PERCENT
    @Volatile private var dailyDurationLimitMinutes: Int = 0
    @Volatile private var focusSchedule: FocusScheduleConfig = FocusScheduleConfig()
    @Volatile private var breakReminderEnabled: Boolean = true
    @Volatile private var breakReminderInterval: Int = Constants.DEFAULT_BREAK_REMINDER_COUNT
    @Volatile private var snoozeUntilTimestampMs: Long = 0L
    @Volatile private var perAppLimits: Map<String, Int> = emptyMap()

    private val entryPoint: ServiceEntryPoint by lazy {
        EntryPointAccessors.fromApplication(
            applicationContext,
            ServiceEntryPoint::class.java
        )
    }

    private var overlayManager: FloatingOverlayManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true

        overlayManager = FloatingOverlayManager(
            serviceContext = this,
            onPositionSaved = { x, y ->
                serviceScope.launch {
                    entryPoint.preferencesRepository().setFloatingCounterPosition(x, y)
                }
            },
            onTemporaryHideRequested = {
                handleTemporaryHideFloatingCounter()
            },
            onExitTargetAppRequested = {
                handleManualExitTargetAppFromBlock()
            },
            onSnoozeConfirmed = {
                handleMindfulSnoozeConfirmed()
            }
        )

        observeStateMachineForOverlay()
        observeUserSettingsAndLimits()
        initializeTodayState()
    }

    private fun observeStateMachineForOverlay() {
        serviceScope.launch {
            entryPoint.trackingStateMachine().snapshot.collectLatest { snapshot ->
                overlayManager?.renderSnapshot(snapshot)
            }
        }
    }

    private fun observeUserSettingsAndLimits() {
        val prefs = entryPoint.preferencesRepository()
        val limitManager = entryPoint.hardLimitManager()
        val stateMachine = entryPoint.trackingStateMachine()

        // Observe tracking, selected apps, policy, warning threshold, and snooze
        serviceScope.launch {
            combine(
                prefs.trackingEnabled,
                prefs.selectedApps,
                prefs.limitEnforcementPolicy,
                prefs.warningThresholdPercent,
                prefs.snoozeUntilTimestampMs
            ) { tracking, apps, policyStr, warnThreshold, snoozeUntil ->
                Quintuple(tracking, apps, policyStr, warnThreshold, snoozeUntil)
            }.collectLatest { (tracking, apps, policyStr, warnThreshold, snoozeUntil) ->
                isTrackingEnabled = tracking
                enabledPackages = expandSelectedPackages(apps)
                enforcementPolicy = LimitEnforcementPolicy.fromKey(policyStr)
                warningThresholdPercent = warnThreshold
                snoozeUntilTimestampMs = snoozeUntil

                stateMachine.onServiceOrPermissionStateChanged(
                    isAccessibilityGranted = true,
                    isOverlayGranted = PermissionUtils.isOverlayPermissionGranted(applicationContext),
                    isServiceRunning = true,
                    isTrackingEnabled = tracking
                )
                refreshLimitsIntoStateMachine()
            }
        }

        // Observe exempted apps and auto-exit consent
        serviceScope.launch {
            combine(
                prefs.exemptedApps,
                prefs.autoExitConsentGranted
            ) { exempted, autoExitConsent ->
                Pair(exempted, autoExitConsent)
            }.collectLatest { (exempted, autoExitConsent) ->
                exemptedPackages = expandSelectedPackages(exempted) - Constants.TARGET_APPS.keys.filter { exempted.isEmpty() }.toSet()
                autoExitConsentGranted = autoExitConsent
                refreshLimitsIntoStateMachine()
            }
        }

        // Observe schedule, duration, and per-app limits
        serviceScope.launch {
            combine(
                prefs.dailyDurationLimitMinutes,
                prefs.focusScheduleEnabled,
                prefs.focusScheduleStartHour,
                prefs.focusScheduleEndHour,
                prefs.observeGoals()
            ) { durationMins, schedEnabled, schedStart, schedEnd, goals ->
                Quintuple(durationMins, schedEnabled, schedStart, schedEnd, goals)
            }.collectLatest { (durationMins, schedEnabled, schedStart, schedEnd, goals) ->
                dailyDurationLimitMinutes = durationMins
                focusSchedule = FocusScheduleConfig(
                    enabled = schedEnabled,
                    startHour = schedStart,
                    endHour = schedEnd
                )
                perAppLimits = limitManager.parsePerAppLimits(goals.perAppLimits)
                refreshLimitsIntoStateMachine()
            }
        }

        serviceScope.launch {
            combine(
                prefs.breakReminderEnabled,
                prefs.breakReminderInterval
            ) { enabled, interval -> Pair(enabled, interval) }
                .collectLatest { (enabled, interval) ->
                    breakReminderEnabled = enabled
                    breakReminderInterval = interval
                }
        }

        // Observe floating counter appearance settings
        serviceScope.launch {
            combine(
                prefs.floatingCounterEnabled,
                prefs.floatingCounterSize,
                prefs.floatingCounterShowMascot,
                prefs.floatingCounterAnimation,
                combine(prefs.floatingCounterPosX, prefs.floatingCounterPosY) { x, y -> Pair(x, y) }
            ) { enabled, sizeKey, showMascot, anim, pos ->
                Quintuple(enabled, sizeKey, showMascot, anim, pos)
            }.collectLatest { (enabled, sizeKey, showMascot, anim, pos) ->
                overlayManager?.updatePreferences(
                    enabled = enabled,
                    size = FloatingCounterSize.fromKey(sizeKey),
                    showMascotIcon = showMascot,
                    animationsEnabled = anim,
                    posX = pos.first,
                    posY = pos.second
                )
            }
        }
    }

    private fun initializeTodayState() {
        serviceScope.launch {
            ensureDateRolloverAndCheckpoint()
            refreshLimitsIntoStateMachine()
        }
    }

    private suspend fun refreshLimitsIntoStateMachine() {
        val today = DateUtils.today()
        val usageRepo = entryPoint.usageRepository()
        val statsRepo = entryPoint.statsRepository()
        val stateMachine = entryPoint.trackingStateMachine()

        val limitObj = statsRepo.getOrCreateDailyLimit(today)
        val todayCount = usageRepo.getShortContentCountForDate(today)
        val pkg = currentPackage
        val appCount = if (pkg != null) usageRepo.getShortContentCountForPackageAndDate(pkg, today) else 0
        val appLimit = if (pkg != null) perAppLimits[pkg] else null
        val isSnoozed = snoozeUntilTimestampMs > System.currentTimeMillis()
        val schedActive = focusSchedule.isActiveAt(DateUtils.currentHour(), DateUtils.currentMinute())

        stateMachine.syncLimitsAndCounts(
            todayShortCount = todayCount,
            dailyLimit = limitObj.totalLimit,
            activeAppTodayCount = appCount,
            activeAppDailyLimit = appLimit,
            warningThresholdPercent = warningThresholdPercent,
            enforcementPolicy = enforcementPolicy,
            isFocusScheduleActive = schedActive,
            userOverrodeToday = isSnoozed
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkgName = event.packageName?.toString() ?: return

        // Never treat our own dashboard or protected system settings/dialer as target apps
        if (pkgName == applicationContext.packageName ||
            entryPoint.hardLimitManager().isProtectedSystemOrEmergencyPackage(pkgName)
        ) {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkgName != "com.android.systemui") {
                currentPackage = pkgName
                entryPoint.trackingStateMachine().onForegroundAppChanged(
                    packageName = pkgName,
                    isTargetApp = false,
                    appName = null
                )
            }
            return
        }

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowStateChanged(pkgName, event)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                handleContentOrScrollEvent(pkgName, event)
            }
        }
    }

    private fun isEnabledAndNonExemptTargetApp(packageName: String): Boolean {
        if (!Constants.TARGET_APPS.containsKey(packageName)) return false
        if (exemptedPackages.contains(packageName)) return false
        return enabledPackages.isEmpty() || enabledPackages.contains(packageName)
    }

    private fun handleWindowStateChanged(packageName: String, event: AccessibilityEvent) {
        val isTarget = isEnabledAndNonExemptTargetApp(packageName)
        val appName = Constants.TARGET_APPS[packageName]

        if (packageName != currentPackage) {
            val previousPackage = currentPackage
            currentPackage = packageName

            serviceScope.launch {
                ensureDateRolloverAndCheckpoint()

                // Close previous target app session if active
                if (previousPackage != null && currentSessionId != null) {
                    entryPoint.usageRepository().endSession(currentSessionId!!)
                    currentSessionId = null
                    sessionContentCount = 0
                }

                if (!isTarget) {
                    entryPoint.shortContentDetectionEngine().resetSession()
                    entryPoint.trackingStateMachine().onForegroundAppChanged(
                        packageName = packageName,
                        isTargetApp = false,
                        appName = null
                    )
                    return@launch
                }

                if (!isTrackingEnabled) {
                    entryPoint.trackingStateMachine().onForegroundAppChanged(
                        packageName = packageName,
                        isTargetApp = true,
                        appName = appName
                    )
                    return@launch
                }

                // Started or re-opened a target app
                val today = DateUtils.today()
                val usageRepo = entryPoint.usageRepository()
                val statsRepo = entryPoint.statsRepository()
                val limitManager = entryPoint.hardLimitManager()

                currentSessionId = usageRepo.startSession(
                    packageName = packageName,
                    appName = appName ?: packageName
                )
                sessionContentCount = 0

                val todayTotal = usageRepo.getShortContentCountForDate(today)
                val appCount = usageRepo.getShortContentCountForPackageAndDate(packageName, today)
                val totalDurationMs = usageRepo.getTotalDurationByDate(today).first() ?: 0L
                val limitObj = statsRepo.getOrCreateDailyLimit(today)
                val appLimit = perAppLimits[packageName]
                val nowMs = System.currentTimeMillis()
                val isSnoozed = snoozeUntilTimestampMs > nowMs

                entryPoint.trackingStateMachine().onForegroundAppChanged(
                    packageName = packageName,
                    isTargetApp = true,
                    appName = appName,
                    activeAppCount = appCount,
                    activeAppLimit = appLimit,
                    userOverrodeToday = isSnoozed
                )

                // Section 3.C & 3.D: If user re-opens target app while limit is already active in STRICT mode,
                // immediately enforce blocking overlay and redirect out if allowed
                if (enforcementPolicy == LimitEnforcementPolicy.STRICT) {
                    val reEntryDecision = limitManager.evaluateLimits(
                        todayTotalCount = todayTotal,
                        totalDailyLimit = limitObj.totalLimit,
                        activePackage = packageName,
                        activeAppName = appName,
                        activeAppTodayCount = appCount,
                        perAppLimits = perAppLimits,
                        todayUsageMs = totalDurationMs,
                        dailyDurationLimitMinutes = dailyDurationLimitMinutes,
                        warningThresholdPercent = warningThresholdPercent,
                        policy = enforcementPolicy,
                        focusSchedule = focusSchedule,
                        warningAlreadyShown = limitObj.warningShown,
                        limitAlreadyReached = limitObj.limitReached,
                        userOverrodeToday = isSnoozed,
                        snoozeUntilTimestampMs = snoozeUntilTimestampMs,
                        exemptedPackages = exemptedPackages,
                        autoExitConsentGranted = autoExitConsentGranted,
                        isAccessibilityServiceActive = isRunning,
                        isTargetInForeground = currentPackage == packageName,
                        nowTimestampMs = nowMs
                    )
                    if (reEntryDecision.shouldPerformGlobalHomeExit) {
                        executeAutomaticForceExitIfPermitted(
                            packageName = packageName,
                            appName = appName ?: packageName,
                            todayTotal = todayTotal,
                            dailyLimit = limitObj.totalLimit,
                            decision = reEntryDecision
                        )
                        return@launch
                    }
                }

                // Inspect active window to see if it opened directly into a short-form feed
                evaluateActiveWindowNode(packageName, event)
            }
        } else if (isTarget) {
            serviceScope.launch {
                evaluateActiveWindowNode(packageName, event)
            }
        }
    }

    private fun handleContentOrScrollEvent(packageName: String, event: AccessibilityEvent) {
        if (!isEnabledAndNonExemptTargetApp(packageName)) {
            if (currentPackage != packageName) {
                currentPackage = packageName
                entryPoint.trackingStateMachine().onForegroundAppChanged(
                    packageName = packageName,
                    isTargetApp = false,
                    appName = null
                )
            }
            return
        }

        val currentSnapshot = entryPoint.trackingStateMachine().snapshot.value
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            val now = SystemClock.elapsedRealtime()
            if (now - currentSnapshot.lastHeartbeatElapsedMs < 450L) {
                return
            }
        }

        serviceScope.launch {
            evaluateActiveWindowNode(packageName, event)
        }
    }

    private suspend fun evaluateActiveWindowNode(packageName: String, event: AccessibilityEvent) {
        val rootNode = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return

        val uiSnapshot = extractUiHierarchySnapshot(rootNode)
        val nowMs = System.currentTimeMillis()

        val signal = AccessibilitySignalInput(
            packageName = packageName,
            eventType = event.eventType,
            timestampMs = nowMs,
            className = event.className?.toString() ?: "",
            scrollDeltaY = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaY else 200,
            scrollDeltaX = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaX else 0,
            fromIndex = event.fromIndex,
            toIndex = event.toIndex,
            itemCount = event.itemCount,
            visibleViewIds = uiSnapshot.viewIds,
            visibleTexts = uiSnapshot.texts,
            visibleContentDescriptions = uiSnapshot.contentDescriptions,
            hasVerticalPagerNode = uiSnapshot.hasVerticalPager
        )

        val evalResult = entryPoint.shortContentDetectionEngine().evaluateSignal(
            signal = signal,
            trackingEnabled = isTrackingEnabled,
            enabledPackages = enabledPackages - exemptedPackages
        )

        val stateMachine = entryPoint.trackingStateMachine()
        val isSnoozed = snoozeUntilTimestampMs > nowMs

        stateMachine.onShortContentContextEvaluated(
            isShortFormContext = evalResult.isShortFormContext,
            isCommentOrMenuOpen = evalResult.isCommentOrOverlayOpen,
            confidence = evalResult.confidence,
            dedupState = evalResult.deduplicationState,
            userOverrodeToday = isSnoozed
        )

        val currentSnapshot = stateMachine.snapshot.value

        // Section 3.B.3 & 3.C: When limit is already reached and user is in short-form context,
        // stop incrementing new counts and trigger automatic exit if permitted!
        if (currentSnapshot.isBlockingOverlayVisible) {
            val limitManager = entryPoint.hardLimitManager()
            val decision = limitManager.evaluateLimits(
                todayTotalCount = currentSnapshot.todayShortCount,
                totalDailyLimit = currentSnapshot.dailyLimit,
                activePackage = packageName,
                activeAppName = evalResult.appDisplayName,
                activeAppTodayCount = currentSnapshot.activeAppTodayCount,
                perAppLimits = perAppLimits,
                todayUsageMs = currentSnapshot.todayUsageMs,
                dailyDurationLimitMinutes = dailyDurationLimitMinutes,
                warningThresholdPercent = warningThresholdPercent,
                policy = enforcementPolicy,
                focusSchedule = focusSchedule,
                warningAlreadyShown = true,
                limitAlreadyReached = true,
                userOverrodeToday = isSnoozed,
                snoozeUntilTimestampMs = snoozeUntilTimestampMs,
                exemptedPackages = exemptedPackages,
                autoExitConsentGranted = autoExitConsentGranted,
                isAccessibilityServiceActive = isRunning,
                isTargetInForeground = currentPackage == packageName,
                nowTimestampMs = nowMs
            )
            if (decision.shouldPerformGlobalHomeExit) {
                executeAutomaticForceExitIfPermitted(
                    packageName = packageName,
                    appName = evalResult.appDisplayName,
                    todayTotal = currentSnapshot.todayShortCount,
                    dailyLimit = currentSnapshot.dailyLimit,
                    decision = decision
                )
            }
            return
        }

        if (!evalResult.shouldIncrementCount) {
            return
        }

        // Verified HIGH_CONFIDENCE short-form transition! Persist atomically across all tables.
        ensureDateRolloverAndCheckpoint()
        val today = DateUtils.today()
        val currentHour = DateUtils.currentHour()
        val usageRepo = entryPoint.usageRepository()
        val statsRepo = entryPoint.statsRepository()
        val notifHelper = entryPoint.notificationHelper()
        val limitManager = entryPoint.hardLimitManager()

        sessionContentCount++

        usageRepo.recordShortContent(
            ShortContentDetection(
                packageName = packageName,
                appName = evalResult.appDisplayName,
                detectedAt = nowMs,
                contentType = evalResult.contentType,
                sessionId = currentSessionId,
                date = today,
                hour = currentHour
            )
        )

        currentSessionId?.let { sessionId ->
            usageRepo.updateSessionShortContentCount(sessionId, sessionContentCount)
        }

        val todayTotal = usageRepo.getShortContentCountForDate(today)
        val appTotal = usageRepo.getShortContentCountForPackageAndDate(packageName, today)
        val totalDurationMs = usageRepo.getTotalDurationByDate(today).first() ?: 0L
        val appDurationMs = usageRepo.getTotalDurationByPackageAndDate(packageName, today).first() ?: 0L
        val totalSessions = usageRepo.getSessionCountByDate(today).first()

        val updatedDailyLimit = statsRepo.syncStatsAfterDetection(
            date = today,
            packageName = packageName,
            appName = evalResult.appDisplayName,
            todayTotalShortCount = todayTotal,
            appShortCount = appTotal,
            totalUsageMs = totalDurationMs,
            appUsageMs = appDurationMs,
            totalSessions = totalSessions.coerceAtLeast(1)
        )

        val decision = limitManager.evaluateLimits(
            todayTotalCount = todayTotal,
            totalDailyLimit = updatedDailyLimit.totalLimit,
            activePackage = packageName,
            activeAppName = evalResult.appDisplayName,
            activeAppTodayCount = appTotal,
            perAppLimits = perAppLimits,
            todayUsageMs = totalDurationMs,
            dailyDurationLimitMinutes = dailyDurationLimitMinutes,
            warningThresholdPercent = warningThresholdPercent,
            policy = enforcementPolicy,
            focusSchedule = focusSchedule,
            warningAlreadyShown = updatedDailyLimit.warningShown,
            limitAlreadyReached = updatedDailyLimit.limitReached,
            userOverrodeToday = isSnoozed,
            snoozeUntilTimestampMs = snoozeUntilTimestampMs,
            exemptedPackages = exemptedPackages,
            autoExitConsentGranted = autoExitConsentGranted,
            isAccessibilityServiceActive = isRunning,
            isTargetInForeground = currentPackage == packageName,
            nowTimestampMs = nowMs
        )

        stateMachine.onVerifiedContentCounted(
            newTodayCount = todayTotal,
            newAppCount = appTotal,
            contentSignature = evalResult.contentSignature,
            timestampMs = nowMs,
            userOverrodeToday = isSnoozed
        )

        if (decision.shouldSendWarningNotification) {
            statsRepo.updateLimitWarningShown(today, true)
            notifHelper.showLimitWarningNotification(todayTotal, updatedDailyLimit.totalLimit)
            statsRepo.recordNotification(
                type = "LIMIT_WARNING",
                title = decision.blockingTitle,
                message = decision.blockingMessage
            )
        }

        if (decision.shouldSendLimitNotification || decision.isLimitReached) {
            if (!updatedDailyLimit.limitReached) {
                statsRepo.updateLimitReached(today, true)
                notifHelper.showLimitReachedNotification(
                    currentCount = todayTotal,
                    limit = updatedDailyLimit.totalLimit,
                    reason = decision.blockingMessage
                )
                statsRepo.recordNotification(
                    type = "LIMIT_REACHED",
                    title = decision.blockingTitle,
                    message = decision.blockingMessage
                )
            }

            if (decision.shouldPerformGlobalHomeExit) {
                executeAutomaticForceExitIfPermitted(
                    packageName = packageName,
                    appName = evalResult.appDisplayName,
                    todayTotal = todayTotal,
                    dailyLimit = updatedDailyLimit.totalLimit,
                    decision = decision
                )
            }
        } else if (breakReminderEnabled &&
            breakReminderInterval > 0 &&
            sessionContentCount > 0 &&
            sessionContentCount % breakReminderInterval == 0
        ) {
            notifHelper.showBreakReminderNotification(todayTotal, sessionContentCount)
            statsRepo.recordNotification(
                type = "BREAK_REMINDER",
                title = "Pengingat Istirahat PRATA",
                message = "Sesi mencapai $sessionContentCount konten berturut-turut."
            )
        }
    }

    /**
     * Executes automatic redirection to the Android Home screen (`performGlobalAction(GLOBAL_ACTION_HOME)`)
     * when all safety preconditions are met (Section 3.B.7, 3.C, 3.D).
     *
     * Never invokes hidden APIs, root, or process killing. If the OEM ROM rejects GLOBAL_ACTION_HOME,
     * safely falls back to keeping the full-screen BlockingOverlayView active.
     */
    private suspend fun executeAutomaticForceExitIfPermitted(
        packageName: String,
        appName: String,
        todayTotal: Int,
        dailyLimit: Int,
        decision: LimitCheckDecision
    ) {
        if (!isRunning || !autoExitConsentGranted) return
        if (currentPackage != packageName) return
        if (entryPoint.hardLimitManager().isProtectedSystemOrEmergencyPackage(packageName)) return

        val notifHelper = entryPoint.notificationHelper()
        val statsRepo = entryPoint.statsRepository()
        val stateMachine = entryPoint.trackingStateMachine()

        // Perform global action on main thread
        val exitSuccess = withContext(Dispatchers.Main) {
            try {
                performGlobalAction(GLOBAL_ACTION_HOME)
            } catch (_: Exception) {
                false
            }
        }

        stateMachine.recordAutoExitResult(exitSuccess)

        if (exitSuccess) {
            notifHelper.showLimitReachedNotification(
                currentCount = todayTotal,
                limit = dailyLimit,
                reason = "Batas tercapai ($todayTotal/$dailyLimit). PRATA mengarahkanmu keluar dari $appName ke layar utama sesuai ${decision.policy.title}."
            )
            statsRepo.recordNotification(
                type = "AUTO_EXIT_HOME",
                title = "Keluar Otomatis ($appName)",
                message = "GLOBAL_ACTION_HOME berhasil dijalankan saat batas tercapai (${decision.policy.title}).",
                userAction = "ACCEPTED"
            )
            // Brief settle pause before marking foreground as Home so the user sees a smooth transition without loop
            delay(350L)
            currentPackage = "android.home"
            stateMachine.onForegroundAppChanged(
                packageName = "android.home",
                isTargetApp = false,
                appName = null
            )
        } else {
            // Safe fallback: keep BlockingOverlayView active if GLOBAL_ACTION_HOME is unsupported by the ROM
            statsRepo.recordNotification(
                type = "AUTO_EXIT_FALLBACK",
                title = "Fallback Overlay Aktif ($appName)",
                message = "Perangkat membatasi GLOBAL_ACTION_HOME; menampilkan layar pembatas penuh."
            )
        }
    }

    private suspend fun ensureDateRolloverAndCheckpoint() {
        val prefs = entryPoint.preferencesRepository()
        val statsRepo = entryPoint.statsRepository()
        val usageRepo = entryPoint.usageRepository()

        val nowWallMs = System.currentTimeMillis()
        val nowElapsedMs = SystemClock.elapsedRealtime()
        val today = DateUtils.today()

        val lastDate = prefs.lastActiveDate.first()
        val lastWallMs = prefs.lastWallClockMs.first()
        val lastElapsedMs = prefs.lastElapsedRealtimeMs.first()

        val clockTampered = DateUtils.isSystemClockTamperedOrRolledBack(
            previousWallClockMs = lastWallMs,
            currentWallClockMs = nowWallMs,
            previousElapsedRealtimeMs = lastElapsedMs,
            currentElapsedRealtimeMs = nowElapsedMs
        )

        if (!clockTampered && lastDate.isNotBlank() && lastDate != today) {
            val prevCount = usageRepo.getShortContentCountForDate(lastDate)
            val prevLimit = statsRepo.getOrCreateDailyLimit(lastDate)
            val prevStats = statsRepo.getOrCreateDailyStats(lastDate)
            statsRepo.updateDailyStats(
                prevStats.copy(
                    totalShortContent = prevCount,
                    limitReached = prevCount >= prevLimit.totalLimit,
                    limitValue = prevLimit.totalLimit
                )
            )
            prefs.setSnoozeUntilTimestampMs(0L)
            snoozeUntilTimestampMs = 0L
            entryPoint.hardLimitManager().resetAutoExitCooldown()

            statsRepo.getOrCreateDailyLimit(today)
            statsRepo.getOrCreateDailyStats(today)
        }

        prefs.updateClockCheckpoint(today, nowWallMs, nowElapsedMs)
    }

    private fun handleTemporaryHideFloatingCounter() {
        val stateMachine = entryPoint.trackingStateMachine()
        stateMachine.setFloatingTemporarilyHidden(true)
        temporaryHideJob?.cancel()
        temporaryHideJob = serviceScope.launch {
            delay(3 * 60 * 1000L)
            stateMachine.setFloatingTemporarilyHidden(false)
        }
    }

    private fun handleManualExitTargetAppFromBlock() {
        val exitSuccess = try {
            performGlobalAction(GLOBAL_ACTION_HOME)
        } catch (_: Exception) {
            false
        }
        entryPoint.trackingStateMachine().recordAutoExitResult(exitSuccess)
        currentPackage = "android.home"
        entryPoint.trackingStateMachine().onForegroundAppChanged(
            packageName = "android.home",
            isTargetApp = false,
            appName = null
        )
        serviceScope.launch {
            entryPoint.statsRepository().recordNotification(
                type = "LIMIT_REACHED",
                title = "Intervensi Berhasil",
                message = "Pengguna memilih keluar dari aplikasi saat batas tercapai.",
                userAction = "ACCEPTED"
            )
        }
    }

    private fun handleMindfulSnoozeConfirmed() {
        val now = System.currentTimeMillis()
        val snoozeUntil = now + Constants.SNOOZE_DURATION_MS
        snoozeUntilTimestampMs = snoozeUntil

        serviceScope.launch {
            val today = DateUtils.today()
            entryPoint.preferencesRepository().setSnoozeUntilTimestampMs(snoozeUntil)
            entryPoint.statsRepository().markUserOverrode(today)
            entryPoint.statsRepository().recordNotification(
                type = "LIMIT_REACHED",
                title = "Tunda 5 Menit",
                message = "Pengguna menunda pembatas selama 5 menit dengan konfirmasi sadar.",
                userAction = "SNOOZED"
            )
            refreshLimitsIntoStateMachine()
        }
    }

    private data class UiHierarchySnapshot(
        val viewIds: List<String>,
        val texts: List<String>,
        val contentDescriptions: List<String>,
        val hasVerticalPager: Boolean
    )

    private fun extractUiHierarchySnapshot(rootNode: AccessibilityNodeInfo): UiHierarchySnapshot {
        val viewIds = mutableListOf<String>()
        val texts = mutableListOf<String>()
        val descriptions = mutableListOf<String>()
        var hasVerticalPager = false
        var visitedNodes = 0
        val maxNodes = 65

        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 10 || visitedNodes >= maxNodes) return
            visitedNodes++

            node.viewIdResourceName?.takeIf { it.isNotBlank() }?.let { viewIds.add(it) }
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { descriptions.add(it) }

            val cls = node.className?.toString() ?: ""
            if (cls.contains("ViewPager", ignoreCase = true) ||
                cls.contains("RecyclerView", ignoreCase = true)
            ) {
                if (node.isScrollable) {
                    hasVerticalPager = true
                }
            }

            val count = node.childCount
            for (i in 0 until count) {
                if (visitedNodes >= maxNodes) break
                val child = try {
                    node.getChild(i)
                } catch (_: Exception) {
                    null
                }
                traverse(child, depth + 1)
            }
        }

        traverse(rootNode, 0)
        return UiHierarchySnapshot(viewIds, texts, descriptions, hasVerticalPager)
    }

    private fun expandSelectedPackages(selected: Set<String>): Set<String> {
        if (selected.isEmpty()) return Constants.TARGET_APPS.keys
        val expanded = selected.toMutableSet()
        if (selected.contains(Constants.PKG_TIKTOK) || selected.contains(Constants.PKG_TIKTOK_ALT)) {
            expanded.add(Constants.PKG_TIKTOK)
            expanded.add(Constants.PKG_TIKTOK_ALT)
            expanded.add(Constants.PKG_TIKTOK_LITE)
        }
        if (selected.contains(Constants.PKG_INSTAGRAM)) {
            expanded.add(Constants.PKG_INSTAGRAM_LITE)
        }
        if (selected.contains(Constants.PKG_FACEBOOK)) {
            expanded.add(Constants.PKG_FACEBOOK_LITE)
        }
        return expanded
    }

    private data class Quintuple<A, B, C, D, E>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D,
        val fifth: E
    )

    override fun onInterrupt() {
        isRunning = false
        entryPoint.shortContentDetectionEngine().onServiceInterrupted()
        entryPoint.trackingStateMachine().onServiceOrPermissionStateChanged(
            isAccessibilityGranted = PermissionUtils.isAccessibilityServiceEnabled(applicationContext),
            isOverlayGranted = PermissionUtils.isOverlayPermissionGranted(applicationContext),
            isServiceRunning = false,
            isTrackingEnabled = isTrackingEnabled
        )
        overlayManager?.destroyAllOverlays()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        overlayManager?.destroyAllOverlays()
        serviceScope.cancel()
    }

    companion object {
        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
