package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.AIRecommendation
import kotlinx.coroutines.flow.Flow

@Dao
interface AIRecommendationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(recommendation: AIRecommendation): Long

    @Update
    suspend fun update(recommendation: AIRecommendation)

    @Delete
    suspend fun delete(recommendation: AIRecommendation)

    @Query("SELECT * FROM ai_recommendations WHERE id = :id")
    suspend fun getById(id: Long): AIRecommendation?

    @Query("SELECT * FROM ai_recommendations WHERE status = 'PENDING' ORDER BY createdAt DESC")
    fun getPending(): Flow<List<AIRecommendation>>

    @Query("SELECT * FROM ai_recommendations WHERE status = :status ORDER BY createdAt DESC")
    fun getByStatus(status: String): Flow<List<AIRecommendation>>

    @Query("SELECT * FROM ai_recommendations ORDER BY createdAt DESC LIMIT :limit")
    fun getRecent(limit: Int): Flow<List<AIRecommendation>>

    @Query("SELECT * FROM ai_recommendations ORDER BY createdAt DESC")
    fun getAll(): Flow<List<AIRecommendation>>

    @Query("UPDATE ai_recommendations SET status = :status, respondedAt = :respondedAt WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, respondedAt: Long = System.currentTimeMillis())

    @Query("UPDATE ai_recommendations SET effectivenessScore = :score WHERE id = :id")
    suspend fun updateEffectivenessScore(id: Long, score: Float)

    @Query("SELECT COUNT(*) FROM ai_recommendations WHERE status = 'PENDING'")
    fun getPendingCount(): Flow<Int>

    @Query("DELETE FROM ai_recommendations WHERE createdAt < :beforeTimestamp")
    suspend fun deleteOlderThan(beforeTimestamp: Long)
}
