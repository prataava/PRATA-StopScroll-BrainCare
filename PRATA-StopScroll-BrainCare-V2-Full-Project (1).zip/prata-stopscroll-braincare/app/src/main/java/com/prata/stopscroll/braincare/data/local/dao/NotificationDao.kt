package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.NotificationRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: NotificationRecord): Long

    @Update
    suspend fun update(record: NotificationRecord)

    @Query("SELECT * FROM notification_records WHERE date = :date ORDER BY sentAt DESC")
    fun getByDate(date: String): Flow<List<NotificationRecord>>

    @Query("SELECT * FROM notification_records ORDER BY sentAt DESC LIMIT :limit")
    fun getRecent(limit: Int): Flow<List<NotificationRecord>>

    @Query("SELECT * FROM notification_records WHERE type = :type ORDER BY sentAt DESC LIMIT :limit")
    fun getRecentByType(type: String, limit: Int): Flow<List<NotificationRecord>>

    @Query("UPDATE notification_records SET userAction = :action WHERE id = :id")
    suspend fun updateUserAction(id: Long, action: String)

    @Query("SELECT COUNT(*) FROM notification_records WHERE type = :type AND date = :date")
    suspend fun getCountByTypeAndDate(type: String, date: String): Int

    @Query("DELETE FROM notification_records WHERE date < :beforeDate")
    suspend fun deleteOlderThan(beforeDate: String)
}
