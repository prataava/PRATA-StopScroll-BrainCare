package com.prata.stopscroll.braincare.data.repository

import com.prata.stopscroll.braincare.data.local.dao.AIConversationDao
import com.prata.stopscroll.braincare.data.local.dao.AIRecommendationDao
import com.prata.stopscroll.braincare.data.local.dao.InsightDao
import com.prata.stopscroll.braincare.data.local.entity.AIConversation
import com.prata.stopscroll.braincare.data.local.entity.AIMessage
import com.prata.stopscroll.braincare.data.local.entity.AIRecommendation
import com.prata.stopscroll.braincare.data.local.entity.BehaviorInsight
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository managing AI conversations, messages, recommendations,
 * and behavioral insights.
 */
@Singleton
class AIRepositoryImpl @Inject constructor(
    private val conversationDao: AIConversationDao,
    private val recommendationDao: AIRecommendationDao,
    private val insightDao: InsightDao
) {

    // ─── Conversations ───────────────────────────────────────────────────

    suspend fun createConversation(title: String = "New Chat"): Long {
        val conversation = AIConversation(title = title)
        return conversationDao.insertConversation(conversation)
    }

    suspend fun getConversation(id: Long): AIConversation? =
        conversationDao.getConversationById(id)

    fun getAllConversations(): Flow<List<AIConversation>> =
        conversationDao.getAllConversations()

    suspend fun updateConversationTitle(id: Long, title: String) =
        conversationDao.updateTitle(id, title)

    suspend fun deleteConversation(id: Long) =
        conversationDao.deleteConversationById(id)

    // ─── Messages ────────────────────────────────────────────────────────

    suspend fun sendMessage(
        conversationId: Long,
        role: String,
        content: String,
        isLocal: Boolean = true
    ): Long {
        val message = AIMessage(
            conversationId = conversationId,
            role = role,
            content = content,
            isLocal = isLocal
        )
        return conversationDao.insertMessageAndTouch(message)
    }

    fun getMessages(conversationId: Long): Flow<List<AIMessage>> =
        conversationDao.getMessagesForConversation(conversationId)

    fun getMessagesForConversation(conversationId: Long): Flow<List<AIMessage>> =
        conversationDao.getMessagesForConversation(conversationId)

    suspend fun saveRecommendation(recommendation: AIRecommendation): Long =
        recommendationDao.insert(recommendation)

    suspend fun updateRecommendationStatus(id: Long, status: String) =
        recommendationDao.updateStatus(id, status)

    suspend fun saveInsight(insight: BehaviorInsight): Long =
        insightDao.insert(insight)

    suspend fun getMessagesOnce(conversationId: Long): List<AIMessage> =
        conversationDao.getMessagesForConversationOnce(conversationId)

    suspend fun getRecentMessages(conversationId: Long, limit: Int): List<AIMessage> =
        conversationDao.getRecentMessages(conversationId, limit)

    suspend fun getMessageCount(conversationId: Long): Int =
        conversationDao.getMessageCount(conversationId)

    suspend fun clearConversationMessages(conversationId: Long) =
        conversationDao.deleteMessagesForConversation(conversationId)

    // ─── Recommendations ─────────────────────────────────────────────────

    suspend fun createRecommendation(
        type: String,
        title: String,
        description: String,
        reasoning: String
    ): Long {
        val recommendation = AIRecommendation(
            type = type,
            title = title,
            description = description,
            reasoning = reasoning
        )
        return recommendationDao.insert(recommendation)
    }

    suspend fun getRecommendation(id: Long): AIRecommendation? =
        recommendationDao.getById(id)

    fun getPendingRecommendations(): Flow<List<AIRecommendation>> =
        recommendationDao.getPending()

    fun getRecommendationsByStatus(status: String): Flow<List<AIRecommendation>> =
        recommendationDao.getByStatus(status)

    fun getRecentRecommendations(limit: Int): Flow<List<AIRecommendation>> =
        recommendationDao.getRecent(limit)

    fun getAllRecommendations(): Flow<List<AIRecommendation>> =
        recommendationDao.getAll()

    fun getPendingRecommendationCount(): Flow<Int> =
        recommendationDao.getPendingCount()

    suspend fun acceptRecommendation(id: Long) =
        recommendationDao.updateStatus(id, "ACCEPTED")

    suspend fun dismissRecommendation(id: Long) =
        recommendationDao.updateStatus(id, "DISMISSED")

    suspend fun completeRecommendation(id: Long) =
        recommendationDao.updateStatus(id, "COMPLETED")

    suspend fun rateRecommendation(id: Long, score: Float) =
        recommendationDao.updateEffectivenessScore(id, score)

    // ─── Behavioral Insights ─────────────────────────────────────────────

    suspend fun createInsight(
        type: String,
        title: String,
        description: String,
        dataStartDate: String,
        dataEndDate: String,
        confidence: String,
        metadata: String = "{}"
    ): Long {
        val insight = BehaviorInsight(
            type = type,
            title = title,
            description = description,
            dataStartDate = dataStartDate,
            dataEndDate = dataEndDate,
            confidence = confidence,
            metadata = metadata
        )
        return insightDao.insert(insight)
    }

    suspend fun getInsight(id: Long): BehaviorInsight? =
        insightDao.getById(id)

    fun getActiveInsights(): Flow<List<BehaviorInsight>> =
        insightDao.getActive()

    fun getRecentInsights(limit: Int): Flow<List<BehaviorInsight>> =
        insightDao.getRecent(limit)

    fun getInsightsByType(type: String): Flow<List<BehaviorInsight>> =
        insightDao.getByType(type)

    fun getInsightsByConfidence(confidence: String): Flow<List<BehaviorInsight>> =
        insightDao.getByConfidence(confidence)

    suspend fun dismissInsight(id: Long) =
        insightDao.dismiss(id)

    // ─── Cleanup ─────────────────────────────────────────────────────────

    suspend fun cleanupOldData(retentionDays: Int) {
        val cutoffTimestamp = System.currentTimeMillis() - (retentionDays.toLong() * 24 * 60 * 60 * 1000)
        recommendationDao.deleteOlderThan(cutoffTimestamp)
        insightDao.deleteOlderThan(cutoffTimestamp)
    }
}
