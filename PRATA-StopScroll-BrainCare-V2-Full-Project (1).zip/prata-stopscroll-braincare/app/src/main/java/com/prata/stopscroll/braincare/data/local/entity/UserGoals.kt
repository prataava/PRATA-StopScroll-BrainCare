package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_goals")
data class UserGoals(
    @PrimaryKey val id: Int = 1, // singleton
    val dailyLimit: Int = 100,
    val perAppLimits: String = "{}", // JSON map of packageName -> limit
    val focusGoalMinutes: Int = 60,
    val approach: String = "gentle", // gentle, moderate, strict
    val detailLevel: String = "standard", // simple, standard, detailed
    val updatedAt: Long = System.currentTimeMillis()
)
