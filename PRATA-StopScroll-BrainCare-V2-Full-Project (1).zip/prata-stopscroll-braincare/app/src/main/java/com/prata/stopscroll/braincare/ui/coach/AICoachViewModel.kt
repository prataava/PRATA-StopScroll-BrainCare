package com.prata.stopscroll.braincare.ui.coach

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prata.stopscroll.braincare.data.local.entity.AIMessage
import com.prata.stopscroll.braincare.data.repository.AIRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.PreferencesRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.domain.ai.AIProviderManager
import com.prata.stopscroll.braincare.domain.ai.HabitAlgorithm
import com.prata.stopscroll.braincare.util.DateUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AICoachUiState(
    val conversationId: Long? = null,
    val messages: List<AIMessage> = emptyList(),
    val isLoading: Boolean = false,
    val isCloudEnabled: Boolean = false,
    val cloudStatusText: String = "Mode Analitik Lokal • 100% Data di Perangkat",
    val baseline: HabitAlgorithm.HabitBaseline? = null,
    val strategyFeedbackMessage: String? = null,
    val errorMessage: String? = null
)

@HiltViewModel
class AICoachViewModel @Inject constructor(
    private val aiRepository: AIRepositoryImpl,
    private val preferencesRepository: PreferencesRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl,
    private val aiProviderManager: AIProviderManager,
    private val habitAlgorithm: HabitAlgorithm
) : ViewModel() {

    private val _uiState = MutableStateFlow(AICoachUiState())
    val uiState: StateFlow<AICoachUiState> = _uiState.asStateFlow()

    init {
        initializeConversation()
        refreshCoachIntelligence()
    }

    fun refreshCoachIntelligence() {
        viewModelScope.launch {
            val status = aiProviderManager.getCloudStatus()
            val habitBaseline = habitAlgorithm.calculateBaseline()
            _uiState.update {
                it.copy(
                    isCloudEnabled = status.isCloudEnabled && status.isEndpointConfigured,
                    cloudStatusText = status.statusLabel,
                    baseline = habitBaseline
                )
            }
        }
    }

    private fun initializeConversation() {
        viewModelScope.launch {
            val existingConversations = aiRepository.getAllConversations().firstOrNull() ?: emptyList()
            val convId = if (existingConversations.isNotEmpty()) {
                existingConversations.first().id
            } else {
                val newId = aiRepository.createConversation("PRATA Digital Coach")
                aiRepository.sendMessage(
                    conversationId = newId,
                    role = "ASSISTANT",
                    content = "Halo! Saya PRATA AI Coach. Saya menganalisis data scrolling nyatamu langsung di perangkat untuk menampilkan jam paling aktif, perbandingan mingguan, efektivitas pengingat, dan rekomendasi target. Apa yang ingin kita evaluasi hari ini?",
                    isLocal = true
                )
                newId
            }

            _uiState.update { it.copy(conversationId = convId) }

            aiRepository.getMessagesForConversation(convId).collect { msgList ->
                _uiState.update { it.copy(messages = msgList) }
            }
        }
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isBlank()) return

        val convId = _uiState.value.conversationId ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            aiRepository.sendMessage(
                conversationId = convId,
                role = "USER",
                content = trimmed,
                isLocal = true
            )

            try {
                val reply = aiProviderManager.getResponseForQuery(
                    conversationId = convId,
                    userQuery = trimmed
                )
                aiRepository.sendMessage(
                    conversationId = convId,
                    role = "ASSISTANT",
                    content = reply,
                    isLocal = !_uiState.value.isCloudEnabled
                )
                refreshCoachIntelligence()
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = e.localizedMessage) }
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    /**
     * Applies the AI-recommended daily target directly to today's limit and UserGoals.
     */
    fun applyRecommendedTarget(targetCount: Int) {
        viewModelScope.launch {
            val today = DateUtils.today()
            statsRepository.updateDailyLimit(today, targetCount)
            preferencesRepository.updateDailyLimit(targetCount)
            _uiState.update {
                it.copy(strategyFeedbackMessage = "Target harian berhasil disesuaikan ke $targetCount konten/hari!")
            }
            refreshCoachIntelligence()
        }
    }

    /**
     * Records user feedback on whether the current reminder/blocking strategy is helping,
     * and adapts enforcement policy accordingly (Requirement H).
     */
    fun submitStrategyFeedback(helped: Boolean) {
        viewModelScope.launch {
            if (helped) {
                statsRepository.recordNotification(
                    type = "STRATEGY_FEEDBACK",
                    title = "Evaluasi Strategi Positif",
                    message = "Pengguna mengonfirmasi pengingat membantu menghentikan scrolling.",
                    userAction = "ACCEPTED"
                )
                _uiState.update {
                    it.copy(strategyFeedbackMessage = "Terima kasih! Strategi saat ini dipertahankan karena efektif membantumu.")
                }
            } else {
                statsRepository.recordNotification(
                    type = "STRATEGY_FEEDBACK",
                    title = "Evaluasi Strategi Perlu Diperketat",
                    message = "Pengguna melaporkan pengingat belum cukup menghentikan scrolling.",
                    userAction = "DISMISSED"
                )
                // Adapt strategy to Focus/Strict mode
                preferencesRepository.setLimitEnforcementPolicy("strict")
                _uiState.update {
                    it.copy(strategyFeedbackMessage = "Strategi disesuaikan ke Mode Ketat agar PRATA membantumu berhenti lebih tegas saat batas tercapai.")
                }
            }
            refreshCoachIntelligence()
        }
    }

    fun dismissFeedbackMessage() {
        _uiState.update { it.copy(strategyFeedbackMessage = null) }
    }
}
