package com.prata.stopscroll.braincare.ui.insights

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.prata.stopscroll.braincare.R
import com.prata.stopscroll.braincare.domain.ai.PredictionEngine
import com.prata.stopscroll.braincare.ui.components.AppDistributionBar
import com.prata.stopscroll.braincare.ui.components.HourlyBarChart
import com.prata.stopscroll.braincare.ui.components.PrataEmptyStateCard
import com.prata.stopscroll.braincare.ui.components.getSocialAppIconRes
import com.prata.stopscroll.braincare.ui.theme.SuccessGreen
import com.prata.stopscroll.braincare.ui.theme.WarmOrange
import com.prata.stopscroll.braincare.ui.theme.WarmPink
import com.prata.stopscroll.braincare.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsightsScreen(
    viewModel: InsightsViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    var expandedInsightId by remember { mutableStateOf<Long?>(null) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.loadData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Analitik & Laporan Wellbeing",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ─── Filter Tabs: Harian / Mingguan (7H) / Bulanan (30H) ─────────
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TimeRange.entries.forEach { range ->
                        FilterChip(
                            selected = uiState.selectedRange == range,
                            onClick = { viewModel.setTimeRange(range) },
                            label = { Text(range.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            }

            // ─── Summary Overview Card (Total, Average, Focus Minutes) ───────
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${uiState.totalCount}",
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = WarmOrange
                            )
                            Text(
                                text = "Total Video",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        HorizontalDivider(
                            modifier = Modifier
                                .height(40.dp)
                                .width(1.dp)
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${uiState.dailyAverage}",
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = WarmPink
                            )
                            Text(
                                text = "Rata-rata / Hari",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        HorizontalDivider(
                            modifier = Modifier
                                .height(40.dp)
                                .width(1.dp)
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${uiState.totalFocusMinutes}m",
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = SuccessGreen
                            )
                            Text(
                                text = "Waktu Fokus",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // ─── Weekly Comparison Report Card (Laporan Mingguan) ────────────
            uiState.weeklyBaseline?.let { base ->
                item {
                    val deltaSign = if (base.weeklyChangePercent > 0) "+${base.weeklyChangePercent}%" else "${base.weeklyChangePercent}%"
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Laporan Perbandingan Mingguan",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = deltaSign,
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = if (base.weeklyChangePercent <= 0) SuccessGreen else WarmOrange
                                )
                            }
                            Text(
                                text = "7 Hari Terakhir: ${base.currentWeekTotal} konten • 7 Hari Sebelumnya: ${base.previousWeekTotal} konten",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Periode Risiko: ${base.highRiskPeriod} • Hari Dalam Target: ${uiState.daysUnderLimit} hari",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // ─── Hourly Distribution Chart (24 Hours) ────────────────────────
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AccessTime,
                                contentDescription = "Distribusi Waktu",
                                tint = WarmOrange
                            )
                            Text(
                                text = "Grafik Aktivitas Scrolling (24 Jam)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        HourlyBarChart(
                            hourlyCounts = uiState.hourlyCounts,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // ─── Per-App Chart Section (Grafik Scrolling Per Aplikasi) ───────
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Grafik Scrolling Per Aplikasi (${uiState.selectedRange.label})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (uiState.appBreakdown.isEmpty()) {
                            Text(
                                text = "Belum ada data aplikasi pada periode ini.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            val maxVal = (uiState.appBreakdown.maxOfOrNull { it.count } ?: 1).coerceAtLeast(1)
                            val sumVal = uiState.appBreakdown.sumOf { it.count }.coerceAtLeast(1)
                            uiState.appBreakdown.forEach { app ->
                                val pct = ((app.count.toFloat() / sumVal) * 100).toInt()
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Image(
                                                painter = painterResource(id = getSocialAppIconRes(app.packageName)),
                                                contentDescription = app.appName,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Text(
                                                text = app.appName,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                                            )
                                        }
                                        Text(
                                            text = "${app.count} video ($pct%)",
                                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                            color = WarmOrange
                                        )
                                    }
                                    AppDistributionBar(
                                        appName = app.appName,
                                        packageName = app.packageName,
                                        count = app.count,
                                        maxCount = maxVal
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ─── AI Prediction Card ──────────────────────────────────────────
            uiState.prediction?.let { pred ->
                item {
                    val (riskColor, riskTitle) = when (pred.riskLevel) {
                        PredictionEngine.RiskLevel.ALREADY_EXCEEDED -> Pair(MaterialTheme.colorScheme.error, "Batas Terlampaui")
                        PredictionEngine.RiskLevel.HIGH -> Pair(Color(0xFFE57373), "Risiko Tinggi Melewati Batas")
                        PredictionEngine.RiskLevel.MODERATE -> Pair(WarmOrange, "Risiko Sedang")
                        PredictionEngine.RiskLevel.LOW -> Pair(Color(0xFF4CAF50), "Risiko Rendah / Aman")
                    }

                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.AutoGraph,
                                        contentDescription = "Prediksi AI",
                                        tint = riskColor
                                    )
                                    Text(
                                        text = "Estimasi AI Akhir Hari",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(riskColor.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = riskTitle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = riskColor,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Text(
                                text = "Proyeksi Hari Ini: ~${pred.estimatedEndOfDayCount} konten pendek",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = pred.explanation,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // ─── Behavioral Insights Section (Expandable Cards) ──────────────
            item {
                Text(
                    text = "Behavioral Insights PRATA",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (uiState.insights.isEmpty()) {
                item {
                    PrataEmptyStateCard(
                        title = "Mengumpulkan Pola Penggunaan",
                        subtitle = "PRATA menganalisis jam aktif dan tren mingguanmu secara otomatis dari data yang tercatat.",
                        illustrationRes = R.drawable.il_empty_state
                    )
                }
            } else {
                items(uiState.insights) { insight ->
                    val isExpanded = expandedInsightId == insight.id
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                            .clickable {
                                expandedInsightId = if (isExpanded) null else insight.id
                            }
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = insight.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = insight.confidence,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }

                            Text(
                                text = insight.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (isExpanded) {
                                Text(
                                    text = "Kategori: ${insight.type} • Periode Analisis: ${insight.dataStartDate} s/d ${insight.dataEndDate}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }
}
