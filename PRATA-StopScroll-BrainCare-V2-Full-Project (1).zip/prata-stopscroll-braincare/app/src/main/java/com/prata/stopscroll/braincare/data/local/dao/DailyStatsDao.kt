package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.DailyStatistics
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyStatsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(stats: DailyStatistics): Long

    @Update
    suspend fun update(stats: DailyStatistics)

    @Query("SELECT * FROM daily_statistics WHERE date = :date")
    suspend fun getByDate(date: String): DailyStatistics?

    @Query("SELECT * FROM daily_statistics WHERE date = :date")
    fun observeByDate(date: String): Flow<DailyStatistics?>

    @Query("SELECT * FROM daily_statistics WHERE date BETWEEN :startDate AND :endDate ORDER BY date ASC")
    fun getRange(startDate: String, endDate: String): Flow<List<DailyStatistics>>

    @Query("SELECT * FROM daily_statistics ORDER BY date DESC LIMIT :limit")
    fun getRecent(limit: Int): Flow<List<DailyStatistics>>

    @Query("SELECT MAX(streakDay) FROM daily_statistics")
    fun getMaxStreak(): Flow<Int?>

    @Query("SELECT streakDay FROM daily_statistics WHERE date = :date")
    suspend fun getStreakForDate(date: String): Int?

    @Query("SELECT AVG(totalShortContent) FROM daily_statistics WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getAverageShortContent(startDate: String, endDate: String): Float?

    @Query("SELECT AVG(totalUsageMs) FROM daily_statistics WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getAverageUsageMs(startDate: String, endDate: String): Float?

    @Query("SELECT SUM(totalShortContent) FROM daily_statistics WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getTotalShortContentRange(startDate: String, endDate: String): Int?

    @Query("SELECT COUNT(*) FROM daily_statistics WHERE limitReached = 0 AND date BETWEEN :startDate AND :endDate")
    suspend fun getDaysUnderLimit(startDate: String, endDate: String): Int

    @Query("DELETE FROM daily_statistics WHERE date < :beforeDate")
    suspend fun deleteOlderThan(beforeDate: String)
}
