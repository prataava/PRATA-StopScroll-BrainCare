package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.DailyLimit
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyLimitDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(limit: DailyLimit): Long

    @Update
    suspend fun update(limit: DailyLimit)

    @Query("SELECT * FROM daily_limits WHERE date = :date")
    suspend fun getByDate(date: String): DailyLimit?

    @Query("SELECT * FROM daily_limits WHERE date = :date")
    fun observeByDate(date: String): Flow<DailyLimit?>

    @Query("UPDATE daily_limits SET currentCount = currentCount + 1 WHERE date = :date")
    suspend fun incrementCount(date: String)

    @Query("UPDATE daily_limits SET warningShown = 1 WHERE date = :date")
    suspend fun markWarningShown(date: String)

    @Query("UPDATE daily_limits SET limitReached = 1 WHERE date = :date")
    suspend fun markLimitReached(date: String)

    @Query("UPDATE daily_limits SET userOverrode = 1 WHERE date = :date")
    suspend fun markUserOverrode(date: String)

    @Query("UPDATE daily_limits SET currentCount = :count WHERE date = :date")
    suspend fun setCount(date: String, count: Int)

    @Query("DELETE FROM daily_limits WHERE date < :beforeDate")
    suspend fun deleteOlderThan(beforeDate: String)
}
