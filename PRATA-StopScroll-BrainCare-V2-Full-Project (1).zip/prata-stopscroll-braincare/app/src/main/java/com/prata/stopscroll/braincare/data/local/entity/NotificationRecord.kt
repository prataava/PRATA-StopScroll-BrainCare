package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notification_records")
data class NotificationRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // LIMIT_WARNING, LIMIT_REACHED, BREAK_REMINDER, INSIGHT, CHALLENGE
    val title: String,
    val message: String,
    val sentAt: Long = System.currentTimeMillis(),
    val userAction: String? = null, // ACCEPTED, DISMISSED, SNOOZED
    val date: String
)
