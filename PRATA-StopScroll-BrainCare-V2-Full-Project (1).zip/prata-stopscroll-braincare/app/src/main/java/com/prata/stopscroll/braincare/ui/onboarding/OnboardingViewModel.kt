package com.prata.stopscroll.braincare.ui.onboarding

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prata.stopscroll.braincare.data.local.entity.QuestionnaireResponse
import com.prata.stopscroll.braincare.data.repository.PreferencesRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.service.MonitoringService
import com.prata.stopscroll.braincare.util.Constants
import com.prata.stopscroll.braincare.util.DateUtils
import com.prata.stopscroll.braincare.util.PermissionUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class OnboardingUiState(
    val currentStep: Int = 0,
    val selectedGoals: Set<String> = emptySet(),
    val selectedApps: Set<String> = Constants.TARGET_APPS.keys,
    val selectedTriggers: Set<String> = emptySet(),
    val initialDailyLimit: Int = 100,
    val isAccessibilityActive: Boolean = false,
    val isCompleted: Boolean = false
)

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferencesRepository: PreferencesRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl
) : ViewModel() {

    private val _uiState = MutableStateFlow(OnboardingUiState())
    val uiState: StateFlow<OnboardingUiState> = _uiState.asStateFlow()

    fun checkPermissions() {
        val active = PermissionUtils.isAccessibilityServiceEnabled(context)
        _uiState.update { it.copy(isAccessibilityActive = active) }
    }

    fun nextStep() {
        _uiState.update { it.copy(currentStep = it.currentStep + 1) }
    }

    fun prevStep() {
        _uiState.update { it.copy(currentStep = (it.currentStep - 1).coerceAtLeast(0)) }
    }

    fun toggleGoal(goal: String) {
        val current = _uiState.value.selectedGoals.toMutableSet()
        if (current.contains(goal)) current.remove(goal) else current.add(goal)
        _uiState.update { it.copy(selectedGoals = current) }
    }

    fun toggleApp(pkg: String) {
        val current = _uiState.value.selectedApps.toMutableSet()
        if (current.contains(pkg)) current.remove(pkg) else current.add(pkg)
        _uiState.update { it.copy(selectedApps = current) }
    }

    fun toggleTrigger(trigger: String) {
        val current = _uiState.value.selectedTriggers.toMutableSet()
        if (current.contains(trigger)) current.remove(trigger) else current.add(trigger)
        _uiState.update { it.copy(selectedTriggers = current) }
    }

    fun setDailyLimit(limit: Int) {
        _uiState.update { it.copy(initialDailyLimit = limit) }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            val state = _uiState.value

            // 1. Save questionnaire responses locally
            preferencesRepository.saveQuestionnaireResponse(
                QuestionnaireResponse(
                    category = "GOALS",
                    questionKey = "primary_goals",
                    answerValue = state.selectedGoals.joinToString(",")
                )
            )

            preferencesRepository.saveQuestionnaireResponse(
                QuestionnaireResponse(
                    category = "TRIGGERS",
                    questionKey = "habit_triggers",
                    answerValue = state.selectedTriggers.joinToString(",")
                )
            )

            // 2. Save settings
            preferencesRepository.setSelectedApps(state.selectedApps)
            preferencesRepository.setTrackingEnabled(true)
            preferencesRepository.setOnboardingCompleted(true)

            // 3. Set today's limit
            val today = DateUtils.today()
            statsRepository.updateDailyLimit(today, state.initialDailyLimit)

            // 4. Start foreground monitoring if possible
            try {
                MonitoringService.start(context)
            } catch (_: Exception) {}

            _uiState.update { it.copy(isCompleted = true) }
        }
    }
}
