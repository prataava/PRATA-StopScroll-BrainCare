package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.AppStatistics
import kotlinx.coroutines.flow.Flow

@Dao
interface AppStatsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(stats: AppStatistics): Long

    @Update
    suspend fun update(stats: AppStatistics)

    @Query("SELECT * FROM app_statistics WHERE date = :date ORDER BY shortContentCount DESC")
    fun getByDate(date: String): Flow<List<AppStatistics>>

    @Query("SELECT * FROM app_statistics WHERE packageName = :packageName AND date = :date")
    suspend fun getByPackageAndDate(packageName: String, date: String): AppStatistics?

    @Query("SELECT * FROM app_statistics WHERE packageName = :packageName AND date = :date")
    fun observeByPackageAndDate(packageName: String, date: String): Flow<AppStatistics?>

    @Query("SELECT * FROM app_statistics WHERE packageName = :packageName AND date BETWEEN :startDate AND :endDate ORDER BY date ASC")
    fun getByPackageRange(packageName: String, startDate: String, endDate: String): Flow<List<AppStatistics>>

    @Query("SELECT packageName, appName, SUM(shortContentCount) as shortContentCount, SUM(usageMs) as usageMs, SUM(sessionCount) as sessionCount FROM app_statistics WHERE date BETWEEN :startDate AND :endDate GROUP BY packageName, appName ORDER BY shortContentCount DESC")
    fun getAggregatedByPackageRange(startDate: String, endDate: String): Flow<List<AppStatisticsAggregate>>

    @Query("DELETE FROM app_statistics WHERE date < :beforeDate")
    suspend fun deleteOlderThan(beforeDate: String)
}

/** Projection for aggregated per-app stats across a date range. */
data class AppStatisticsAggregate(
    val packageName: String,
    val appName: String,
    val shortContentCount: Int,
    val usageMs: Long,
    val sessionCount: Int
)
