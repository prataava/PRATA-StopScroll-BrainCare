package com.prata.stopscroll.braincare.util

import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Timezone-aware, clock-tamper-resilient date utilities (Requirement G).
 */
object DateUtils {
    private val DATE_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US)

    fun today(zoneId: ZoneId = ZoneId.systemDefault()): String {
        return LocalDate.now(zoneId).format(DATE_FORMATTER)
    }

    fun currentHour(zoneId: ZoneId = ZoneId.systemDefault()): Int {
        return Instant.now().atZone(zoneId).hour
    }

    fun currentMinute(zoneId: ZoneId = ZoneId.systemDefault()): Int {
        return Instant.now().atZone(zoneId).minute
    }

    fun formatDate(timestampMs: Long, zoneId: ZoneId = ZoneId.systemDefault()): String {
        if (timestampMs <= 0L) return today(zoneId)
        return Instant.ofEpochMilli(timestampMs).atZone(zoneId).toLocalDate().format(DATE_FORMATTER)
    }

    fun formatTime(timestampMs: Long): String {
        val tf = SimpleDateFormat("HH:mm", Locale.US).apply {
            timeZone = TimeZone.getDefault()
        }
        return tf.format(Date(timestampMs))
    }

    fun formatDisplayDate(dateStr: String): String {
        return try {
            val sdfIn = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val sdfOut = SimpleDateFormat("EEE, dd MMM yyyy", Locale.US)
            val parsed = sdfIn.parse(dateStr)
            if (parsed != null) sdfOut.format(parsed) else dateStr
        } catch (e: Exception) {
            dateStr
        }
    }

    fun daysAgo(days: Int, zoneId: ZoneId = ZoneId.systemDefault()): String {
        return LocalDate.now(zoneId).minusDays(days.toLong()).format(DATE_FORMATTER)
    }

    fun daysAgoFrom(anchorDateStr: String, days: Int): String {
        return try {
            LocalDate.parse(anchorDateStr, DATE_FORMATTER).minusDays(days.toLong()).format(DATE_FORMATTER)
        } catch (_: Exception) {
            daysAgo(days)
        }
    }

    /**
     * Detects whether the system clock was moved backward significantly compared to monotonic elapsed time.
     */
    fun isSystemClockTamperedOrRolledBack(
        previousWallClockMs: Long,
        currentWallClockMs: Long,
        previousElapsedRealtimeMs: Long,
        currentElapsedRealtimeMs: Long,
        toleranceMs: Long = 120_000L // 2 minutes tolerance for NTP sync
    ): Boolean {
        if (previousWallClockMs <= 0L || previousElapsedRealtimeMs <= 0L) return false
        if (currentElapsedRealtimeMs < previousElapsedRealtimeMs) {
            // Device rebooted; monotonic clock reset
            return false
        }
        val wallDelta = currentWallClockMs - previousWallClockMs
        val monotonicDelta = currentElapsedRealtimeMs - previousElapsedRealtimeMs
        return (monotonicDelta - wallDelta) > toleranceMs
    }

    fun formatDuration(ms: Long): String {
        val safeMs = ms.coerceAtLeast(0L)
        val totalSecs = safeMs / 1000
        val hours = totalSecs / 3600
        val mins = (totalSecs % 3600) / 60
        val secs = totalSecs % 60

        return when {
            hours > 0 -> "${hours}h ${mins}m"
            mins > 0 -> "${mins}m ${secs}s"
            else -> "${secs}s"
        }
    }

    fun formatMinutes(minutes: Int): String {
        val safeMins = minutes.coerceAtLeast(0)
        val hours = safeMins / 60
        val mins = safeMins % 60
        return when {
            hours > 0 && mins > 0 -> "${hours}h ${mins}m"
            hours > 0 -> "${hours}h"
            else -> "${mins}m"
        }
    }

    fun getHourLabel(hour: Int): String {
        return String.format(Locale.US, "%02d:00", hour.coerceIn(0, 23))
    }
}
