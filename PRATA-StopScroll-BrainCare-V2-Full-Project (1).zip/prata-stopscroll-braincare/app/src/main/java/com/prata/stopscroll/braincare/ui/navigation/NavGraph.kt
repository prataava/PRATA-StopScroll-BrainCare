package com.prata.stopscroll.braincare.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.prata.stopscroll.braincare.ui.challenge.ChallengeScreen
import com.prata.stopscroll.braincare.ui.challenge.ChallengeViewModel
import com.prata.stopscroll.braincare.ui.coach.AICoachScreen
import com.prata.stopscroll.braincare.ui.coach.AICoachViewModel
import com.prata.stopscroll.braincare.ui.home.HomeScreen
import com.prata.stopscroll.braincare.ui.home.HomeViewModel
import com.prata.stopscroll.braincare.ui.insights.InsightsScreen
import com.prata.stopscroll.braincare.ui.insights.InsightsViewModel
import com.prata.stopscroll.braincare.ui.onboarding.OnboardingScreen
import com.prata.stopscroll.braincare.ui.onboarding.OnboardingViewModel
import com.prata.stopscroll.braincare.ui.settings.SettingsScreen
import com.prata.stopscroll.braincare.ui.settings.SettingsViewModel

@Composable
fun PrataApp(
    startDestination: String = Screen.Home.route
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showBottomBar = currentRoute in Screen.bottomNavItems.map { it.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    Screen.bottomNavItems.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = { Text(screen.title) },
                            selected = selected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            enterTransition = { fadeIn(animationSpec = tween(220)) },
            exitTransition = { fadeOut(animationSpec = tween(180)) },
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                val vm: HomeViewModel = hiltViewModel()
                HomeScreen(
                    viewModel = vm,
                    onNavigateToInsights = { navController.navigate(Screen.Insights.route) },
                    onNavigateToAICoach = { navController.navigate(Screen.AICoach.route) }
                )
            }

            composable(Screen.Insights.route) {
                val vm: InsightsViewModel = hiltViewModel()
                InsightsScreen(viewModel = vm)
            }

            composable(Screen.AICoach.route) {
                val vm: AICoachViewModel = hiltViewModel()
                AICoachScreen(viewModel = vm)
            }

            composable(Screen.Challenge.route) {
                val vm: ChallengeViewModel = hiltViewModel()
                ChallengeScreen(viewModel = vm)
            }

            composable(Screen.Settings.route) {
                val vm: SettingsViewModel = hiltViewModel()
                SettingsScreen(viewModel = vm)
            }

            composable(Screen.Onboarding.route) {
                val vm: OnboardingViewModel = hiltViewModel()
                OnboardingScreen(
                    viewModel = vm,
                    onFinished = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Onboarding.route) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}
