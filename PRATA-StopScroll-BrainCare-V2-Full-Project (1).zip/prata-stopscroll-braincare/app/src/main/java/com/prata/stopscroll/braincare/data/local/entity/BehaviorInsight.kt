package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "behavior_insights")
data class BehaviorInsight(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // PEAK_HOURS, TREND, PATTERN, BASELINE, PREDICTION
    val title: String,
    val description: String,
    val dataStartDate: String,
    val dataEndDate: String,
    val confidence: String, // LOW, MEDIUM, HIGH
    val metadata: String = "{}", // JSON for extra data
    val generatedAt: Long = System.currentTimeMillis(),
    val dismissed: Boolean = false
)
