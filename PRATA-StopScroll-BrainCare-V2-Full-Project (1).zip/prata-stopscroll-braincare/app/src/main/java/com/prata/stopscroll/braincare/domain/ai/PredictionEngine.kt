package com.prata.stopscroll.braincare.domain.ai

import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.UsageRepositoryImpl
import com.prata.stopscroll.braincare.util.DateUtils
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PredictionEngine @Inject constructor(
    private val statsRepository: StatsRepositoryImpl,
    private val usageRepository: UsageRepositoryImpl
) {

    data class ScrollPrediction(
        val estimatedEndOfDayCount: Int,
        val riskLevel: RiskLevel,
        val confidence: String, // LOW, MEDIUM, HIGH
        val explanation: String,
        val isDataSufficient: Boolean
    )

    enum class RiskLevel {
        LOW,
        MODERATE,
        HIGH,
        ALREADY_EXCEEDED
    }

    suspend fun predictTodayLimitExceedance(): ScrollPrediction {
        val today = DateUtils.today()
        val currentHour = DateUtils.currentHour()
        val currentCount = usageRepository.getShortContentCountForDate(today)
        val dailyLimitObj = statsRepository.getOrCreateDailyLimit(today)
        val dailyLimit = dailyLimitObj.totalLimit

        if (currentCount >= dailyLimit) {
            return ScrollPrediction(
                estimatedEndOfDayCount = currentCount,
                riskLevel = RiskLevel.ALREADY_EXCEEDED,
                confidence = "HIGH",
                explanation = "Batas harian ($dailyLimit konten) sudah terlampaui saat ini ($currentCount konten).",
                isDataSufficient = true
            )
        }

        // Get historical stats from past 7 days to estimate average evening/afternoon activity
        val sevenDaysAgo = DateUtils.daysAgo(7)
        val pastStats = statsRepository.getDailyStatsRange(sevenDaysAgo, today).firstOrNull() ?: emptyList()
        val validPastStats = pastStats.filter { it.totalShortContent > 0 && it.date != today }

        if (validPastStats.isEmpty()) {
            // Early day fallback
            val hoursRemaining = (24 - currentHour).coerceAtLeast(1)
            val hourlyPace = if (currentHour > 0) currentCount.toFloat() / currentHour else 0f
            val projected = (currentCount + (hourlyPace * hoursRemaining)).toInt()

            val risk = when {
                projected > dailyLimit * 1.2 -> RiskLevel.HIGH
                projected > dailyLimit -> RiskLevel.MODERATE
                else -> RiskLevel.LOW
            }

            return ScrollPrediction(
                estimatedEndOfDayCount = projected,
                riskLevel = risk,
                confidence = "LOW",
                explanation = "Estimasi berdasarkan laju scrolling hari ini ($currentCount konten hingga jam $currentHour:00). Memerlukan lebih banyak hari untuk akurasi optimal.",
                isDataSufficient = false
            )
        }

        val historicalAvg = validPastStats.map { it.totalShortContent }.average().toFloat()
        val hoursRemaining = (24 - currentHour).coerceAtLeast(1)
        val hourlyPaceToday = if (currentHour > 0) currentCount.toFloat() / currentHour else (historicalAvg / 16)
        
        // Blend current pace with historical average (weighted 60% today, 40% historical)
        val blendedRemainingExpected = (hourlyPaceToday * 0.6f + (historicalAvg / 24f) * 0.4f) * hoursRemaining
        val projectedTotal = (currentCount + blendedRemainingExpected).toInt()

        val risk = when {
            projectedTotal > dailyLimit * 1.15 -> RiskLevel.HIGH
            projectedTotal >= dailyLimit -> RiskLevel.MODERATE
            else -> RiskLevel.LOW
        }

        val confidence = if (validPastStats.size >= 5) "HIGH" else "MEDIUM"
        val explanation = when (risk) {
            RiskLevel.HIGH -> "Berdasarkan pola hari ini dan $hoursRemaining jam tersisa, diproyeksikan mencapai ~$projectedTotal konten (melebihi batas $dailyLimit)."
            RiskLevel.MODERATE -> "Laju scrolling saat ini mendekati batas harianmu ($dailyLimit konten). Pertimbangkan membatasi sesi media sosial."
            RiskLevel.LOW -> "Penggunaanmu saat ini aman dan berada di bawah batas harian ($dailyLimit konten)."
            RiskLevel.ALREADY_EXCEEDED -> "Batas harian sudah terlewati."
        }

        return ScrollPrediction(
            estimatedEndOfDayCount = projectedTotal,
            riskLevel = risk,
            confidence = confidence,
            explanation = explanation,
            isDataSufficient = true
        )
    }
}
