package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.AIConversation
import com.prata.stopscroll.braincare.data.local.entity.AIMessage
import kotlinx.coroutines.flow.Flow

@Dao
interface AIConversationDao {

    // --- Conversation operations ---

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: AIConversation): Long

    @Update
    suspend fun updateConversation(conversation: AIConversation)

    @Delete
    suspend fun deleteConversation(conversation: AIConversation)

    @Query("DELETE FROM ai_conversations WHERE id = :conversationId")
    suspend fun deleteConversationById(conversationId: Long)

    @Query("SELECT * FROM ai_conversations ORDER BY updatedAt DESC")
    fun getAllConversations(): Flow<List<AIConversation>>

    @Query("SELECT * FROM ai_conversations WHERE id = :id")
    suspend fun getConversationById(id: Long): AIConversation?

    @Query("UPDATE ai_conversations SET title = :title, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateTitle(id: Long, title: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE ai_conversations SET updatedAt = :updatedAt WHERE id = :id")
    suspend fun touchConversation(id: Long, updatedAt: Long = System.currentTimeMillis())

    // --- Message operations ---

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: AIMessage): Long

    @Delete
    suspend fun deleteMessage(message: AIMessage)

    @Query("SELECT * FROM ai_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: Long): Flow<List<AIMessage>>

    @Query("SELECT * FROM ai_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesForConversationOnce(conversationId: Long): List<AIMessage>

    @Query("SELECT * FROM ai_messages WHERE conversationId = :conversationId ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentMessages(conversationId: Long, limit: Int): List<AIMessage>

    @Query("SELECT COUNT(*) FROM ai_messages WHERE conversationId = :conversationId")
    suspend fun getMessageCount(conversationId: Long): Int

    @Query("DELETE FROM ai_messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: Long)

    // --- Transaction operations ---

    @Transaction
    suspend fun insertMessageAndTouch(message: AIMessage): Long {
        val id = insertMessage(message)
        touchConversation(message.conversationId)
        return id
    }
}
