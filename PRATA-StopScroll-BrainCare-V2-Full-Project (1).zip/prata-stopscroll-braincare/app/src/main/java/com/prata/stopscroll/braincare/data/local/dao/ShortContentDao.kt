package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.prata.stopscroll.braincare.data.local.entity.ShortContentDetection
import kotlinx.coroutines.flow.Flow

@Dao
interface ShortContentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(detection: ShortContentDetection): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(detections: List<ShortContentDetection>)

    @Delete
    suspend fun delete(detection: ShortContentDetection)

    @Query("SELECT * FROM short_content_detections WHERE id = :id")
    suspend fun getById(id: Long): ShortContentDetection?

    @Query("SELECT * FROM short_content_detections WHERE date = :date ORDER BY detectedAt DESC")
    fun getByDate(date: String): Flow<List<ShortContentDetection>>

    @Query("SELECT * FROM short_content_detections WHERE packageName = :packageName AND date = :date ORDER BY detectedAt DESC")
    fun getByPackageAndDate(packageName: String, date: String): Flow<List<ShortContentDetection>>

    @Query("SELECT COUNT(*) FROM short_content_detections WHERE date = :date")
    fun getCountByDate(date: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM short_content_detections WHERE packageName = :packageName AND date = :date")
    fun getCountByPackageAndDate(packageName: String, date: String): Flow<Int>

    @Query("SELECT hour, COUNT(*) as count FROM short_content_detections WHERE date = :date GROUP BY hour ORDER BY hour")
    fun getHourlyDistribution(date: String): Flow<List<HourlyCount>>

    @Query("SELECT hour, COUNT(*) as count FROM short_content_detections WHERE date BETWEEN :startDate AND :endDate GROUP BY hour ORDER BY hour")
    fun getHourlyDistributionRange(startDate: String, endDate: String): Flow<List<HourlyCount>>

    @Query("SELECT contentType, COUNT(*) as count FROM short_content_detections WHERE date = :date GROUP BY contentType")
    fun getContentTypeDistribution(date: String): Flow<List<ContentTypeCount>>

    @Query("SELECT packageName, appName, COUNT(*) as count FROM short_content_detections WHERE date = :date GROUP BY packageName, appName ORDER BY count DESC")
    fun getAppDistribution(date: String): Flow<List<AppCount>>

    @Query("SELECT EXISTS(SELECT 1 FROM short_content_detections WHERE packageName = :packageName AND detectedAt BETWEEN :startTime AND :endTime LIMIT 1)")
    suspend fun existsInTimeRange(packageName: String, startTime: Long, endTime: Long): Boolean

    @Query("SELECT date, COUNT(*) as count FROM short_content_detections WHERE date BETWEEN :startDate AND :endDate GROUP BY date ORDER BY date")
    fun getDailyCountsRange(startDate: String, endDate: String): Flow<List<DailyCount>>

    @Query("DELETE FROM short_content_detections WHERE date < :beforeDate")
    suspend fun deleteOlderThan(beforeDate: String)
}

/** Projection for hourly distribution queries. */
data class HourlyCount(
    val hour: Int,
    val count: Int
)

/** Projection for content type distribution queries. */
data class ContentTypeCount(
    val contentType: String,
    val count: Int
)

/** Projection for per-app distribution queries. */
data class AppCount(
    val packageName: String,
    val appName: String,
    val count: Int
)

/** Projection for daily count queries. */
data class DailyCount(
    val date: String,
    val count: Int
)
