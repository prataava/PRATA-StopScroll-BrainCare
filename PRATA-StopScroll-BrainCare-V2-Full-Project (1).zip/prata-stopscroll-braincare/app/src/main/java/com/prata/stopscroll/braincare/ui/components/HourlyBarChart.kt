package com.prata.stopscroll.braincare.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.prata.stopscroll.braincare.data.local.dao.HourlyCount
import com.prata.stopscroll.braincare.ui.theme.WarmOrange

@Composable
fun HourlyBarChart(
    hourlyCounts: List<HourlyCount>,
    modifier: Modifier = Modifier
) {
    // Fill all 24 hours 0..23
    val countsMap = hourlyCounts.associate { it.hour to it.count }
    val full24Hours = (0..23).map { hour -> countsMap[hour] ?: 0 }
    val maxCount = (full24Hours.maxOrNull() ?: 1).coerceAtLeast(10)

    var selectedHour by remember { mutableStateOf<Int?>(null) }

    val barColor = MaterialTheme.colorScheme.primaryContainer
    val peakColor = WarmOrange
    val selectedColor = MaterialTheme.colorScheme.secondary

    Column(modifier = modifier) {
        selectedHour?.let { hour ->
            val count = full24Hours[hour]
            Text(
                text = "Pukul ${String.format("%02d:00", hour)}: $count konten pendek",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(full24Hours) {
                        detectTapGestures { offset ->
                            val slotWidth = size.width / 24f
                            val tappedHour = (offset.x / slotWidth).toInt().coerceIn(0, 23)
                            selectedHour = tappedHour
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val slotWidth = canvasWidth / 24f
                val barWidth = slotWidth * 0.65f

                full24Hours.forEachIndexed { hour, count ->
                    val barHeight = (count.toFloat() / maxCount) * (canvasHeight - 20.dp.toPx())
                    val left = (hour * slotWidth) + ((slotWidth - barWidth) / 2f)
                    val top = canvasHeight - barHeight.coerceAtLeast(4.dp.toPx())

                    val color = when {
                        hour == selectedHour -> selectedColor
                        count == maxCount && count > 0 -> peakColor
                        count > 0 -> barColor
                        else -> Color.Gray.copy(alpha = 0.2f)
                    }

                    drawRoundRect(
                        color = color,
                        topLeft = Offset(left, top),
                        size = Size(barWidth, barHeight.coerceAtLeast(4.dp.toPx())),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                }
            }
        }

        // Labels for 00:00, 06:00, 12:00, 18:00, 23:00
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf("00:00", "06:00", "12:00", "18:00", "23:00").forEach { label ->
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
