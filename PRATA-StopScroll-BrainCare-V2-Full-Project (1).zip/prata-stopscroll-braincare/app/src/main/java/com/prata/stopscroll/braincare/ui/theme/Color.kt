package com.prata.stopscroll.braincare.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val CreamBackground = Color(0xFFFFF9F2)
val CreamSurface = Color(0xFFFFFFFF)
val CreamSurfaceVariant = Color(0xFFF7EFE6)
val CharcoalPrimary = Color(0xFF262626)
val CharcoalText = Color(0xFF1E1E1E)
val CharcoalSubtext = Color(0xFF6B6864)

val WarmOrange = Color(0xFFE8854A)
val WarmOrangeLight = Color(0xFFFFD8C2)
val WarmPink = Color(0xFFE07B8B)
val WarmPinkLight = Color(0xFFFFDFE5)

val SuccessGreen = Color(0xFF388E3C)
val WarningYellow = Color(0xFFF57C00)
val DangerRed = Color(0xFFD32F2F)

// Dark Theme Palette
val DarkBackground = Color(0xFF141414)
val DarkSurface = Color(0xFF1F1F1F)
val DarkSurfaceVariant = Color(0xFF2A2A2A)
val DarkText = Color(0xFFF5F5F5)
val DarkSubtext = Color(0xFFA0A0A0)

val DarkWarmOrange = Color(0xFFFF9D66)
val DarkWarmPink = Color(0xFFFF94A5)
