package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_limits",
    indices = [
        Index(value = ["date"], unique = true)
    ]
)
data class DailyLimit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val totalLimit: Int = 100,
    val currentCount: Int = 0,
    val warningShown: Boolean = false,
    val limitReached: Boolean = false,
    val userOverrode: Boolean = false
)
