package com.prata.stopscroll.braincare.domain.limit

import com.prata.stopscroll.braincare.domain.state.LimitEnforcementPolicy
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Evaluates hard scroll limits, per-app limits, daily duration limits, focus schedules,
 * warning thresholds, user exemptions, and automatic exit (`GLOBAL_ACTION_HOME`) policies (Section 3).
 */
data class FocusScheduleConfig(
    val enabled: Boolean = false,
    val startHour: Int = 22,
    val startMinute: Int = 0,
    val endHour: Int = 6,
    val endMinute: Int = 0,
    val label: String = "Jadwal Bebas Scrolling Malam"
) {
    fun isActiveAt(hour: Int, minute: Int): Boolean {
        if (!enabled) return false
        val currentMins = hour * 60 + minute
        val startMins = startHour * 60 + startMinute
        val endMins = endHour * 60 + endMinute

        return if (startMins <= endMins) {
            currentMins in startMins until endMins
        } else {
            currentMins >= startMins || currentMins < endMins
        }
    }
}

data class LimitCheckDecision(
    val isWarningReached: Boolean,
    val isLimitReached: Boolean,
    val shouldShowBlockingOverlay: Boolean,
    val shouldPerformGlobalHomeExit: Boolean,
    val shouldSendWarningNotification: Boolean,
    val shouldSendLimitNotification: Boolean,
    val blockingTitle: String,
    val blockingMessage: String,
    val policy: LimitEnforcementPolicy,
    val canSnoozeFromOverlay: Boolean
)

@Singleton
class HardLimitManager @Inject constructor() {

    private val entryPattern = Regex(""""([^"]+)"\s*:\s*(\d+)""")

    // Anti-loop cooldown tracking for automatic GLOBAL_ACTION_HOME execution (Section 3.C)
    @Volatile
    private var lastAutoExitTimestampMs: Long = 0L

    fun resetAutoExitCooldown() {
        lastAutoExitTimestampMs = 0L
    }

    /**
     * Checks whether a package is a system, emergency, dialer, settings, or PRATA package
     * that must NEVER be blocked or force-exited (Section 3.C & 3.D).
     */
    fun isProtectedSystemOrEmergencyPackage(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return true
        val lower = packageName.lowercase()
        if (PROTECTED_EXACT_PACKAGES.contains(lower)) return true
        return PROTECTED_PACKAGE_PREFIXES.any { lower.startsWith(it) }
    }

    fun parsePerAppLimits(jsonStr: String?): Map<String, Int> {
        if (jsonStr.isNullOrBlank()) return emptyMap()
        val map = mutableMapOf<String, Int>()
        for (match in entryPattern.findAll(jsonStr)) {
            val key = match.groupValues[1].trim()
            val value = match.groupValues[2].toIntOrNull() ?: 0
            if (key.isNotEmpty() && value > 0) {
                map[key] = value
            }
        }
        return map
    }

    fun serializePerAppLimits(limits: Map<String, Int>): String {
        val valid = limits.filter { it.key.isNotBlank() && it.value > 0 }
        if (valid.isEmpty()) return "{}"
        val entries = valid.entries.joinToString(",") { (k, v) ->
            val safeKey = k.replace("\"", "")
            "\"$safeKey\":$v"
        }
        return "{$entries}"
    }

    /**
     * Evaluates all configured limits, user exemptions, and automatic exit rules (Section 3.A - 3.D).
     */
    fun evaluateLimits(
        todayTotalCount: Int,
        totalDailyLimit: Int,
        activePackage: String?,
        activeAppName: String?,
        activeAppTodayCount: Int,
        perAppLimits: Map<String, Int>,
        todayUsageMs: Long,
        dailyDurationLimitMinutes: Int,
        warningThresholdPercent: Float,
        policy: LimitEnforcementPolicy,
        focusSchedule: FocusScheduleConfig,
        warningAlreadyShown: Boolean,
        limitAlreadyReached: Boolean,
        userOverrodeToday: Boolean,
        snoozeUntilTimestampMs: Long,
        exemptedPackages: Set<String> = emptySet(),
        autoExitConsentGranted: Boolean = true,
        isAccessibilityServiceActive: Boolean = true,
        isTargetInForeground: Boolean = true,
        nowTimestampMs: Long = System.currentTimeMillis()
    ): LimitCheckDecision {
        // Never block or exit protected system/emergency packages or user-exempted apps
        if (isProtectedSystemOrEmergencyPackage(activePackage) ||
            (activePackage != null && exemptedPackages.contains(activePackage))
        ) {
            return LimitCheckDecision(
                isWarningReached = false,
                isLimitReached = false,
                shouldShowBlockingOverlay = false,
                shouldPerformGlobalHomeExit = false,
                shouldSendWarningNotification = false,
                shouldSendLimitNotification = false,
                blockingTitle = "Aplikasi Dikecualikan / Sistem",
                blockingMessage = "Aplikasi ini dikecualikan dari pembatasan.",
                policy = policy,
                canSnoozeFromOverlay = true
            )
        }

        val cal = Calendar.getInstance().apply { timeInMillis = nowTimestampMs }
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)

        val scheduleActive = focusSchedule.isActiveAt(hour, minute)
        val appLimit = if (activePackage != null) perAppLimits[activePackage] else null
        val appLimitHit = appLimit != null && appLimit > 0 && activeAppTodayCount >= appLimit
        val totalLimitHit = totalDailyLimit > 0 && todayTotalCount >= totalDailyLimit
        val durationLimitHit = dailyDurationLimitMinutes > 0 &&
                (todayUsageMs / 60_000L) >= dailyDurationLimitMinutes

        val isAnyLimitReached = totalLimitHit || appLimitHit || durationLimitHit || scheduleActive

        val warningThresholdCount = (totalDailyLimit * warningThresholdPercent.coerceIn(0.5f, 0.95f)).toInt()
        val isWarningReached = !isAnyLimitReached && totalDailyLimit > 0 && todayTotalCount >= warningThresholdCount

        val isSnoozeActive = userOverrodeToday && snoozeUntilTimestampMs > nowTimestampMs

        val shouldBlock = isAnyLimitReached && !isSnoozeActive &&
                (policy == LimitEnforcementPolicy.FOCUS || policy == LimitEnforcementPolicy.STRICT)

        // Evaluate whether automatic redirection to Home screen (GLOBAL_ACTION_HOME) is permitted
        // and outside the anti-loop cooldown window (Section 3.C)
        val cooldownElapsed = (nowTimestampMs - lastAutoExitTimestampMs) >= AUTO_EXIT_COOLDOWN_MS
        val shouldAutoExit = shouldBlock &&
                isAccessibilityServiceActive &&
                isTargetInForeground &&
                autoExitConsentGranted &&
                cooldownElapsed

        if (shouldAutoExit) {
            lastAutoExitTimestampMs = nowTimestampMs
        }

        val appLabel = activeAppName ?: "Aplikasi"
        val title: String
        val message: String
        when {
            scheduleActive -> {
                title = "Jadwal Bebas Scrolling Aktif"
                message = "${focusSchedule.label} (${String.format("%02d:%02d", focusSchedule.startHour, focusSchedule.startMinute)} - ${String.format("%02d:%02d", focusSchedule.endHour, focusSchedule.endMinute)}) sedang berlangsung. Istirahatkan pikiranmu dari konten pendek."
            }
            appLimitHit -> {
                title = "Batas $appLabel Tercapai!"
                message = "Kamu telah melewati $activeAppTodayCount dari batas $appLimit konten pendek di $appLabel hari ini."
            }
            durationLimitHit -> {
                val usedMins = (todayUsageMs / 60_000L).toInt()
                title = "Batas Durasi Harian Tercapai!"
                message = "Durasi scrolling hari ini telah mencapai $usedMins menit dari batas $dailyDurationLimitMinutes menit."
            }
            totalLimitHit -> {
                title = "Batas Scrolling Harian Tercapai!"
                message = "Kamu telah menonton $todayTotalCount dari batas $totalDailyLimit konten pendek hari ini. Saatnya mengembalikan fokusmu!"
            }
            isWarningReached -> {
                title = "Mendekati Batas Harian"
                message = "Kamu sudah mencapai $todayTotalCount dari $totalDailyLimit konten pendek (${((todayTotalCount.toFloat() / totalDailyLimit) * 100).toInt()}%)."
            }
            else -> {
                title = "Fokus Terjaga"
                message = "Konsumsi konten pendek masih dalam batas aman."
            }
        }

        return LimitCheckDecision(
            isWarningReached = isWarningReached,
            isLimitReached = isAnyLimitReached,
            shouldShowBlockingOverlay = shouldBlock,
            shouldPerformGlobalHomeExit = shouldAutoExit,
            shouldSendWarningNotification = isWarningReached && !warningAlreadyShown,
            shouldSendLimitNotification = isAnyLimitReached && !limitAlreadyReached,
            blockingTitle = title,
            blockingMessage = message,
            policy = policy,
            canSnoozeFromOverlay = policy == LimitEnforcementPolicy.FOCUS
        )
    }

    companion object {
        const val AUTO_EXIT_COOLDOWN_MS = 2_500L

        private val PROTECTED_EXACT_PACKAGES = setOf(
            "com.prata.stopscroll.braincare",
            "com.prata.stopscroll.braincare.debug",
            "com.android.settings",
            "com.android.systemui",
            "com.android.phone",
            "com.android.server.telecom",
            "com.android.emergency",
            "com.google.android.dialer",
            "com.samsung.android.dialer",
            "com.android.incallui",
            "com.google.android.permissioncontroller",
            "com.android.packageinstaller"
        )

        private val PROTECTED_PACKAGE_PREFIXES = listOf(
            "com.android.emergency",
            "com.android.incallui",
            "com.android.settings"
        )
    }
}
