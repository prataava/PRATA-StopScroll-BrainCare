package com.prata.stopscroll.braincare.data.repository

import com.prata.stopscroll.braincare.data.datastore.UserSettingsDataStore
import com.prata.stopscroll.braincare.data.local.dao.QuestionnaireDao
import com.prata.stopscroll.braincare.data.local.dao.UserGoalsDao
import com.prata.stopscroll.braincare.data.local.entity.QuestionnaireResponse
import com.prata.stopscroll.braincare.data.local.entity.UserGoals
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository wrapping [UserSettingsDataStore], [UserGoalsDao], and [QuestionnaireDao]
 * to provide a unified preferences/configuration API.
 */
@Singleton
class PreferencesRepositoryImpl @Inject constructor(
    private val settingsDataStore: UserSettingsDataStore,
    private val userGoalsDao: UserGoalsDao,
    private val questionnaireDao: QuestionnaireDao
) {

    // ─── DataStore Settings ──────────────────────────────────────────────

    val onboardingCompleted: Flow<Boolean> = settingsDataStore.onboardingCompleted
    val trackingEnabled: Flow<Boolean> = settingsDataStore.trackingEnabled
    val selectedApps: Flow<Set<String>> = settingsDataStore.selectedApps
    val exemptedApps: Flow<Set<String>> = settingsDataStore.exemptedApps
    val notificationsEnabled: Flow<Boolean> = settingsDataStore.notificationsEnabled
    val aiCloudEnabled: Flow<Boolean> = settingsDataStore.aiCloudEnabled
    val aiCloudConsent: Flow<Boolean> = settingsDataStore.aiCloudConsent
    val aiCloudEndpoint: Flow<String> = settingsDataStore.aiCloudEndpoint
    val darkMode: Flow<String> = settingsDataStore.darkMode
    val language: Flow<String> = settingsDataStore.language
    val reducedMotion: Flow<Boolean> = settingsDataStore.reducedMotion
    val dataRetentionDays: Flow<Int> = settingsDataStore.dataRetentionDays

    // Floating Counter Preferences
    val floatingCounterEnabled: Flow<Boolean> = settingsDataStore.floatingCounterEnabled
    val floatingCounterSize: Flow<String> = settingsDataStore.floatingCounterSize
    val floatingCounterShowMascot: Flow<Boolean> = settingsDataStore.floatingCounterShowMascot
    val floatingCounterExpandedDefault: Flow<Boolean> = settingsDataStore.floatingCounterExpandedDefault
    val floatingCounterPosX: Flow<Int> = settingsDataStore.floatingCounterPosX
    val floatingCounterPosY: Flow<Int> = settingsDataStore.floatingCounterPosY
    val floatingCounterAnimation: Flow<Boolean> = settingsDataStore.floatingCounterAnimation

    // Limit Policy, Auto-Exit Consent, Schedules & Reminders
    val limitEnforcementPolicy: Flow<String> = settingsDataStore.limitEnforcementPolicy
    val autoExitConsentGranted: Flow<Boolean> = settingsDataStore.autoExitConsentGranted
    val strictModeConsentGranted: Flow<Boolean> = settingsDataStore.strictModeConsentGranted
    val warningThresholdPercent: Flow<Float> = settingsDataStore.warningThresholdPercent
    val dailyDurationLimitMinutes: Flow<Int> = settingsDataStore.dailyDurationLimitMinutes
    val focusScheduleEnabled: Flow<Boolean> = settingsDataStore.focusScheduleEnabled
    val focusScheduleStartHour: Flow<Int> = settingsDataStore.focusScheduleStartHour
    val focusScheduleEndHour: Flow<Int> = settingsDataStore.focusScheduleEndHour
    val breakReminderEnabled: Flow<Boolean> = settingsDataStore.breakReminderEnabled
    val breakReminderInterval: Flow<Int> = settingsDataStore.breakReminderInterval
    val snoozeUntilTimestampMs: Flow<Long> = settingsDataStore.snoozeUntilTimestampMs

    // Daily Reset & Clock Checkpoints
    val lastActiveDate: Flow<String> = settingsDataStore.lastActiveDate
    val lastWallClockMs: Flow<Long> = settingsDataStore.lastWallClockMs
    val lastElapsedRealtimeMs: Flow<Long> = settingsDataStore.lastElapsedRealtimeMs

    suspend fun setOnboardingCompleted(completed: Boolean) =
        settingsDataStore.setOnboardingCompleted(completed)

    suspend fun setTrackingEnabled(enabled: Boolean) =
        settingsDataStore.setTrackingEnabled(enabled)

    suspend fun setSelectedApps(apps: Set<String>) =
        settingsDataStore.setSelectedApps(apps)

    suspend fun addSelectedApp(packageName: String) =
        settingsDataStore.addSelectedApp(packageName)

    suspend fun removeSelectedApp(packageName: String) =
        settingsDataStore.removeSelectedApp(packageName)

    suspend fun toggleExemptedApp(packageName: String) =
        settingsDataStore.toggleExemptedApp(packageName)

    suspend fun setNotificationsEnabled(enabled: Boolean) =
        settingsDataStore.setNotificationsEnabled(enabled)

    suspend fun setAiCloudEnabled(enabled: Boolean) =
        settingsDataStore.setAiCloudEnabled(enabled)

    suspend fun setAiCloudConsent(consent: Boolean) =
        settingsDataStore.setAiCloudConsent(consent)

    suspend fun setAiCloudEndpoint(endpoint: String) =
        settingsDataStore.setAiCloudEndpoint(endpoint)

    suspend fun setDarkMode(mode: String) =
        settingsDataStore.setDarkMode(mode)

    suspend fun setLanguage(lang: String) =
        settingsDataStore.setLanguage(lang)

    suspend fun setReducedMotion(reduced: Boolean) =
        settingsDataStore.setReducedMotion(reduced)

    suspend fun setDataRetentionDays(days: Int) =
        settingsDataStore.setDataRetentionDays(days)

    // Floating Counter Setters
    suspend fun setFloatingCounterEnabled(enabled: Boolean) =
        settingsDataStore.setFloatingCounterEnabled(enabled)

    suspend fun setFloatingCounterSize(size: String) =
        settingsDataStore.setFloatingCounterSize(size)

    suspend fun setFloatingCounterShowMascot(show: Boolean) =
        settingsDataStore.setFloatingCounterShowMascot(show)

    suspend fun setFloatingCounterExpandedDefault(expanded: Boolean) =
        settingsDataStore.setFloatingCounterExpandedDefault(expanded)

    suspend fun setFloatingCounterPosition(x: Int, y: Int) =
        settingsDataStore.setFloatingCounterPosition(x, y)

    suspend fun setFloatingCounterAnimation(enabled: Boolean) =
        settingsDataStore.setFloatingCounterAnimation(enabled)

    // Limit Policy, Auto-Exit & Schedule Setters
    suspend fun setLimitEnforcementPolicy(policy: String) {
        settingsDataStore.setLimitEnforcementPolicy(policy)
        getOrCreateGoals()
        userGoalsDao.updateApproach(policy)
    }

    suspend fun setAutoExitConsentGranted(granted: Boolean) =
        settingsDataStore.setAutoExitConsentGranted(granted)

    suspend fun setStrictModeConsentGranted(granted: Boolean) =
        settingsDataStore.setStrictModeConsentGranted(granted)

    suspend fun setWarningThresholdPercent(percent: Float) =
        settingsDataStore.setWarningThresholdPercent(percent)

    suspend fun setDailyDurationLimitMinutes(minutes: Int) =
        settingsDataStore.setDailyDurationLimitMinutes(minutes)

    suspend fun setFocusSchedule(enabled: Boolean, startHour: Int, endHour: Int) =
        settingsDataStore.setFocusSchedule(enabled, startHour, endHour)

    suspend fun setBreakReminder(enabled: Boolean, intervalCount: Int) =
        settingsDataStore.setBreakReminder(enabled, intervalCount)

    suspend fun setSnoozeUntilTimestampMs(timestampMs: Long) =
        settingsDataStore.setSnoozeUntilTimestampMs(timestampMs)

    suspend fun updateClockCheckpoint(dateStr: String, wallClockMs: Long, elapsedRealtimeMs: Long) =
        settingsDataStore.updateClockCheckpoint(dateStr, wallClockMs, elapsedRealtimeMs)

    // ─── User Goals (Room) ───────────────────────────────────────────────

    suspend fun getOrCreateGoals(): UserGoals {
        return userGoalsDao.get() ?: run {
            val defaults = UserGoals()
            userGoalsDao.insertOrReplace(defaults)
            defaults
        }
    }

    fun observeGoals(): Flow<UserGoals> = userGoalsDao.observe().map { it ?: UserGoals() }

    suspend fun updateGoals(goals: UserGoals) =
        userGoalsDao.insertOrReplace(goals.copy(updatedAt = System.currentTimeMillis()))

    suspend fun updateDailyLimit(limit: Int) {
        getOrCreateGoals()
        userGoalsDao.updateDailyLimit(limit)
    }

    suspend fun updateApproach(approach: String) {
        getOrCreateGoals()
        userGoalsDao.updateApproach(approach)
    }

    suspend fun updatePerAppLimits(limitsJson: String) {
        getOrCreateGoals()
        userGoalsDao.updatePerAppLimits(limitsJson)
    }

    suspend fun updateFocusGoal(minutes: Int) {
        getOrCreateGoals()
        userGoalsDao.updateFocusGoal(minutes)
    }

    suspend fun updateDetailLevel(level: String) {
        getOrCreateGoals()
        userGoalsDao.updateDetailLevel(level)
    }

    suspend fun saveQuestionnaireResponse(response: QuestionnaireResponse): Long =
        questionnaireDao.insert(response)

    suspend fun saveQuestionnaireResponse(
        category: String,
        questionKey: String,
        answerValue: String,
        version: Int = 1
    ): Long {
        val response = QuestionnaireResponse(
            category = category,
            questionKey = questionKey,
            answerValue = answerValue,
            version = version
        )
        return questionnaireDao.insert(response)
    }

    suspend fun saveQuestionnaireResponses(responses: List<QuestionnaireResponse>) =
        questionnaireDao.insertAll(responses)

    fun getQuestionnaireByCategory(category: String): Flow<List<QuestionnaireResponse>> =
        questionnaireDao.getByCategory(category)

    fun getLatestQuestionnaireByCategory(category: String): Flow<List<QuestionnaireResponse>> =
        questionnaireDao.getLatestByCategory(category)

    suspend fun getLatestAnswerByKey(questionKey: String): QuestionnaireResponse? =
        questionnaireDao.getLatestByKey(questionKey)

    fun getAllQuestionnaireResponses(): Flow<List<QuestionnaireResponse>> =
        questionnaireDao.getAll()

    fun getCompletedCategories(): Flow<List<String>> =
        questionnaireDao.getCompletedCategories()

    suspend fun deleteQuestionnaireCategory(category: String) =
        questionnaireDao.deleteByCategory(category)
}
