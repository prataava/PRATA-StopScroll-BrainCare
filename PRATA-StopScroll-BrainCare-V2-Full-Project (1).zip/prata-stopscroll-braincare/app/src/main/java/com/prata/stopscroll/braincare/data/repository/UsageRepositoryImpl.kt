package com.prata.stopscroll.braincare.data.repository

import com.prata.stopscroll.braincare.data.local.dao.AppCount
import com.prata.stopscroll.braincare.data.local.dao.ContentTypeCount
import com.prata.stopscroll.braincare.data.local.dao.DailyCount
import com.prata.stopscroll.braincare.data.local.dao.HourlyCount
import com.prata.stopscroll.braincare.data.local.dao.ShortContentDao
import com.prata.stopscroll.braincare.data.local.dao.UsageSessionDao
import com.prata.stopscroll.braincare.data.local.entity.AppUsageSession
import com.prata.stopscroll.braincare.data.local.entity.ShortContentDetection
import com.prata.stopscroll.braincare.util.DateUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository managing app usage sessions and short-form content detections.
 * Uses timezone-aware DateUtils so midnight rollovers and session splits are consistent.
 */
@Singleton
class UsageRepositoryImpl @Inject constructor(
    private val usageSessionDao: UsageSessionDao,
    private val shortContentDao: ShortContentDao
) {

    // ─── Usage Sessions ──────────────────────────────────────────────────

    suspend fun startSession(packageName: String, appName: String): Long {
        // Close any dangling session from an abrupt service stop first
        val dangling = usageSessionDao.getActiveSession()
        val now = System.currentTimeMillis()
        if (dangling != null && dangling.endTime == null) {
            val safeDuration = (now - dangling.startTime).coerceIn(0L, 4 * 3600_000L)
            usageSessionDao.update(
                dangling.copy(
                    endTime = now,
                    durationMs = safeDuration
                )
            )
        }

        val session = AppUsageSession(
            packageName = packageName,
            appName = appName,
            startTime = now,
            date = DateUtils.formatDate(now)
        )
        return usageSessionDao.insert(session)
    }

    suspend fun endSession(sessionId: Long) {
        val session = usageSessionDao.getById(sessionId) ?: return
        val now = System.currentTimeMillis()
        val duration = (now - session.startTime).coerceAtLeast(0L)
        usageSessionDao.update(
            session.copy(
                endTime = now,
                durationMs = duration
            )
        )
    }

    suspend fun updateSessionShortContentCount(sessionId: Long, count: Int) {
        val session = usageSessionDao.getById(sessionId) ?: return
        val now = System.currentTimeMillis()
        val duration = (now - session.startTime).coerceAtLeast(session.durationMs)
        usageSessionDao.update(
            session.copy(
                shortContentCount = count,
                durationMs = duration
            )
        )
    }

    suspend fun getActiveSession(): AppUsageSession? =
        usageSessionDao.getActiveSession()

    suspend fun getActiveSessionForPackage(packageName: String): AppUsageSession? =
        usageSessionDao.getActiveSessionForPackage(packageName)

    fun getSessionsByDate(date: String): Flow<List<AppUsageSession>> =
        usageSessionDao.getByDate(date)

    fun getSessionsByPackageAndDate(packageName: String, date: String): Flow<List<AppUsageSession>> =
        usageSessionDao.getByPackageAndDate(packageName, date)

    fun getSessionsByTimeRange(startTime: Long, endTime: Long): Flow<List<AppUsageSession>> =
        usageSessionDao.getByTimeRange(startTime, endTime)

    fun getTotalDurationByDate(date: String): Flow<Long?> =
        usageSessionDao.getTotalDurationByDate(date)

    fun getTotalDurationByPackageAndDate(packageName: String, date: String): Flow<Long?> =
        usageSessionDao.getTotalDurationByPackageAndDate(packageName, date)

    fun getSessionCountByDate(date: String): Flow<Int> =
        usageSessionDao.getSessionCountByDate(date)

    fun getActivePackagesByDate(date: String): Flow<List<String>> =
        usageSessionDao.getActivePackagesByDate(date)

    // ─── Short Content Detections ────────────────────────────────────────

    suspend fun recordShortContent(detection: ShortContentDetection): Long =
        shortContentDao.insert(detection)

    suspend fun getShortContentCountForDate(date: String): Int =
        shortContentDao.getCountByDate(date).first()

    suspend fun getShortContentCountForPackageAndDate(packageName: String, date: String): Int =
        shortContentDao.getCountByPackageAndDate(packageName, date).first()

    suspend fun getContentCountByAppForDate(date: String): List<AppCount> =
        shortContentDao.getAppDistribution(date).first()

    suspend fun getHourlyCountForDate(date: String): List<HourlyCount> =
        shortContentDao.getHourlyDistribution(date).first()

    fun getRecentSessions(limit: Int = 100): Flow<List<AppUsageSession>> =
        usageSessionDao.getByTimeRange(0L, Long.MAX_VALUE)

    suspend fun recordShortContent(
        packageName: String,
        appName: String,
        contentType: String,
        sessionId: Long? = null
    ): Long {
        val now = System.currentTimeMillis()
        val calendar = Calendar.getInstance().apply { timeInMillis = now }
        val detection = ShortContentDetection(
            packageName = packageName,
            appName = appName,
            detectedAt = now,
            contentType = contentType,
            sessionId = sessionId,
            date = DateUtils.formatDate(now),
            hour = calendar.get(Calendar.HOUR_OF_DAY)
        )
        return shortContentDao.insert(detection)
    }

    suspend fun isDuplicate(packageName: String, windowMs: Long = 1200L): Boolean {
        val now = System.currentTimeMillis()
        return shortContentDao.existsInTimeRange(packageName, now - windowMs, now)
    }

    fun getShortContentByDate(date: String): Flow<List<ShortContentDetection>> =
        shortContentDao.getByDate(date)

    fun getShortContentByPackageAndDate(packageName: String, date: String): Flow<List<ShortContentDetection>> =
        shortContentDao.getByPackageAndDate(packageName, date)

    fun getShortContentCountByDate(date: String): Flow<Int> =
        shortContentDao.getCountByDate(date)

    fun getShortContentCountByPackageAndDate(packageName: String, date: String): Flow<Int> =
        shortContentDao.getCountByPackageAndDate(packageName, date)

    fun getHourlyDistribution(date: String): Flow<List<HourlyCount>> =
        shortContentDao.getHourlyDistribution(date)

    fun getHourlyDistributionRange(startDate: String, endDate: String): Flow<List<HourlyCount>> =
        shortContentDao.getHourlyDistributionRange(startDate, endDate)

    fun getContentTypeDistribution(date: String): Flow<List<ContentTypeCount>> =
        shortContentDao.getContentTypeDistribution(date)

    fun getAppDistribution(date: String): Flow<List<AppCount>> =
        shortContentDao.getAppDistribution(date)

    fun getDailyCountsRange(startDate: String, endDate: String): Flow<List<DailyCount>> =
        shortContentDao.getDailyCountsRange(startDate, endDate)

    // ─── Data Retention ──────────────────────────────────────────────────

    suspend fun cleanupOldData(retentionDays: Int) {
        val safeDays = retentionDays.coerceAtLeast(30)
        val cutoffDate = DateUtils.daysAgo(safeDays)
        usageSessionDao.deleteOlderThan(cutoffDate)
        shortContentDao.deleteOlderThan(cutoffDate)
    }
}
