package com.prata.stopscroll.braincare.domain.ai

import com.prata.stopscroll.braincare.data.local.entity.BehaviorInsight
import com.prata.stopscroll.braincare.data.repository.AIRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.UsageRepositoryImpl
import com.prata.stopscroll.braincare.util.DateUtils
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BehaviorAnalyzer @Inject constructor(
    private val usageRepository: UsageRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl,
    private val aiRepository: AIRepositoryImpl
) {

    suspend fun analyzeAndGenerateInsights(): List<BehaviorInsight> {
        val today = DateUtils.today()
        val sevenDaysAgo = DateUtils.daysAgo(7)

        val recentStats = statsRepository.getDailyStatsRange(sevenDaysAgo, today).firstOrNull() ?: emptyList()

        if (recentStats.size < 3) {
            // Insufficient data notice
            val existing = aiRepository.getRecentInsights(1).firstOrNull()
            if (existing.isNullOrEmpty()) {
                val insight = BehaviorInsight(
                    type = "BASELINE",
                    title = "Mengumpulkan Pola Kebiasaan",
                    description = "PRATA masih mengumpulkan pola penggunaanmu. Insight personal akan tersedia setelah data mencukupi (minimal 3 hari pemakaian).",
                    dataStartDate = sevenDaysAgo,
                    dataEndDate = today,
                    confidence = "LOW"
                )
                aiRepository.saveInsight(insight)
                return listOf(insight)
            }
            return emptyList()
        }

        val insights = mutableListOf<BehaviorInsight>()

        // 1. Peak Scrolling Hours Analysis
        val hourlyDistribution = usageRepository.getHourlyCountForDate(today)
        if (hourlyDistribution.isNotEmpty()) {
            val peakHour = hourlyDistribution.maxByOrNull { it.count }
            if (peakHour != null && peakHour.count > 10) {
                val peakRange = "${String.format("%02d:00", peakHour.hour)} - ${String.format("%02d:00", (peakHour.hour + 1) % 24)}"
                val peakInsight = BehaviorInsight(
                    type = "PEAK_HOURS",
                    title = "Jam Paling Aktif",
                    description = "Aktivitas scrolling tertinggi tercatat pada $peakRange dengan total ${peakHour.count} konten pendek. Pertimbangkan menjadwalkan jeda fokus pada jam ini.",
                    dataStartDate = today,
                    dataEndDate = today,
                    confidence = "HIGH"
                )
                aiRepository.saveInsight(peakInsight)
                insights.add(peakInsight)
            }
        }

        // 2. Weekly Trend Analysis (Moving Average)
        val validDays = recentStats.filter { it.totalShortContent > 0 }
        if (validDays.size >= 4) {
            val avgShorts = validDays.map { it.totalShortContent }.average().toInt()
            val latest = validDays.last().totalShortContent
            val diffPercent = if (avgShorts > 0) ((latest - avgShorts).toFloat() / avgShorts * 100).toInt() else 0

            val trendTitle: String
            val trendDesc: String
            if (diffPercent < -15) {
                trendTitle = "Tren Penurunan Scrolling"
                trendDesc = "Hebat! Penggunaan hari ini ($latest konten) 15%+ lebih rendah dibanding rata-rata 7 hari terakhirmu ($avgShorts konten)."
            } else if (diffPercent > 20) {
                trendTitle = "Peningkatan Frekuensi Scrolling"
                trendDesc = "Aktivitas scrolling hari ini ($latest konten) meningkat $diffPercent% dari rata-rata mingguan ($avgShorts konten). Luangkan waktu untuk istirahat mata dan pikiran."
            } else {
                trendTitle = "Pola Penggunaan Stabil"
                trendDesc = "Tingkat scrolling harianmu berada dalam kisaran rata-rata mingguan sekitar $avgShorts konten per hari."
            }

            val trendInsight = BehaviorInsight(
                type = "TREND",
                title = trendTitle,
                description = trendDesc,
                dataStartDate = sevenDaysAgo,
                dataEndDate = today,
                confidence = if (validDays.size >= 6) "HIGH" else "MEDIUM"
            )
            aiRepository.saveInsight(trendInsight)
            insights.add(trendInsight)
        }

        // 3. Top Consumed App Analysis
        val topApps = usageRepository.getContentCountByAppForDate(today)
        if (topApps.isNotEmpty()) {
            val mostUsed = topApps.maxByOrNull { it.count }
            if (mostUsed != null && mostUsed.count > 15) {
                val appInsight = BehaviorInsight(
                    type = "PATTERN",
                    title = "Fokus Distraksi Utama",
                    description = "${mostUsed.appName} menyumbang ${mostUsed.count} konten pendek hari ini. Ini adalah aplikasi dengan scrolling tertinggi.",
                    dataStartDate = today,
                    dataEndDate = today,
                    confidence = "HIGH"
                )
                aiRepository.saveInsight(appInsight)
                insights.add(appInsight)
            }
        }

        return insights
    }
}
