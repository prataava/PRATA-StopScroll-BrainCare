package com.prata.stopscroll.braincare.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.prata.stopscroll.braincare.MainActivity
import com.prata.stopscroll.braincare.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val notificationManager: NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val monitoringChannel = NotificationChannel(
                Constants.CHANNEL_MONITORING,
                "Pemantauan Latar Belakang PRATA",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menampilkan status pelacakan konten pendek secara real-time"
                setShowBadge(false)
            }

            val alertsChannel = NotificationChannel(
                Constants.CHANNEL_ALERTS,
                "Peringatan & Batas Scrolling",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Peringatan saat mendekati atau mencapai batas harian scrolling"
                enableVibration(true)
                setShowBadge(true)
            }

            val insightsChannel = NotificationChannel(
                Constants.CHANNEL_INSIGHTS,
                "AI Insights & Rekomendasi",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Insight perilaku dan evaluasi kebiasaan digital harian"
            }

            val focusChannel = NotificationChannel(
                Constants.CHANNEL_FOCUS,
                "Mode Fokus & Pengingat Istirahat",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifikasi timer fokus dan pengingat istirahat berkala"
            }

            notificationManager.createNotificationChannels(
                listOf(monitoringChannel, alertsChannel, insightsChannel, focusChannel)
            )
        }
    }

    private fun getAppPendingIntent(): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        return PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun buildMonitoringNotification(shortCount: Int, limit: Int): Notification {
        val title = "PRATA StopScroll BrainCare Aktif"
        val content = "Hari ini: $shortCount / $limit konten pendek terdeteksi"

        return NotificationCompat.Builder(context, Constants.CHANNEL_MONITORING)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setContentIntent(getAppPendingIntent())
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    fun showLimitWarningNotification(currentCount: Int, limit: Int) {
        val notification = NotificationCompat.Builder(context, Constants.CHANNEL_ALERTS)
            .setContentTitle("⚠️ Mendekati Batas Scrolling Harian")
            .setContentText("Kamu sudah menonton $currentCount dari batas $limit konten pendek hari ini. Yuk istirahatkan mata sejenak!")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(getAppPendingIntent())
            .build()

        try {
            NotificationManagerCompat.from(context).notify(Constants.NOTIF_ID_LIMIT_WARNING, notification)
        } catch (_: SecurityException) {
        }
    }

    fun showLimitReachedNotification(currentCount: Int, limit: Int, reason: String? = null) {
        val body = reason ?: "Batas $limit konten pendek telah tercapai ($currentCount ditonton). Kembalikan fokusmu sekarang!"
        val notification = NotificationCompat.Builder(context, Constants.CHANNEL_ALERTS)
            .setContentTitle("🛑 Batas Scrolling Tercapai!")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(getAppPendingIntent())
            .build()

        try {
            NotificationManagerCompat.from(context).notify(Constants.NOTIF_ID_LIMIT_REACHED, notification)
        } catch (_: SecurityException) {
        }
    }

    fun showBreakReminderNotification(currentCount: Int, sessionCount: Int) {
        val body = "Kamu telah menonton $sessionCount video pendek berturut-turut (total $currentCount hari ini). Alihkan pandangan 20 detik dari layar."
        val notification = NotificationCompat.Builder(context, Constants.CHANNEL_FOCUS)
            .setContentTitle("🌿 Waktunya Istirahat Mata & Otak")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(getAppPendingIntent())
            .build()

        try {
            NotificationManagerCompat.from(context).notify(Constants.NOTIF_ID_BREAK_REMINDER, notification)
        } catch (_: SecurityException) {
        }
    }

    fun showInsightNotification(title: String, description: String) {
        val notification = NotificationCompat.Builder(context, Constants.CHANNEL_INSIGHTS)
            .setContentTitle(title)
            .setContentText(description)
            .setStyle(NotificationCompat.BigTextStyle().bigText(description))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(getAppPendingIntent())
            .build()

        try {
            NotificationManagerCompat.from(context).notify(Constants.NOTIF_ID_INSIGHT, notification)
        } catch (_: SecurityException) {
        }
    }
}
