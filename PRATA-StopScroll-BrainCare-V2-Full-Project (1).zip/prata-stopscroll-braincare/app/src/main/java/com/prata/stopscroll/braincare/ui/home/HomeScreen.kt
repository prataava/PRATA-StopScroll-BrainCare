package com.prata.stopscroll.braincare.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.prata.stopscroll.braincare.R
import com.prata.stopscroll.braincare.domain.state.MascotMoodState
import com.prata.stopscroll.braincare.ui.components.AppDistributionBar
import com.prata.stopscroll.braincare.ui.components.FocusTimerDialog
import com.prata.stopscroll.braincare.ui.components.MascotWidget
import com.prata.stopscroll.braincare.ui.components.PrataBrainMascotIllustration
import com.prata.stopscroll.braincare.ui.components.PrataEmptyStateCard
import com.prata.stopscroll.braincare.ui.components.getSocialAppIconRes
import com.prata.stopscroll.braincare.ui.theme.DangerRed
import com.prata.stopscroll.braincare.ui.theme.SuccessGreen
import com.prata.stopscroll.braincare.ui.theme.WarmOrange
import com.prata.stopscroll.braincare.ui.theme.WarmPink
import com.prata.stopscroll.braincare.util.DateUtils
import com.prata.stopscroll.braincare.util.PermissionUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToInsights: () -> Unit,
    onNavigateToAICoach: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showFocusDialog by remember { mutableStateOf(false) }
    var showQuickLimitDialog by remember { mutableStateOf(false) }
    var showDetectionHistory by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.loadData()
    }

    if (showFocusDialog) {
        FocusTimerDialog(
            initialMinutes = 25,
            onDismiss = { showFocusDialog = false },
            onSessionCompleted = { mins, interruptions ->
                viewModel.recordFocusSession(mins, interruptions)
            }
        )
    }

    if (showQuickLimitDialog) {
        var sliderLimit by remember { mutableIntStateOf(uiState.dailyLimit) }
        AlertDialog(
            onDismissRequest = { showQuickLimitDialog = false },
            title = { Text("Sesuaikan Batas Harian (Konfirmasi)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Mengubah batas memerlukan konfirmasi sadar agar target kontrol digitalmu tetap terjaga.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Batas Baru: $sliderLimit konten pendek / hari",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = WarmOrange
                    )
                    Slider(
                        value = sliderLimit.toFloat(),
                        onValueChange = { sliderLimit = it.toInt() },
                        valueRange = 20f..300f,
                        steps = 27
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateDailyLimitConfirmed(sliderLimit)
                        showQuickLimitDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WarmOrange)
                ) {
                    Text("Konfirmasi & Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickLimitDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "PRATA StopScroll",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "${DateUtils.formatDisplayDate(DateUtils.today())} • ${uiState.enforcementPolicy.title}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    MascotWidget(
                        currentCount = uiState.todayShortCount,
                        limit = uiState.dailyLimit,
                        isTrackingPaused = !uiState.isTrackingEnabled,
                        reducedMotion = uiState.reducedMotion,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ─── Accessibility Warning Banner (if not active) ────────────────
            if (!uiState.isAccessibilityActive) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Warning,
                                contentDescription = "Peringatan Izin",
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Accessibility Service Belum Aktif",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Text(
                                    text = "Aktifkan agar penghitung real-time, floating counter, dan pembatas otomatis dapat bekerja.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            Button(
                                onClick = { PermissionUtils.openAccessibilitySettings(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("Aktifkan")
                            }
                        }
                    }
                }
            }

            // ─── Hard Limit Reached Alert Banner ─────────────────────────────
            if (uiState.limitReached) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.14f)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.il_limit_reached),
                                contentDescription = "Batas Tercapai",
                                modifier = Modifier.size(52.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Batas Scrolling Harian Tercapai!",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = DangerRed
                                )
                                Text(
                                    text = "Status: LIMIT_REACHED (${uiState.enforcementPolicy.title} Aktif). Pembatas otomatis akan melindungi fokusmu saat aplikasi target dibuka.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // ─── Main Counter, Brain Mascot & Daily Progress Card ────────────
            item {
                val ratio = if (uiState.dailyLimit > 0) {
                    (uiState.todayShortCount.toFloat() / uiState.dailyLimit).coerceIn(0f, 1f)
                } else 0f

                val animDuration = if (uiState.reducedMotion) 0 else 750
                val animatedProgress by animateFloatAsState(
                    targetValue = ratio,
                    animationSpec = tween(animDuration),
                    label = "limit_progress"
                )
                val animatedCount by animateIntAsState(
                    targetValue = uiState.todayShortCount,
                    animationSpec = tween(if (uiState.reducedMotion) 0 else 450),
                    label = "counter_anim"
                )

                val mascotMood = when {
                    !uiState.isTrackingEnabled -> MascotMoodState.RESTING
                    ratio >= 1.0f -> MascotMoodState.OVERLOADED
                    ratio >= 0.8f -> MascotMoodState.TIRED
                    ratio >= 0.45f -> MascotMoodState.FOCUSED
                    else -> MascotMoodState.FRESH
                }

                Card(
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.clickable { showQuickLimitDialog = true }
                            ) {
                                Text(
                                    text = "Target: ${uiState.dailyLimit} Konten",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "Ubah Batas",
                                    tint = WarmOrange,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            // Live Tracking Toggle Pill
                            Row(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(
                                        if (uiState.isTrackingEnabled) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .clickable { viewModel.toggleTracking() }
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (uiState.isTrackingEnabled) SuccessGreen else Color.Gray
                                        )
                                )
                                Text(
                                    text = if (uiState.isTrackingEnabled) "Tracking Aktif" else "Tracking Dijeda",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Circular Counter Visual with Embedded PRATA Mascot
                        Box(
                            modifier = Modifier.size(210.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier.size(196.dp),
                                color = when {
                                    ratio >= 1.0f -> DangerRed
                                    ratio >= 0.8f -> WarmOrange
                                    else -> WarmPink
                                },
                                strokeWidth = 14.dp,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                PrataBrainMascotIllustration(
                                    mood = mascotMood,
                                    size = 56.dp,
                                    reducedMotion = uiState.reducedMotion
                                )
                                Text(
                                    text = "$animatedCount",
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        fontSize = 40.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "dari ${uiState.dailyLimit} video pendek",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Floating Counter Live Indicator Row
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.toggleFloatingCounter() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_floating_counter_badge),
                                        contentDescription = "Floating Counter",
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Column {
                                        Text(
                                            text = "Floating Counter Otomatis: [PRATA] ${uiState.todayShortCount} / ${uiState.dailyLimit}",
                                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (uiState.isFloatingCounterEnabled)
                                                "Tampil otomatis saat membuka TikTok, Reels & Shorts"
                                            else "Floating counter sedang dinonaktifkan",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Switch(
                                    checked = uiState.isFloatingCounterEnabled,
                                    onCheckedChange = { viewModel.toggleFloatingCounter() }
                                )
                            }
                        }
                    }
                }
            }

            // ─── Quick Actions: Focus Timer, Streak, AI Coach ────────────────
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showFocusDialog = true },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Timer,
                                contentDescription = "Focus Timer",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Focus Timer",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = if (uiState.todayFocusMinutes > 0) "${uiState.todayFocusMinutes}m selesai hari ini" else "Mulai 25 Menit",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToAICoach() },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocalFireDepartment,
                                contentDescription = "Streak",
                                tint = WarmOrange
                            )
                            Text(
                                text = "${uiState.streakDays} Hari Streak",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = "Konsultasi AI Coach →",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }

            // ─── AI Recommendation Card (if any pending) ─────────────────────
            if (uiState.pendingRecommendations.isNotEmpty()) {
                val rec = uiState.pendingRecommendations.first()
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.il_ai_coach),
                                    contentDescription = "AI Recommendation",
                                    modifier = Modifier.size(28.dp)
                                )
                                Text(
                                    text = rec.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = rec.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Analisis Data: ${rec.reasoning}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { viewModel.dismissRecommendation(rec.id) }) {
                                    Text("Nanti")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { viewModel.acceptRecommendation(rec.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = WarmOrange)
                                ) {
                                    Text("Terapkan")
                                }
                            }
                        }
                    }
                }
            }

            // ─── Per-App Breakdown Section with Custom Icons & Progress ──────
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Konsumsi Per Aplikasi Hari Ini",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = onNavigateToInsights) {
                        Text("Lihat Grafik →")
                    }
                }
            }

            if (uiState.appBreakdown.isEmpty()) {
                item {
                    PrataEmptyStateCard(
                        title = "Belum Ada Aktivitas Video Pendek Hari Ini",
                        subtitle = "Saat kamu menggulir TikTok, Instagram Reels, atau YouTube Shorts, hitungan terverifikasi akan muncul secara real-time di sini.",
                        illustrationRes = R.drawable.il_empty_state
                    )
                }
            } else {
                val maxAppCount = (uiState.appBreakdown.maxOfOrNull { it.count } ?: 1).coerceAtLeast(10)
                items(uiState.appBreakdown) { app ->
                    val appLimit = uiState.perAppLimits[app.packageName]
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Image(
                                        painter = painterResource(id = getSocialAppIconRes(app.packageName)),
                                        contentDescription = app.appName,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Column {
                                        Text(
                                            text = app.appName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (appLimit != null && appLimit > 0)
                                                "Batas Aplikasi: ${app.count} / $appLimit video"
                                            else "Terdeteksi dengan keyakinan tinggi",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Text(
                                    text = "${app.count} konten",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = WarmOrange
                                )
                            }
                            AppDistributionBar(
                                appName = app.appName,
                                packageName = app.packageName,
                                count = app.count,
                                maxCount = appLimit ?: maxAppCount,
                                appLimit = appLimit
                            )
                        }
                    }
                }
            }

            // ─── Expandable Real-Time Detection History Card ─────────────────
            if (uiState.recentDetections.isNotEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showDetectionHistory = !showDetectionHistory },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Riwayat Deteksi Terakhir (${uiState.recentDetections.size})",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(
                                    imageVector = if (showDetectionHistory) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                    contentDescription = "Perluas Riwayat"
                                )
                            }

                            AnimatedVisibility(visible = showDetectionHistory) {
                                Column(
                                    modifier = Modifier.padding(top = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    uiState.recentDetections.take(8).forEach { det ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${det.appName} (${det.contentType})",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${DateUtils.formatTime(det.detectedAt)} • HIGH_CONFIDENCE",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }
}
