package com.prata.stopscroll.braincare

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.prata.stopscroll.braincare.util.Constants
import com.prata.stopscroll.braincare.util.NotificationHelper
import com.prata.stopscroll.braincare.worker.DailyResetWorker
import com.prata.stopscroll.braincare.worker.InsightGenerationWorker
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class PrataApplication : Application() {

    @Inject
    lateinit var notificationHelper: NotificationHelper

    override fun onCreate() {
        super.onCreate()
        instance = this

        notificationHelper.createNotificationChannels()
        schedulePeriodicWorkers()
    }

    private fun schedulePeriodicWorkers() {
        val workManager = WorkManager.getInstance(this)

        // Run daily reset worker every 24 hours
        val dailyResetRequest = PeriodicWorkRequestBuilder<DailyResetWorker>(24, TimeUnit.HOURS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            Constants.WORK_DAILY_RESET,
            ExistingPeriodicWorkPolicy.KEEP,
            dailyResetRequest
        )

        // Run insight generation worker every 6 hours
        val insightGenRequest = PeriodicWorkRequestBuilder<InsightGenerationWorker>(6, TimeUnit.HOURS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            Constants.WORK_INSIGHT_GEN,
            ExistingPeriodicWorkPolicy.KEEP,
            insightGenRequest
        )
    }

    companion object {
        lateinit var instance: PrataApplication
            private set
    }
}
