package com.prata.stopscroll.braincare.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.prata.stopscroll.braincare.R
import com.prata.stopscroll.braincare.domain.state.MascotMoodState
import com.prata.stopscroll.braincare.ui.theme.CharcoalPrimary
import com.prata.stopscroll.braincare.ui.theme.DangerRed
import com.prata.stopscroll.braincare.ui.theme.SuccessGreen
import com.prata.stopscroll.braincare.ui.theme.WarmOrange
import com.prata.stopscroll.braincare.ui.theme.WarmPink
import com.prata.stopscroll.braincare.util.Constants

/**
 * Maps social media package names to local vector drawable icons (Requirement J).
 */
@DrawableRes
fun getSocialAppIconRes(packageName: String): Int {
    return when (packageName) {
        Constants.PKG_TIKTOK, Constants.PKG_TIKTOK_ALT, Constants.PKG_TIKTOK_LITE -> R.drawable.ic_social_tiktok
        Constants.PKG_INSTAGRAM, Constants.PKG_INSTAGRAM_LITE -> R.drawable.ic_social_instagram
        Constants.PKG_YOUTUBE -> R.drawable.ic_social_youtube
        Constants.PKG_FACEBOOK, Constants.PKG_FACEBOOK_LITE -> R.drawable.ic_social_facebook
        Constants.PKG_SNAPCHAT -> R.drawable.ic_social_snapchat
        else -> R.drawable.ic_floating_counter_badge
    }
}

/**
 * Maps mascot mood state to its local vector drawable resource.
 */
@DrawableRes
fun getMascotDrawableRes(mood: MascotMoodState): Int {
    return when (mood) {
        MascotMoodState.FRESH -> R.drawable.ic_mascot_brain_main
        MascotMoodState.FOCUSED -> R.drawable.ic_mascot_focused
        MascotMoodState.TIRED -> R.drawable.ic_mascot_tired
        MascotMoodState.OVERLOADED -> R.drawable.ic_mascot_overload
        MascotMoodState.RESTING -> R.drawable.ic_mascot_brain_main
    }
}

/**
 * Renders the animated PRATA Brain Mascot Illustration with reducedMotion support (Requirements J & K).
 */
@Composable
fun PrataBrainMascotIllustration(
    mood: MascotMoodState,
    size: Dp = 88.dp,
    reducedMotion: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "brain_mascot_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = if (reducedMotion) 1.0f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val effectiveScale = if (reducedMotion) 1f else pulseScale

    Box(
        modifier = modifier
            .size(size)
            .scale(effectiveScale),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = getMascotDrawableRes(mood)),
            contentDescription = mood.label,
            modifier = Modifier.size(size)
        )
    }
}

/**
 * Reusable local Empty State Illustration card so no screen ever shows a plain empty box (Requirement J).
 */
@Composable
fun PrataEmptyStateCard(
    title: String,
    subtitle: String,
    @DrawableRes illustrationRes: Int = R.drawable.il_empty_state,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = illustrationRes),
                contentDescription = title,
                modifier = Modifier.size(84.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Interactive Per-App Horizontal Distribution Bar Chart (Requirement I & K).
 */
@Composable
fun AppDistributionBar(
    appName: String,
    packageName: String,
    count: Int,
    maxCount: Int,
    appLimit: Int? = null,
    modifier: Modifier = Modifier
) {
    val ratio = if (maxCount > 0) (count.toFloat() / maxCount).coerceIn(0.05f, 1f) else 0.05f
    val isOverAppLimit = appLimit != null && appLimit > 0 && count >= appLimit
    val barColor = when {
        isOverAppLimit -> DangerRed
        packageName.contains("tiktok") -> WarmPink
        packageName.contains("instagram") -> WarmOrange
        packageName.contains("youtube") -> Color(0xFFE53935)
        else -> CharcoalPrimary
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape)
    ) {
        drawRoundRect(
            color = barColor.copy(alpha = 0.18f),
            size = Size(size.width, size.height),
            cornerRadius = CornerRadius(size.height / 2, size.height / 2)
        )
        drawRoundRect(
            color = barColor,
            size = Size(size.width * ratio, size.height),
            cornerRadius = CornerRadius(size.height / 2, size.height / 2)
        )
    }
}
