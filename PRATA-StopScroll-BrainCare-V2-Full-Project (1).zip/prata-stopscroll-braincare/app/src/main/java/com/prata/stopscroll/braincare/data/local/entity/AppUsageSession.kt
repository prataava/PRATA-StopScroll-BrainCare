package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "app_usage_sessions",
    indices = [
        Index("packageName"),
        Index("startTime")
    ]
)
data class AppUsageSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val startTime: Long, // epoch millis
    val endTime: Long? = null,
    val durationMs: Long = 0,
    val shortContentCount: Int = 0,
    val date: String // yyyy-MM-dd
)
