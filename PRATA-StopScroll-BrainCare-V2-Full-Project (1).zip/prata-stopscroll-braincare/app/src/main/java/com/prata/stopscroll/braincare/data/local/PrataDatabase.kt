package com.prata.stopscroll.braincare.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.prata.stopscroll.braincare.data.local.dao.AIConversationDao
import com.prata.stopscroll.braincare.data.local.dao.AIRecommendationDao
import com.prata.stopscroll.braincare.data.local.dao.AppStatsDao
import com.prata.stopscroll.braincare.data.local.dao.ChallengeDao
import com.prata.stopscroll.braincare.data.local.dao.DailyLimitDao
import com.prata.stopscroll.braincare.data.local.dao.DailyStatsDao
import com.prata.stopscroll.braincare.data.local.dao.FocusSessionDao
import com.prata.stopscroll.braincare.data.local.dao.InsightDao
import com.prata.stopscroll.braincare.data.local.dao.NotificationDao
import com.prata.stopscroll.braincare.data.local.dao.QuestionnaireDao
import com.prata.stopscroll.braincare.data.local.dao.ShortContentDao
import com.prata.stopscroll.braincare.data.local.dao.UsageSessionDao
import com.prata.stopscroll.braincare.data.local.dao.UserGoalsDao
import com.prata.stopscroll.braincare.data.local.entity.AIConversation
import com.prata.stopscroll.braincare.data.local.entity.AIMessage
import com.prata.stopscroll.braincare.data.local.entity.AIRecommendation
import com.prata.stopscroll.braincare.data.local.entity.AppStatistics
import com.prata.stopscroll.braincare.data.local.entity.AppUsageSession
import com.prata.stopscroll.braincare.data.local.entity.BehaviorInsight
import com.prata.stopscroll.braincare.data.local.entity.ChallengeProgress
import com.prata.stopscroll.braincare.data.local.entity.DailyLimit
import com.prata.stopscroll.braincare.data.local.entity.DailyStatistics
import com.prata.stopscroll.braincare.data.local.entity.FocusSession
import com.prata.stopscroll.braincare.data.local.entity.NotificationRecord
import com.prata.stopscroll.braincare.data.local.entity.QuestionnaireResponse
import com.prata.stopscroll.braincare.data.local.entity.ShortContentDetection
import com.prata.stopscroll.braincare.data.local.entity.UserGoals

@Database(
    entities = [
        AppUsageSession::class,
        ShortContentDetection::class,
        DailyStatistics::class,
        AppStatistics::class,
        UserGoals::class,
        DailyLimit::class,
        FocusSession::class,
        NotificationRecord::class,
        QuestionnaireResponse::class,
        BehaviorInsight::class,
        AIConversation::class,
        AIMessage::class,
        AIRecommendation::class,
        ChallengeProgress::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PrataDatabase : RoomDatabase() {

    abstract fun usageSessionDao(): UsageSessionDao
    abstract fun shortContentDao(): ShortContentDao
    abstract fun dailyStatsDao(): DailyStatsDao
    abstract fun appStatsDao(): AppStatsDao
    abstract fun userGoalsDao(): UserGoalsDao
    abstract fun dailyLimitDao(): DailyLimitDao
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun notificationDao(): NotificationDao
    abstract fun questionnaireDao(): QuestionnaireDao
    abstract fun insightDao(): InsightDao
    abstract fun aiConversationDao(): AIConversationDao
    abstract fun aiRecommendationDao(): AIRecommendationDao
    abstract fun challengeDao(): ChallengeDao

    companion object {
        const val DATABASE_NAME = "prata_braincare_db"
    }
}
