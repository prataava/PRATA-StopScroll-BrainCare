package com.prata.stopscroll.braincare.di

import com.prata.stopscroll.braincare.data.repository.*
import com.prata.stopscroll.braincare.domain.ai.BehaviorAnalyzer
import com.prata.stopscroll.braincare.domain.detection.ShortContentDetectionEngine
import com.prata.stopscroll.braincare.domain.limit.HardLimitManager
import com.prata.stopscroll.braincare.domain.state.TrackingStateMachine
import com.prata.stopscroll.braincare.util.NotificationHelper
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@EntryPoint
@InstallIn(SingletonComponent::class)
interface ServiceEntryPoint {
    fun usageRepository(): UsageRepositoryImpl
    fun statsRepository(): StatsRepositoryImpl
    fun preferencesRepository(): PreferencesRepositoryImpl
    fun aiRepository(): AIRepositoryImpl
    fun challengeRepository(): ChallengeRepositoryImpl
    fun notificationHelper(): NotificationHelper
    fun behaviorAnalyzer(): BehaviorAnalyzer
    fun trackingStateMachine(): TrackingStateMachine
    fun shortContentDetectionEngine(): ShortContentDetectionEngine
    fun hardLimitManager(): HardLimitManager
}
