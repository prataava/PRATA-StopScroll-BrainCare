package com.prata.stopscroll.braincare.domain.detection

import com.prata.stopscroll.braincare.domain.state.ContentDeduplicationState
import com.prata.stopscroll.braincare.domain.state.DetectionConfidence
import com.prata.stopscroll.braincare.util.Constants
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

/**
 * Pure, testable UI representation extracted from AccessibilityNodeInfo and AccessibilityEvent.
 * Allows deterministic unit testing of precision, recall, false positives, and false negatives
 * against ground-truth datasets without requiring Android framework mocks.
 */
data class AccessibilitySignalInput(
    val packageName: String,
    val eventType: Int, // 32 = WINDOW_STATE_CHANGED, 4096 = VIEW_SCROLLED, 2048 = WINDOW_CONTENT_CHANGED
    val timestampMs: Long,
    val className: String = "",
    val scrollDeltaY: Int = 0,
    val scrollDeltaX: Int = 0,
    val fromIndex: Int = -1,
    val toIndex: Int = -1,
    val itemCount: Int = -1,
    val visibleViewIds: List<String> = emptyList(),
    val visibleTexts: List<String> = emptyList(),
    val visibleContentDescriptions: List<String> = emptyList(),
    val hasVerticalPagerNode: Boolean = false
)

/**
 * Per-application detection rule configuration (Requirement C.1 & C.2).
 * Can be updated dynamically if social media UI structures evolve.
 */
data class AppDetectionRule(
    val packageName: String,
    val appDisplayName: String,
    val contentType: String,
    val shortFormViewIdMarkers: List<String>,
    val shortFormTextMarkers: List<String>,
    val commentOrOverlayExclusionMarkers: List<String>,
    val nonShortFormScreenExclusionMarkers: List<String>,
    val minScrollDeltaY: Int = 120
)

/**
 * Result of evaluating an accessibility signal through the multi-stage detection engine.
 */
data class DetectionEvaluationResult(
    val shouldIncrementCount: Boolean,
    val isTargetApp: Boolean,
    val isShortFormContext: Boolean,
    val isCommentOrOverlayOpen: Boolean,
    val confidence: DetectionConfidence,
    val deduplicationState: ContentDeduplicationState,
    val contentSignature: String,
    val contentType: String,
    val appDisplayName: String,
    val diagnosticReason: String
)

/**
 * Multi-stage short-form content detection & deduplication engine (Requirement C).
 *
 * Stages:
 * 1. Application identification & user selection check
 * 2. Comment / Drawer / Non-short-form screen exclusion
 * 3. Multi-signal short-form context verification
 * 4. Content signature extraction (stripping volatile counters/timestamps)
 * 5. State-machine deduplication (cooldown + minimum view time + LRU seen-signature ring buffer)
 * 6. Confidence classification
 */
@Singleton
class ShortContentDetectionEngine @Inject constructor() {

    private val appRules: MutableMap<String, AppDetectionRule> = mutableMapOf()

    // Session & deduplication state
    private var activePackage: String? = null
    private var currentDedupState: ContentDeduplicationState = ContentDeduplicationState.NO_CONTENT
    private var activeContentSignature: String = ""
    private var candidateSignature: String = ""
    private var lastCountedTimestampMs: Long = 0L
    private var lastScrollEventTimestampMs: Long = 0L
    private var lastPagerIndex: Int = -1

    // Ring buffer of already counted content signatures in the current app session
    // Prevents re-counting if the user scrolls slightly up/down or revisits the previous video
    private val countedSignaturesInSession = LinkedHashSet<String>()
    private val maxSessionSignatureHistory = 40

    init {
        registerDefaultRules()
    }

    fun registerDefaultRules() {
        val tiktokRule = AppDetectionRule(
            packageName = Constants.PKG_TIKTOK,
            appDisplayName = "TikTok",
            contentType = Constants.TYPE_TIKTOK,
            shortFormViewIdMarkers = listOf(
                "viewpager", "vertical_view_pager", "feed_view_pager",
                "video_player", "player_view", "digg_Check", "comment_container",
                "share_container", "avatar", "title", "music_title"
            ),
            shortFormTextMarkers = listOf(
                "For You", "Untuk Anda", "Following", "Mengikuti", "Original Sound", "Suara Asli"
            ),
            commentOrOverlayExclusionMarkers = listOf(
                "comment_list", "comment_input", "add_comment", "tambahkan komentar",
                "comments_title", "komentar", "reply_to", "balas ke",
                "share_panel", "bagikan ke", "report_dialog"
            ),
            nonShortFormScreenExclusionMarkers = listOf(
                "inbox_fragment", "notification_list", "kotak masuk",
                "chat_message_list", "direct_message", "profile_tab_grid",
                "edit_profile", "settings_page", "pengaturan dan privasi",
                "search_result_list", "discover_grid"
            )
        )
        appRules[Constants.PKG_TIKTOK] = tiktokRule
        appRules[Constants.PKG_TIKTOK_ALT] = tiktokRule.copy(packageName = Constants.PKG_TIKTOK_ALT)
        appRules[Constants.PKG_TIKTOK_LITE] = tiktokRule.copy(
            packageName = Constants.PKG_TIKTOK_LITE,
            appDisplayName = "TikTok Lite"
        )

        val instagramRule = AppDetectionRule(
            packageName = Constants.PKG_INSTAGRAM,
            appDisplayName = "Instagram Reels",
            contentType = Constants.TYPE_REEL,
            shortFormViewIdMarkers = listOf(
                "clips_viewer_view_pager", "clips_video_container", "reel_viewer",
                "clips_item_overlay", "clips_author_info", "clips_audio_attribution"
            ),
            shortFormTextMarkers = listOf(
                "Reels", "Audio asli", "Original audio"
            ),
            commentOrOverlayExclusionMarkers = listOf(
                "layout_comment_thread", "comment_composer_edit_text", "row_comment_textview",
                "tambahkan komentar", "add a comment", "direct_share_sheet"
            ),
            nonShortFormScreenExclusionMarkers = listOf(
                "feed_timeline", "row_feed_photo", "direct_thread_Capabilities",
                "direct_inbox", "profile_header", "explore_grid", "story_viewer_tray"
            )
        )
        appRules[Constants.PKG_INSTAGRAM] = instagramRule
        appRules[Constants.PKG_INSTAGRAM_LITE] = instagramRule.copy(
            packageName = Constants.PKG_INSTAGRAM_LITE,
            appDisplayName = "Instagram Lite"
        )

        val youtubeRule = AppDetectionRule(
            packageName = Constants.PKG_YOUTUBE,
            appDisplayName = "YouTube Shorts",
            contentType = Constants.TYPE_SHORT,
            shortFormViewIdMarkers = listOf(
                "reel_recycler", "shorts_player", "reel_player_page_container",
                "reel_watch_fragment", "reel_multi_format_link", "reel_rhs_buttons"
            ),
            shortFormTextMarkers = listOf(
                "Shorts", "Remix", "Langganan", "Subscribe"
            ),
            commentOrOverlayExclusionMarkers = listOf(
                "engagement_panel", "comment_section", "comments_entry_point_header",
                "add_comment_box", "tambahkan komentar", "live_chat"
            ),
            nonShortFormScreenExclusionMarkers = listOf(
                "watch_while_layout_longform", "browse_feed_recycler",
                "subscriptions_feed", "library_tab", "search_results_list"
            )
        )
        appRules[Constants.PKG_YOUTUBE] = youtubeRule

        val facebookRule = AppDetectionRule(
            packageName = Constants.PKG_FACEBOOK,
            appDisplayName = "Facebook Reels",
            contentType = Constants.TYPE_REEL,
            shortFormViewIdMarkers = listOf(
                "fb_shorts_viewer", "reels_viewer", "short_form_video_container",
                "fb_shorts_pager", "reels_player_overlay"
            ),
            shortFormTextMarkers = listOf(
                "Reels", "Audio Asli", "Original Audio"
            ),
            commentOrOverlayExclusionMarkers = listOf(
                "ufis_comment_list", "comment_composer", "tulis komentar", "write a comment"
            ),
            nonShortFormScreenExclusionMarkers = listOf(
                "news_feed_recycler", "marketplace_feed", "notifications_list", "messenger_thread"
            )
        )
        appRules[Constants.PKG_FACEBOOK] = facebookRule
        appRules[Constants.PKG_FACEBOOK_LITE] = facebookRule.copy(
            packageName = Constants.PKG_FACEBOOK_LITE,
            appDisplayName = "Facebook Lite"
        )

        val snapchatRule = AppDetectionRule(
            packageName = Constants.PKG_SNAPCHAT,
            appDisplayName = "Snapchat Spotlight",
            contentType = Constants.TYPE_SPOTLIGHT,
            shortFormViewIdMarkers = listOf(
                "spotlight_player", "spotlight_feed", "spotlight_view_pager",
                "spotlight_action_bar"
            ),
            shortFormTextMarkers = listOf(
                "Spotlight"
            ),
            commentOrOverlayExclusionMarkers = listOf(
                "spotlight_comments_tray", "comment_input_field", "send_to_list"
            ),
            nonShortFormScreenExclusionMarkers = listOf(
                "camera_page", "chat_feed_list", "snap_map_container", "memories_grid"
            )
        )
        appRules[Constants.PKG_SNAPCHAT] = snapchatRule
    }

    fun updateRule(rule: AppDetectionRule) {
        appRules[rule.packageName] = rule
    }

    fun getRuleForPackage(packageName: String): AppDetectionRule? = appRules[packageName]

    fun resetSession() {
        activePackage = null
        currentDedupState = ContentDeduplicationState.SESSION_ENDED
        activeContentSignature = ""
        candidateSignature = ""
        lastCountedTimestampMs = 0L
        lastScrollEventTimestampMs = 0L
        lastPagerIndex = -1
        countedSignaturesInSession.clear()
    }

    fun onServiceInterrupted() {
        currentDedupState = ContentDeduplicationState.SERVICE_INTERRUPTED
    }

    /**
     * Evaluates an incoming accessibility signal and determines whether a short-form content
     * transition occurred with high confidence.
     */
    fun evaluateSignal(
        signal: AccessibilitySignalInput,
        trackingEnabled: Boolean,
        enabledPackages: Set<String> = appRules.keys
    ): DetectionEvaluationResult {
        if (!trackingEnabled) {
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = appRules.containsKey(signal.packageName),
                isShortFormContext = false,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.TRACKING_INACTIVE,
                deduplicationState = ContentDeduplicationState.NO_CONTENT,
                contentSignature = "",
                contentType = Constants.TYPE_UNKNOWN,
                appDisplayName = "",
                diagnosticReason = "Tracking sedang dijeda oleh pengguna"
            )
        }

        val rule = appRules[signal.packageName]
        val isEnabledTarget = rule != null && (enabledPackages.isEmpty() || enabledPackages.contains(signal.packageName))

        if (!isEnabledTarget || rule == null) {
            if (activePackage != null && activePackage != signal.packageName) {
                activePackage = null
                currentDedupState = ContentDeduplicationState.APP_SWITCHED
                activeContentSignature = ""
                lastPagerIndex = -1
                countedSignaturesInSession.clear()
            }
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = false,
                isShortFormContext = false,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.UNSUPPORTED_APP,
                deduplicationState = ContentDeduplicationState.APP_SWITCHED,
                contentSignature = "",
                contentType = Constants.TYPE_UNKNOWN,
                appDisplayName = "",
                diagnosticReason = "Aplikasi bukan target pemantauan (${signal.packageName})"
            )
        }

        // Detect app switch into a target app
        if (activePackage != signal.packageName) {
            activePackage = signal.packageName
            currentDedupState = ContentDeduplicationState.APP_SWITCHED
            activeContentSignature = ""
            candidateSignature = ""
            lastPagerIndex = -1
            countedSignaturesInSession.clear()
        }

        val combinedIds = signal.visibleViewIds.joinToString(" ").lowercase()
        val combinedTexts = signal.visibleTexts.joinToString(" ").lowercase()
        val combinedDescs = signal.visibleContentDescriptions.joinToString(" ").lowercase()
        val allUiCorpus = "$combinedIds $combinedTexts $combinedDescs"

        // Stage 2: Check if comment sheet, share sheet, or non-short-form screen is open
        val isCommentOrOverlayOpen = rule.commentOrOverlayExclusionMarkers.any { marker ->
            allUiCorpus.contains(marker.lowercase())
        }
        if (isCommentOrOverlayOpen) {
            currentDedupState = ContentDeduplicationState.UI_OVERLAY_OR_COMMENT_OPEN
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = true, // Still inside short-form player, but comment sheet is open
                isCommentOrOverlayOpen = true,
                confidence = DetectionConfidence.INSUFFICIENT_EVIDENCE,
                deduplicationState = currentDedupState,
                contentSignature = activeContentSignature,
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Panel komentar atau menu sedang terbuka — scroll diabaikan"
            )
        }

        val isNonShortFormScreen = rule.nonShortFormScreenExclusionMarkers.any { marker ->
            allUiCorpus.contains(marker.lowercase())
        }
        if (isNonShortFormScreen) {
            currentDedupState = ContentDeduplicationState.NO_CONTENT
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = false,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.INSUFFICIENT_EVIDENCE,
                deduplicationState = currentDedupState,
                contentSignature = "",
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Layar saat ini bukan feed video pendek (mis. Inbox/Profil/Beranda)"
            )
        }

        // Stage 3: Multi-signal Short-Form Context Verification
        val matchedViewId = rule.shortFormViewIdMarkers.any { marker ->
            combinedIds.contains(marker.lowercase())
        }
        val matchedTextMarker = rule.shortFormTextMarkers.any { marker ->
            combinedTexts.contains(marker.lowercase()) || combinedDescs.contains(marker.lowercase())
        }
        val isVerticalPagerClass = signal.hasVerticalPagerNode ||
                signal.className.contains("ViewPager", ignoreCase = true) ||
                signal.className.contains("RecyclerView", ignoreCase = true)

        // Require at least 2 signals or explicit short-form container ID
        val signalScore = (if (matchedViewId) 2 else 0) +
                (if (matchedTextMarker) 1 else 0) +
                (if (isVerticalPagerClass) 1 else 0)

        val isShortFormContext = signalScore >= 2
        if (!isShortFormContext) {
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = false,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.INSUFFICIENT_EVIDENCE,
                deduplicationState = ContentDeduplicationState.NO_CONTENT,
                contentSignature = "",
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Konteks konten pendek belum terverifikasi (skor sinyal: $signalScore)"
            )
        }

        // Stage 4: Extract normalized content signature (stripping volatile numbers/counters)
        val extractedSignature = buildNormalizedSignature(
            packageName = signal.packageName,
            texts = signal.visibleTexts,
            descriptions = signal.visibleContentDescriptions,
            toIndex = signal.toIndex
        )

        // If this is only a window state / content change without a scroll transition,
        // establish baseline active content without counting a scroll transition
        val isScrollEvent = signal.eventType == 4096 // AccessibilityEvent.TYPE_VIEW_SCROLLED
        if (!isScrollEvent) {
            if (activeContentSignature.isEmpty() && extractedSignature.isNotEmpty()) {
                activeContentSignature = extractedSignature
                countedSignaturesInSession.add(extractedSignature)
                currentDedupState = ContentDeduplicationState.ACTIVE_CONTENT_IDENTIFIED
            }
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = true,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.PROBABLE_TRANSITION,
                deduplicationState = ContentDeduplicationState.ACTIVE_CONTENT_IDENTIFIED,
                contentSignature = activeContentSignature,
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Konteks video pendek aktif terdeteksi (menunggu transisi scroll)"
            )
        }

        // Stage 5: Verify physical scroll transition metrics
        // Reject horizontal swipes (e.g., switching tabs or swiping carousel photos)
        if (abs(signal.scrollDeltaX) > abs(signal.scrollDeltaY) && abs(signal.scrollDeltaX) > 80) {
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = true,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.INSUFFICIENT_EVIDENCE,
                deduplicationState = currentDedupState,
                contentSignature = activeContentSignature,
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Swipe horizontal diabaikan"
            )
        }

        val hasPageIndexAdvance = signal.toIndex >= 0 && signal.toIndex != lastPagerIndex
        val hasSufficientVerticalScroll = abs(signal.scrollDeltaY) >= rule.minScrollDeltaY ||
                (signal.scrollDeltaY == 0 && signal.toIndex >= 0)

        if (!hasPageIndexAdvance && !hasSufficientVerticalScroll) {
            currentDedupState = ContentDeduplicationState.CANDIDATE_TRANSITION_PENDING
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = true,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.PROBABLE_TRANSITION,
                deduplicationState = currentDedupState,
                contentSignature = extractedSignature,
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Scroll terlalu kecil / belum berpindah halaman"
            )
        }

        // Stage 6: Cooldown & Content Identity Deduplication
        val elapsedSinceLastCount = signal.timestampMs - lastCountedTimestampMs
        if (lastCountedTimestampMs > 0L && elapsedSinceLastCount in 0 until Constants.DEDUP_COOLDOWN_MS) {
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = true,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.PROBABLE_TRANSITION,
                deduplicationState = ContentDeduplicationState.CONTENT_COUNTED,
                contentSignature = activeContentSignature,
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Dalam jeda deduplikasi (${elapsedSinceLastCount}ms < ${Constants.DEDUP_COOLDOWN_MS}ms)"
            )
        }

        if (extractedSignature.isBlank()) {
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = true,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.INSUFFICIENT_EVIDENCE,
                deduplicationState = ContentDeduplicationState.CANDIDATE_TRANSITION_PENDING,
                contentSignature = "",
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Identitas konten kosong — menunggu render elemen UI"
            )
        }

        // Check if this exact content signature was already counted in the current session
        if (extractedSignature == activeContentSignature || countedSignaturesInSession.contains(extractedSignature)) {
            currentDedupState = ContentDeduplicationState.CONTENT_COUNTED
            return DetectionEvaluationResult(
                shouldIncrementCount = false,
                isTargetApp = true,
                isShortFormContext = true,
                isCommentOrOverlayOpen = false,
                confidence = DetectionConfidence.PROBABLE_TRANSITION,
                deduplicationState = currentDedupState,
                contentSignature = extractedSignature,
                contentType = rule.contentType,
                appDisplayName = rule.appDisplayName,
                diagnosticReason = "Konten yang sama sudah dihitung pada sesi ini"
            )
        }

        // Verified new short-form content transition!
        activeContentSignature = extractedSignature
        lastCountedTimestampMs = signal.timestampMs
        lastScrollEventTimestampMs = signal.timestampMs
        if (signal.toIndex >= 0) {
            lastPagerIndex = signal.toIndex
        }
        currentDedupState = ContentDeduplicationState.CONTENT_COUNTED

        countedSignaturesInSession.add(extractedSignature)
        if (countedSignaturesInSession.size > maxSessionSignatureHistory) {
            val firstKey = countedSignaturesInSession.first()
            countedSignaturesInSession.remove(firstKey)
        }

        return DetectionEvaluationResult(
            shouldIncrementCount = true,
            isTargetApp = true,
            isShortFormContext = true,
            isCommentOrOverlayOpen = false,
            confidence = DetectionConfidence.HIGH_CONFIDENCE,
            deduplicationState = ContentDeduplicationState.CONTENT_COUNTED,
            contentSignature = extractedSignature,
            contentType = rule.contentType,
            appDisplayName = rule.appDisplayName,
            diagnosticReason = "Transisi konten pendek baru terverifikasi (HIGH_CONFIDENCE)"
        )
    }

    /**
     * Builds a stable signature for the currently visible video/reel while stripping out
     * volatile metrics (like/comment/share counters, timers, percentages) so animations
     * or liking a video never trigger a false content change.
     */
    fun buildNormalizedSignature(
        packageName: String,
        texts: List<String>,
        descriptions: List<String>,
        toIndex: Int = -1
    ): String {
        val volatileMetricRegex = Regex(
            pattern = """^\d+([.,]\d+)?\s*[kKmMbBrbjt]*$|^(\d{1,2}:\d{2})$|^(like|suka|share|bagikan|comment|komentar|ikuti|follow|subscribe|langganan|remix)$""",
            option = RegexOption.IGNORE_CASE
        )

        val meaningfulParts = (texts + descriptions)
            .map { it.trim() }
            .filter { it.length >= 3 }
            .filterNot { volatileMetricRegex.matches(it) }
            .map { raw ->
                // Strip trailing dynamic numbers while keeping @handles and caption words
                raw.replace(Regex("""\b\d+([.,]\d+)?\s*(likes|suka|views|tayangan|comments|komentar)\b""", RegexOption.IGNORE_CASE), "")
                    .trim()
                    .lowercase()
            }
            .filter { it.length >= 3 }
            .distinct()
            .take(5)

        if (meaningfulParts.isEmpty()) {
            return if (toIndex >= 0) "$packageName#idx:$toIndex" else ""
        }

        val joined = meaningfulParts.joinToString("|")
        return "$packageName#$joined"
    }
}
