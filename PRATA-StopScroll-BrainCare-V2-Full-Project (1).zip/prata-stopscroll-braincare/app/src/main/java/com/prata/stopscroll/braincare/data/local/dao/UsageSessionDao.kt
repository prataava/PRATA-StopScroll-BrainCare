package com.prata.stopscroll.braincare.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.prata.stopscroll.braincare.data.local.entity.AppUsageSession
import kotlinx.coroutines.flow.Flow

@Dao
interface UsageSessionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: AppUsageSession): Long

    @Update
    suspend fun update(session: AppUsageSession)

    @Delete
    suspend fun delete(session: AppUsageSession)

    @Query("SELECT * FROM app_usage_sessions WHERE id = :id")
    suspend fun getById(id: Long): AppUsageSession?

    @Query("SELECT * FROM app_usage_sessions WHERE date = :date ORDER BY startTime DESC")
    fun getByDate(date: String): Flow<List<AppUsageSession>>

    @Query("SELECT * FROM app_usage_sessions WHERE packageName = :packageName AND date = :date ORDER BY startTime DESC")
    fun getByPackageAndDate(packageName: String, date: String): Flow<List<AppUsageSession>>

    @Query("SELECT * FROM app_usage_sessions WHERE startTime BETWEEN :startTime AND :endTime ORDER BY startTime DESC")
    fun getByTimeRange(startTime: Long, endTime: Long): Flow<List<AppUsageSession>>

    @Query("SELECT * FROM app_usage_sessions WHERE endTime IS NULL ORDER BY startTime DESC LIMIT 1")
    suspend fun getActiveSession(): AppUsageSession?

    @Query("SELECT * FROM app_usage_sessions WHERE packageName = :packageName AND endTime IS NULL ORDER BY startTime DESC LIMIT 1")
    suspend fun getActiveSessionForPackage(packageName: String): AppUsageSession?

    @Query("SELECT SUM(durationMs) FROM app_usage_sessions WHERE date = :date")
    fun getTotalDurationByDate(date: String): Flow<Long?>

    @Query("SELECT SUM(durationMs) FROM app_usage_sessions WHERE packageName = :packageName AND date = :date")
    fun getTotalDurationByPackageAndDate(packageName: String, date: String): Flow<Long?>

    @Query("SELECT COUNT(*) FROM app_usage_sessions WHERE date = :date")
    fun getSessionCountByDate(date: String): Flow<Int>

    @Query("SELECT DISTINCT packageName FROM app_usage_sessions WHERE date = :date")
    fun getActivePackagesByDate(date: String): Flow<List<String>>

    @Query("DELETE FROM app_usage_sessions WHERE date < :beforeDate")
    suspend fun deleteOlderThan(beforeDate: String)
}
