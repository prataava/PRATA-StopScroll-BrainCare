package com.prata.stopscroll.braincare.domain.state

import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Unified, deterministic system state machine for PRATA StopScroll BrainCare (Requirement F).
 * Replaces scattered booleans with a single authoritative state model.
 */
enum class SystemTrackingState {
    IDLE,
    TARGET_APP_ACTIVE,
    SHORT_CONTENT_DETECTED,
    TRACKING_ACTIVE,
    TRACKING_PAUSED,
    LIMIT_WARNING,
    LIMIT_REACHED,
    BLOCKING_ACTIVE,
    TARGET_APP_INACTIVE,
    PERMISSION_MISSING,
    SERVICE_UNAVAILABLE
}

/**
 * Internal confidence levels for short-form content detection (Requirement C.4).
 */
enum class DetectionConfidence {
    HIGH_CONFIDENCE,       // Terdeteksi dengan keyakinan tinggi -> masuk hitungan utama
    PROBABLE_TRANSITION,   // Kemungkinan pergantian konten -> menunggu konfirmasi sinyal
    INSUFFICIENT_EVIDENCE, // Belum cukup bukti -> diabaikan
    UNSUPPORTED_APP,       // Aplikasi tidak didukung / tidak dipilih / dikecualikan
    TRACKING_INACTIVE      // Tracking sedang dijeda / nonaktif
}

/**
 * Deduplication state machine states (Requirement C.3).
 */
enum class ContentDeduplicationState {
    NO_CONTENT,
    ACTIVE_CONTENT_IDENTIFIED,
    CANDIDATE_TRANSITION_PENDING,
    CONTENT_COUNTED,
    UI_OVERLAY_OR_COMMENT_OPEN,
    APP_SWITCHED,
    SESSION_ENDED,
    SERVICE_INTERRUPTED
}

/**
 * User-selectable enforcement policy when daily or per-app limit is reached (Section 3.D).
 *
 * 1. REMINDER (Mode Pengingat): Menampilkan peringatan ketika limit tercapai.
 * 2. FOCUS (Mode Blokir): Menampilkan layar pembatas pada aplikasi target dan mengarahkan pengguna
 *    keluar (GLOBAL_ACTION_HOME) jika mekanisme mendukungnya; dapat ditunda dengan konfirmasi sadar.
 * 3. STRICT (Mode Ketat): Mengarahkan pengguna keluar dari aplikasi target saat limit tercapai, lalu
 *    mempertahankan pembatas dan pengalihan keluar ketika pengguna mencoba membuka kembali aplikasi
 *    target selama limit masih aktif.
 */
enum class LimitEnforcementPolicy(
    val key: String,
    val title: String,
    val description: String
) {
    REMINDER(
        key = "reminder",
        title = "Mode Pengingat",
        description = "Menampilkan peringatan visual pada floating counter dan notifikasi ketika batas tercapai tanpa menutup aplikasi."
    ),
    FOCUS(
        key = "focus",
        title = "Mode Blokir",
        description = "Menampilkan layar pembatas pada aplikasi target dan mengarahkan keluar ke Home screen saat batas tercapai. Dapat ditunda setelah konfirmasi sadar."
    ),
    STRICT(
        key = "strict",
        title = "Mode Ketat",
        description = "Mengarahkan keluar dari aplikasi target saat batas tercapai, lalu mempertahankan pembatas setiap kali aplikasi target dibuka kembali selama batas masih aktif."
    );

    companion object {
        fun fromKey(key: String?): LimitEnforcementPolicy {
            return when (key?.lowercase()) {
                "reminder" -> REMINDER
                "strict" -> STRICT
                "focus", "block", "blokir" -> FOCUS
                else -> FOCUS
            }
        }
    }
}

/**
 * Floating counter size presets (Requirement D & I).
 */
enum class FloatingCounterSize(val key: String, val label: String, val scaleFactor: Float) {
    SMALL("small", "Kecil (Mini)", 0.85f),
    MEDIUM("medium", "Normal", 1.0f),
    LARGE("large", "Besar", 1.18f);

    companion object {
        fun fromKey(key: String?): FloatingCounterSize {
            return entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: MEDIUM
        }
    }
}

/**
 * Mascot mood state driven by real-time scroll usage ratio and system state (Requirement J & K).
 */
enum class MascotMoodState(val label: String) {
    FRESH("Otak Segar & Sehat"),
    FOCUSED("Fokus Terjaga"),
    TIRED("Mulai Lelah • Kurangi Scroll"),
    OVERLOADED("Overload • Batas Tercapai!"),
    RESTING("Mode Istirahat / Dijeda")
}

/**
 * Immutable snapshot of the complete tracking, detection, overlay, and limit state.
 * Shared across AccessibilityService, FloatingOverlayManager, MonitoringService, and UI ViewModels.
 */
data class LiveTrackingSnapshot(
    val systemState: SystemTrackingState = SystemTrackingState.IDLE,
    val dedupState: ContentDeduplicationState = ContentDeduplicationState.NO_CONTENT,
    val lastConfidence: DetectionConfidence = DetectionConfidence.INSUFFICIENT_EVIDENCE,
    val activePackage: String? = null,
    val activeAppName: String? = null,
    val todayShortCount: Int = 0,
    val dailyLimit: Int = 100,
    val activeAppTodayCount: Int = 0,
    val activeAppDailyLimit: Int? = null,
    val todayUsageMs: Long = 0L,
    val dailyDurationLimitMinutes: Int = 0,
    val warningThresholdPercent: Float = 0.8f,
    val enforcementPolicy: LimitEnforcementPolicy = LimitEnforcementPolicy.FOCUS,
    val isShortFormContext: Boolean = false,
    val isCommentOrMenuOpen: Boolean = false,
    val isFloatingOverlayVisible: Boolean = false,
    val isFloatingExpanded: Boolean = false,
    val isFloatingTemporarilyHidden: Boolean = false,
    val isBlockingOverlayVisible: Boolean = false,
    val blockingReason: String? = null,
    val lastAutoExitSucceeded: Boolean = true,
    val isTrackingEnabled: Boolean = true,
    val isFocusScheduleActive: Boolean = false,
    val isAccessibilityGranted: Boolean = false,
    val isOverlayGranted: Boolean = false,
    val isServiceRunning: Boolean = false,
    val lastVerifiedSignature: String = "",
    val lastTransitionTimestampMs: Long = 0L,
    val lastHeartbeatElapsedMs: Long = 0L
) {
    val progressRatio: Float
        get() = if (dailyLimit > 0) (todayShortCount.toFloat() / dailyLimit).coerceIn(0f, 1f) else 0f

    val isWarningReached: Boolean
        get() = dailyLimit > 0 && todayShortCount >= (dailyLimit * warningThresholdPercent).toInt()

    val isLimitReached: Boolean
        get() = (dailyLimit > 0 && todayShortCount >= dailyLimit) ||
                (activeAppDailyLimit != null && activeAppDailyLimit > 0 && activeAppTodayCount >= activeAppDailyLimit) ||
                isFocusScheduleActive

    val mascotMood: MascotMoodState
        get() = when {
            !isTrackingEnabled || systemState == SystemTrackingState.TRACKING_PAUSED -> MascotMoodState.RESTING
            systemState == SystemTrackingState.LIMIT_REACHED || systemState == SystemTrackingState.BLOCKING_ACTIVE || progressRatio >= 1.0f -> MascotMoodState.OVERLOADED
            systemState == SystemTrackingState.LIMIT_WARNING || progressRatio >= warningThresholdPercent -> MascotMoodState.TIRED
            progressRatio >= 0.45f || systemState == SystemTrackingState.TRACKING_ACTIVE -> MascotMoodState.FOCUSED
            else -> MascotMoodState.FRESH
        }
}

/**
 * Thread-safe singleton state machine coordinating all state transitions.
 */
@Singleton
class TrackingStateMachine @Inject constructor() {

    private val _snapshot = MutableStateFlow(LiveTrackingSnapshot())
    val snapshot: StateFlow<LiveTrackingSnapshot> = _snapshot.asStateFlow()

    private fun monotonicNow(): Long = try {
        SystemClock.elapsedRealtime()
    } catch (_: Throwable) {
        System.currentTimeMillis()
    }

    fun onServiceOrPermissionStateChanged(
        isAccessibilityGranted: Boolean,
        isOverlayGranted: Boolean,
        isServiceRunning: Boolean,
        isTrackingEnabled: Boolean
    ) {
        _snapshot.update { current ->
            val nextSystemState = when {
                !isAccessibilityGranted -> SystemTrackingState.PERMISSION_MISSING
                !isServiceRunning -> SystemTrackingState.SERVICE_UNAVAILABLE
                !isTrackingEnabled -> SystemTrackingState.TRACKING_PAUSED
                current.systemState == SystemTrackingState.PERMISSION_MISSING ||
                current.systemState == SystemTrackingState.SERVICE_UNAVAILABLE ||
                current.systemState == SystemTrackingState.TRACKING_PAUSED -> SystemTrackingState.IDLE
                else -> current.systemState
            }

            val hideOverlays = nextSystemState == SystemTrackingState.PERMISSION_MISSING ||
                    nextSystemState == SystemTrackingState.SERVICE_UNAVAILABLE ||
                    nextSystemState == SystemTrackingState.TRACKING_PAUSED

            current.copy(
                systemState = nextSystemState,
                dedupState = if (hideOverlays) ContentDeduplicationState.SERVICE_INTERRUPTED else current.dedupState,
                lastConfidence = if (!isTrackingEnabled) DetectionConfidence.TRACKING_INACTIVE else current.lastConfidence,
                isAccessibilityGranted = isAccessibilityGranted,
                isOverlayGranted = isOverlayGranted,
                isServiceRunning = isServiceRunning,
                isTrackingEnabled = isTrackingEnabled,
                isFloatingOverlayVisible = if (hideOverlays) false else current.isFloatingOverlayVisible,
                isBlockingOverlayVisible = if (hideOverlays) false else current.isBlockingOverlayVisible,
                lastHeartbeatElapsedMs = monotonicNow()
            )
        }
    }

    fun syncLimitsAndCounts(
        todayShortCount: Int,
        dailyLimit: Int,
        activeAppTodayCount: Int = _snapshot.value.activeAppTodayCount,
        activeAppDailyLimit: Int? = _snapshot.value.activeAppDailyLimit,
        warningThresholdPercent: Float = _snapshot.value.warningThresholdPercent,
        enforcementPolicy: LimitEnforcementPolicy = _snapshot.value.enforcementPolicy,
        isFocusScheduleActive: Boolean = _snapshot.value.isFocusScheduleActive,
        userOverrodeToday: Boolean = false
    ) {
        _snapshot.update { current ->
            val updated = current.copy(
                todayShortCount = todayShortCount,
                dailyLimit = dailyLimit,
                activeAppTodayCount = activeAppTodayCount,
                activeAppDailyLimit = activeAppDailyLimit,
                warningThresholdPercent = warningThresholdPercent,
                enforcementPolicy = enforcementPolicy,
                isFocusScheduleActive = isFocusScheduleActive,
                lastHeartbeatElapsedMs = monotonicNow()
            )
            recalculateLimitAndOverlayState(updated, userOverrodeToday)
        }
    }

    fun onForegroundAppChanged(
        packageName: String,
        isTargetApp: Boolean,
        appName: String?,
        activeAppCount: Int = 0,
        activeAppLimit: Int? = null,
        userOverrodeToday: Boolean = false
    ) {
        _snapshot.update { current ->
            if (!current.isAccessibilityGranted) {
                return@update current.copy(
                    systemState = SystemTrackingState.PERMISSION_MISSING,
                    isFloatingOverlayVisible = false,
                    isBlockingOverlayVisible = false
                )
            }
            if (!current.isTrackingEnabled) {
                return@update current.copy(
                    systemState = SystemTrackingState.TRACKING_PAUSED,
                    activePackage = packageName,
                    activeAppName = appName,
                    lastConfidence = DetectionConfidence.TRACKING_INACTIVE,
                    isFloatingOverlayVisible = false,
                    isBlockingOverlayVisible = false
                )
            }

            if (!isTargetApp) {
                current.copy(
                    systemState = SystemTrackingState.TARGET_APP_INACTIVE,
                    dedupState = ContentDeduplicationState.APP_SWITCHED,
                    lastConfidence = DetectionConfidence.UNSUPPORTED_APP,
                    activePackage = packageName,
                    activeAppName = null,
                    isShortFormContext = false,
                    isCommentOrMenuOpen = false,
                    isFloatingOverlayVisible = false,
                    isFloatingTemporarilyHidden = false,
                    isBlockingOverlayVisible = false,
                    blockingReason = null,
                    lastHeartbeatElapsedMs = monotonicNow()
                )
            } else {
                val entered = current.copy(
                    systemState = SystemTrackingState.TARGET_APP_ACTIVE,
                    dedupState = ContentDeduplicationState.APP_SWITCHED,
                    activePackage = packageName,
                    activeAppName = appName,
                    activeAppTodayCount = activeAppCount,
                    activeAppDailyLimit = activeAppLimit,
                    isShortFormContext = false,
                    isCommentOrMenuOpen = false,
                    isFloatingTemporarilyHidden = false,
                    lastHeartbeatElapsedMs = monotonicNow()
                )
                recalculateLimitAndOverlayState(entered, userOverrodeToday)
            }
        }
    }

    fun onShortContentContextEvaluated(
        isShortFormContext: Boolean,
        isCommentOrMenuOpen: Boolean,
        confidence: DetectionConfidence,
        dedupState: ContentDeduplicationState,
        userOverrodeToday: Boolean = false
    ) {
        _snapshot.update { current ->
            if (!current.isTrackingEnabled) {
                return@update current.copy(
                    systemState = SystemTrackingState.TRACKING_PAUSED,
                    lastConfidence = DetectionConfidence.TRACKING_INACTIVE,
                    isFloatingOverlayVisible = false,
                    isBlockingOverlayVisible = false
                )
            }

            val baseState = when {
                !isShortFormContext && !isCommentOrMenuOpen -> SystemTrackingState.TARGET_APP_ACTIVE
                current.systemState == SystemTrackingState.TARGET_APP_ACTIVE && isShortFormContext ->
                    SystemTrackingState.SHORT_CONTENT_DETECTED
                isShortFormContext -> SystemTrackingState.TRACKING_ACTIVE
                else -> current.systemState
            }

            val updated = current.copy(
                systemState = baseState,
                dedupState = dedupState,
                lastConfidence = confidence,
                isShortFormContext = isShortFormContext,
                isCommentOrMenuOpen = isCommentOrMenuOpen,
                lastHeartbeatElapsedMs = monotonicNow()
            )
            recalculateLimitAndOverlayState(updated, userOverrodeToday)
        }
    }

    fun onVerifiedContentCounted(
        newTodayCount: Int,
        newAppCount: Int,
        contentSignature: String,
        timestampMs: Long,
        userOverrodeToday: Boolean = false
    ) {
        _snapshot.update { current ->
            val updated = current.copy(
                systemState = SystemTrackingState.TRACKING_ACTIVE,
                dedupState = ContentDeduplicationState.CONTENT_COUNTED,
                lastConfidence = DetectionConfidence.HIGH_CONFIDENCE,
                todayShortCount = newTodayCount,
                activeAppTodayCount = newAppCount,
                isShortFormContext = true,
                lastVerifiedSignature = contentSignature,
                lastTransitionTimestampMs = timestampMs,
                lastHeartbeatElapsedMs = monotonicNow()
            )
            recalculateLimitAndOverlayState(updated, userOverrodeToday)
        }
    }

    fun recordAutoExitResult(succeeded: Boolean) {
        _snapshot.update { current ->
            current.copy(lastAutoExitSucceeded = succeeded)
        }
    }

    fun setFloatingTemporarilyHidden(hidden: Boolean) {
        _snapshot.update { current ->
            current.copy(
                isFloatingTemporarilyHidden = hidden,
                isFloatingOverlayVisible = if (hidden) false else (current.isShortFormContext && current.isTrackingEnabled)
            )
        }
    }

    fun toggleFloatingExpanded() {
        _snapshot.update { current ->
            current.copy(isFloatingExpanded = !current.isFloatingExpanded)
        }
    }

    private fun recalculateLimitAndOverlayState(
        state: LiveTrackingSnapshot,
        userOverrodeToday: Boolean
    ): LiveTrackingSnapshot {
        if (!state.isTrackingEnabled || state.systemState == SystemTrackingState.TARGET_APP_INACTIVE ||
            state.systemState == SystemTrackingState.PERMISSION_MISSING ||
            state.systemState == SystemTrackingState.SERVICE_UNAVAILABLE
        ) {
            return state.copy(
                isFloatingOverlayVisible = false,
                isBlockingOverlayVisible = false,
                blockingReason = null
            )
        }

        val totalLimitHit = state.dailyLimit > 0 && state.todayShortCount >= state.dailyLimit
        val appLimitHit = state.activeAppDailyLimit != null &&
                state.activeAppDailyLimit > 0 &&
                state.activeAppTodayCount >= state.activeAppDailyLimit
        val scheduleHit = state.isFocusScheduleActive

        val limitHit = totalLimitHit || appLimitHit || scheduleHit
        val warningHit = !limitHit && state.dailyLimit > 0 &&
                state.todayShortCount >= (state.dailyLimit * state.warningThresholdPercent).toInt()

        val reason = when {
            scheduleHit -> "Jadwal Bebas Scrolling sedang aktif"
            appLimitHit -> "Batas harian ${state.activeAppName ?: "aplikasi"} (${state.activeAppDailyLimit} konten) tercapai"
            totalLimitHit -> "Batas harian (${state.dailyLimit} konten) telah tercapai"
            else -> null
        }

        val isTargetForeground = state.activePackage != null && state.systemState != SystemTrackingState.IDLE
        val shouldEnforceBlock = limitHit && !userOverrodeToday &&
                (state.enforcementPolicy == LimitEnforcementPolicy.FOCUS ||
                 state.enforcementPolicy == LimitEnforcementPolicy.STRICT) &&
                (state.isShortFormContext || (state.enforcementPolicy == LimitEnforcementPolicy.STRICT && isTargetForeground))

        val effectiveSystemState = when {
            shouldEnforceBlock -> SystemTrackingState.BLOCKING_ACTIVE
            limitHit && (state.isShortFormContext || isTargetForeground) -> SystemTrackingState.LIMIT_REACHED
            warningHit && state.isShortFormContext -> SystemTrackingState.LIMIT_WARNING
            state.isShortFormContext -> SystemTrackingState.TRACKING_ACTIVE
            state.activePackage != null -> SystemTrackingState.TARGET_APP_ACTIVE
            else -> SystemTrackingState.IDLE
        }

        val shouldShowFloating = state.isShortFormContext && !state.isFloatingTemporarilyHidden

        return state.copy(
            systemState = effectiveSystemState,
            isFloatingOverlayVisible = shouldShowFloating,
            isBlockingOverlayVisible = shouldEnforceBlock,
            blockingReason = reason
        )
    }
}
