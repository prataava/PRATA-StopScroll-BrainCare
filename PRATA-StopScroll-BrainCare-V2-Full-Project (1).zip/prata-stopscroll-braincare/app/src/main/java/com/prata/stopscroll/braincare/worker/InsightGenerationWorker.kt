package com.prata.stopscroll.braincare.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.prata.stopscroll.braincare.di.ServiceEntryPoint
import dagger.hilt.android.EntryPointAccessors

class InsightGenerationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val entryPoint = EntryPointAccessors.fromApplication(
                applicationContext,
                ServiceEntryPoint::class.java
            )

            val behaviorAnalyzer = entryPoint.behaviorAnalyzer()
            val notificationHelper = entryPoint.notificationHelper()

            val generated = behaviorAnalyzer.analyzeAndGenerateInsights()
            if (generated.isNotEmpty()) {
                val latest = generated.first()
                if (latest.confidence == "HIGH") {
                    notificationHelper.showInsightNotification(latest.title, latest.description)
                }
            }

            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
