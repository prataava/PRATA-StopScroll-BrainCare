package com.prata.stopscroll.braincare.ui.onboarding

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.prata.stopscroll.braincare.R
import com.prata.stopscroll.braincare.ui.components.getSocialAppIconRes
import com.prata.stopscroll.braincare.ui.theme.WarmOrange
import com.prata.stopscroll.braincare.ui.theme.WarmPink
import com.prata.stopscroll.braincare.util.Constants
import com.prata.stopscroll.braincare.util.PermissionUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    viewModel: OnboardingViewModel,
    onFinished: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.checkPermissions()
    }

    LaunchedEffect(uiState.isCompleted) {
        if (uiState.isCompleted) {
            onFinished()
        }
    }

    Scaffold { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header & Progress Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (uiState.currentStep > 0) {
                    IconButton(onClick = { viewModel.prevStep() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                } else {
                    Spacer(modifier = Modifier.width(48.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (0..4).forEach { stepIndex ->
                        Box(
                            modifier = Modifier
                                .size(if (stepIndex == uiState.currentStep) 10.dp else 8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (stepIndex == uiState.currentStep) WarmOrange
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(48.dp))
            }

            // Step Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when (uiState.currentStep) {
                    0 -> StepWelcome()
                    1 -> StepGoals(
                        selectedGoals = uiState.selectedGoals,
                        onToggle = { viewModel.toggleGoal(it) }
                    )
                    2 -> StepApps(
                        selectedApps = uiState.selectedApps,
                        onToggle = { viewModel.toggleApp(it) }
                    )
                    3 -> StepLimit(
                        currentLimit = uiState.initialDailyLimit,
                        onLimitChanged = { viewModel.setDailyLimit(it) }
                    )
                    4 -> StepPermissions(
                        isAccessibilityGranted = uiState.isAccessibilityActive,
                        onOpenSettings = { PermissionUtils.openAccessibilitySettings(context) }
                    )
                }
            }

            // Bottom Action Button
            Button(
                onClick = {
                    if (uiState.currentStep < 4) {
                        viewModel.nextStep()
                    } else {
                        viewModel.completeOnboarding()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WarmOrange),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    text = if (uiState.currentStep == 4) "Mulai Gunakan PRATA" else "Lanjutkan",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
fun StepWelcome() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.il_onboarding_welcome),
            contentDescription = "PRATA StopScroll BrainCare",
            modifier = Modifier.size(136.dp)
        )

        Text(
            text = "PRATA StopScroll BrainCare",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Text(
            text = "“Kendalikan Scrolling. Kembalikan Fokusmu.”",
            style = MaterialTheme.typography.titleMedium,
            color = WarmPink,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )

        Text(
            text = "Penghitung konten pendek akurat dengan Floating Counter otomatis, pembatas tegas saat batas tercapai, dan AI Coach berbasis data lokal.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun StepGoals(
    selectedGoals: Set<String>,
    onToggle: (String) -> Unit
) {
    val goals = listOf(
        "Mengurangi waktu scrolling harian",
        "Lebih fokus belajar atau bekerja",
        "Memperbaiki rutinitas tidur tanpa layar",
        "Lebih sadar saat membuka media sosial",
        "Memahami pola kebiasaan digital saya"
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.il_onboarding_goals),
            contentDescription = "Tujuan",
            modifier = Modifier.size(84.dp)
        )
        Text(
            text = "Apa tujuan utamamu?",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Pilih target kebiasaan yang ingin kamu bangun bersama PRATA:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        goals.forEach { goal ->
            val isSelected = selectedGoals.contains(goal)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle(goal) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (isSelected) WarmOrange else Color.Gray
                    )
                    Text(
                        text = goal,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun StepApps(
    selectedApps: Set<String>,
    onToggle: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Aplikasi Target Pemantauan",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Floating counter dan deteksi otomatis akan aktif saat kamu menonton video pendek di aplikasi berikut:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(4.dp))

        Constants.PRIMARY_SELECTABLE_APPS.forEach { (pkg, name) ->
            val isSelected = selectedApps.contains(pkg)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle(pkg) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Image(
                            painter = painterResource(id = getSocialAppIconRes(pkg)),
                            contentDescription = name,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggle(pkg) }
                    )
                }
            }
        }
    }
}

@Composable
fun StepLimit(
    currentLimit: Int,
    onLimitChanged: (Int) -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.il_onboarding_limits),
            contentDescription = "Batas Harian",
            modifier = Modifier.size(96.dp)
        )
        Text(
            text = "Tentukan Batas Harian Awal",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Text(
            text = "PRATA akan memberi peringatan pada 80% batas dan mengaktifkan layar pembatas saat batas tercapai.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Text(
            text = "$currentLimit video pendek",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            ),
            color = WarmOrange
        )

        Slider(
            value = currentLimit.toFloat(),
            onValueChange = { onLimitChanged(it.toInt()) },
            valueRange = 30f..250f,
            steps = 21,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        Text(
            text = "Rekomendasi awal: 80–100 video/hari.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun StepPermissions(
    isAccessibilityGranted: Boolean,
    onOpenSettings: () -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.il_onboarding_permissions),
            contentDescription = "Izin Privasi",
            modifier = Modifier.size(88.dp)
        )
        Text(
            text = "Aktifkan Pelacakan & Floating Counter",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Text(
            text = "PRATA menggunakan AccessibilityService untuk mendeteksi transisi video pendek dan menampilkan Floating Counter otomatis di atas aplikasi target.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "🔒 Jaminan Privasi Lokal PRATA:",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text("• Tidak pernah merekam pesan pribadi atau password.")
                Text("• Floating counter otomatis bersembunyi saat membuka WhatsApp, kamera, atau aplikasi lain.")
                Text("• Seluruh data disimpan 100% di dalam perangkatmu.")
            }
        }

        OutlinedButton(
            onClick = onOpenSettings,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(
                imageVector = if (isAccessibilityGranted) Icons.Filled.CheckCircle else Icons.Filled.Settings,
                contentDescription = null,
                tint = if (isAccessibilityGranted) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isAccessibilityGranted) "Accessibility Sudah Aktif ✅" else "Buka Pengaturan Accessibility"
            )
        }
    }
}
