package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "short_content_detections",
    indices = [
        Index("packageName"),
        Index("detectedAt"),
        Index("date")
    ]
)
data class ShortContentDetection(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val detectedAt: Long, // epoch millis
    val contentType: String, // REEL, SHORT, SPOTLIGHT, TIKTOK
    val sessionId: Long? = null,
    val date: String, // yyyy-MM-dd
    val hour: Int // 0-23
)
