package com.prata.stopscroll.braincare.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_statistics",
    indices = [
        Index(value = ["date"], unique = true)
    ]
)
data class DailyStatistics(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String, // yyyy-MM-dd
    val totalShortContent: Int = 0,
    val totalUsageMs: Long = 0,
    val totalSessions: Int = 0,
    val limitReached: Boolean = false,
    val limitValue: Int? = null,
    val focusMinutes: Int = 0,
    val streakDay: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
