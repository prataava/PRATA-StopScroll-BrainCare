package com.prata.stopscroll.braincare.ui.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.prata.stopscroll.braincare.data.local.PrataDatabase
import com.prata.stopscroll.braincare.data.repository.PreferencesRepositoryImpl
import com.prata.stopscroll.braincare.data.repository.StatsRepositoryImpl
import com.prata.stopscroll.braincare.domain.limit.HardLimitManager
import com.prata.stopscroll.braincare.domain.state.FloatingCounterSize
import com.prata.stopscroll.braincare.domain.state.LimitEnforcementPolicy
import com.prata.stopscroll.braincare.domain.state.TrackingStateMachine
import com.prata.stopscroll.braincare.service.MonitoringService
import com.prata.stopscroll.braincare.service.ScrollAccessibilityService
import com.prata.stopscroll.braincare.util.Constants
import com.prata.stopscroll.braincare.util.DateUtils
import com.prata.stopscroll.braincare.util.PermissionUtils
import com.prata.stopscroll.braincare.worker.DataExportWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import javax.inject.Inject

data class SettingsUiState(
    val dailyLimit: Int = 100,
    val perAppLimits: Map<String, Int> = emptyMap(),
    val dailyDurationLimitMinutes: Int = 0,
    val warningThresholdPercent: Float = 0.8f,
    val enforcementPolicy: LimitEnforcementPolicy = LimitEnforcementPolicy.FOCUS,
    val autoExitConsentGranted: Boolean = true,
    val strictModeConsentGranted: Boolean = false,
    val exemptedApps: Set<String> = emptySet(),
    val focusScheduleEnabled: Boolean = false,
    val focusScheduleStartHour: Int = 22,
    val focusScheduleEndHour: Int = 6,
    val breakReminderEnabled: Boolean = true,
    val breakReminderInterval: Int = 25,
    val floatingCounterEnabled: Boolean = true,
    val floatingCounterSize: FloatingCounterSize = FloatingCounterSize.MEDIUM,
    val floatingCounterShowMascot: Boolean = true,
    val floatingCounterAnimation: Boolean = true,
    val reducedMotion: Boolean = false,
    val isTrackingEnabled: Boolean = true,
    val selectedApps: Set<String> = emptySet(),
    val notificationsEnabled: Boolean = true,
    val aiCloudEnabled: Boolean = false,
    val aiCloudConsent: Boolean = false,
    val isAccessibilityGranted: Boolean = false,
    val isOverlayGranted: Boolean = false,
    val isUsageAccessGranted: Boolean = false,
    val isNotificationGranted: Boolean = false,
    val diagnosticReport: String? = null,
    val exportSuccessMessage: String? = null,
    val dataClearedMessage: String? = null
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferencesRepository: PreferencesRepositoryImpl,
    private val statsRepository: StatsRepositoryImpl,
    private val hardLimitManager: HardLimitManager,
    private val trackingStateMachine: TrackingStateMachine,
    private val database: PrataDatabase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        loadSettings()
        checkPermissions()
    }

    fun checkPermissions() {
        val hasAccess = PermissionUtils.isAccessibilityServiceEnabled(context) || ScrollAccessibilityService.isRunning
        val hasOverlay = PermissionUtils.isOverlayPermissionGranted(context) || hasAccess
        val hasUsage = PermissionUtils.isUsageStatsPermissionGranted(context)
        val hasNotif = PermissionUtils.isNotificationPermissionGranted(context)

        _uiState.update {
            it.copy(
                isAccessibilityGranted = hasAccess,
                isOverlayGranted = hasOverlay,
                isUsageAccessGranted = hasUsage,
                isNotificationGranted = hasNotif
            )
        }
    }

    private fun loadSettings() {
        val today = DateUtils.today()
        viewModelScope.launch {
            val limit = statsRepository.getOrCreateDailyLimit(today).totalLimit
            _uiState.update { it.copy(dailyLimit = limit) }
        }

        viewModelScope.launch {
            preferencesRepository.observeGoals().collectLatest { goals ->
                val map = hardLimitManager.parsePerAppLimits(goals.perAppLimits)
                _uiState.update { it.copy(perAppLimits = map) }
            }
        }

        viewModelScope.launch {
            combine(
                preferencesRepository.trackingEnabled,
                preferencesRepository.selectedApps,
                preferencesRepository.exemptedApps,
                preferencesRepository.autoExitConsentGranted,
                preferencesRepository.strictModeConsentGranted
            ) { tracking, apps, exempted, autoExit, strictConsent ->
                Quintuple(tracking, apps, exempted, autoExit, strictConsent)
            }.collectLatest { (tracking, apps, exempted, autoExit, strictConsent) ->
                val effectiveApps = if (apps.isEmpty()) Constants.PRIMARY_SELECTABLE_APPS.keys else apps
                _uiState.update {
                    it.copy(
                        isTrackingEnabled = tracking,
                        selectedApps = effectiveApps,
                        exemptedApps = exempted,
                        autoExitConsentGranted = autoExit,
                        strictModeConsentGranted = strictConsent
                    )
                }
            }
        }

        viewModelScope.launch {
            combine(
                preferencesRepository.notificationsEnabled,
                preferencesRepository.aiCloudEnabled,
                preferencesRepository.aiCloudConsent
            ) { notifs, cloud, consent -> Triple(notifs, cloud, consent) }
                .collectLatest { (notifs, cloud, consent) ->
                    _uiState.update {
                        it.copy(
                            notificationsEnabled = notifs,
                            aiCloudEnabled = cloud,
                            aiCloudConsent = consent
                        )
                    }
                }
        }

        viewModelScope.launch {
            combine(
                preferencesRepository.limitEnforcementPolicy,
                preferencesRepository.warningThresholdPercent,
                preferencesRepository.dailyDurationLimitMinutes,
                preferencesRepository.focusScheduleEnabled,
                combine(preferencesRepository.focusScheduleStartHour, preferencesRepository.focusScheduleEndHour) { s, e -> Pair(s, e) }
            ) { policyStr, warnPct, durMins, schedEnabled, schedHours ->
                Quintuple(policyStr, warnPct, durMins, schedEnabled, schedHours)
            }.collectLatest { (policyStr, warnPct, durMins, schedEnabled, schedHours) ->
                _uiState.update {
                    it.copy(
                        enforcementPolicy = LimitEnforcementPolicy.fromKey(policyStr),
                        warningThresholdPercent = warnPct,
                        dailyDurationLimitMinutes = durMins,
                        focusScheduleEnabled = schedEnabled,
                        focusScheduleStartHour = schedHours.first,
                        focusScheduleEndHour = schedHours.second
                    )
                }
            }
        }

        viewModelScope.launch {
            combine(
                preferencesRepository.breakReminderEnabled,
                preferencesRepository.breakReminderInterval,
                preferencesRepository.floatingCounterEnabled,
                preferencesRepository.floatingCounterSize,
                combine(
                    preferencesRepository.floatingCounterShowMascot,
                    preferencesRepository.floatingCounterAnimation,
                    preferencesRepository.reducedMotion
                ) { mascot, anim, reduced -> Triple(mascot, anim, reduced) }
            ) { brkEnabled, brkInt, fltEnabled, fltSize, fltVisuals ->
                Quintuple(brkEnabled, brkInt, fltEnabled, fltSize, fltVisuals)
            }.collectLatest { (brkEnabled, brkInt, fltEnabled, fltSize, fltVisuals) ->
                _uiState.update {
                    it.copy(
                        breakReminderEnabled = brkEnabled,
                        breakReminderInterval = brkInt,
                        floatingCounterEnabled = fltEnabled,
                        floatingCounterSize = FloatingCounterSize.fromKey(fltSize),
                        floatingCounterShowMascot = fltVisuals.first,
                        floatingCounterAnimation = fltVisuals.second,
                        reducedMotion = fltVisuals.third
                    )
                }
            }
        }
    }

    fun updateDailyLimit(newLimit: Int) {
        val today = DateUtils.today()
        viewModelScope.launch {
            statsRepository.updateDailyLimit(today, newLimit)
            preferencesRepository.updateDailyLimit(newLimit)
            _uiState.update { it.copy(dailyLimit = newLimit) }
        }
    }

    fun updatePerAppLimit(packageName: String, limit: Int) {
        viewModelScope.launch {
            val updated = _uiState.value.perAppLimits.toMutableMap()
            if (limit <= 0) {
                updated.remove(packageName)
            } else {
                updated[packageName] = limit
            }
            val json = hardLimitManager.serializePerAppLimits(updated)
            preferencesRepository.updatePerAppLimits(json)
            _uiState.update { it.copy(perAppLimits = updated) }
        }
    }

    fun updateEnforcementPolicy(policy: LimitEnforcementPolicy) {
        viewModelScope.launch {
            preferencesRepository.setLimitEnforcementPolicy(policy.key)
            if (policy == LimitEnforcementPolicy.STRICT) {
                preferencesRepository.setStrictModeConsentGranted(true)
                preferencesRepository.setAutoExitConsentGranted(true)
            }
            _uiState.update { it.copy(enforcementPolicy = policy) }
        }
    }

    fun setAutoExitConsent(granted: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setAutoExitConsentGranted(granted)
        }
    }

    fun toggleExemptedApp(packageName: String) {
        viewModelScope.launch {
            preferencesRepository.toggleExemptedApp(packageName)
        }
    }

    fun updateWarningThreshold(percent: Float) {
        viewModelScope.launch {
            preferencesRepository.setWarningThresholdPercent(percent)
            _uiState.update { it.copy(warningThresholdPercent = percent) }
        }
    }

    fun updateDurationLimitMinutes(minutes: Int) {
        viewModelScope.launch {
            preferencesRepository.setDailyDurationLimitMinutes(minutes)
            _uiState.update { it.copy(dailyDurationLimitMinutes = minutes) }
        }
    }

    fun updateFocusSchedule(enabled: Boolean, startHour: Int, endHour: Int) {
        viewModelScope.launch {
            preferencesRepository.setFocusSchedule(enabled, startHour, endHour)
        }
    }

    fun updateBreakReminder(enabled: Boolean, intervalCount: Int) {
        viewModelScope.launch {
            preferencesRepository.setBreakReminder(enabled, intervalCount)
        }
    }

    fun setFloatingCounterEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setFloatingCounterEnabled(enabled)
        }
    }

    fun setFloatingCounterSize(size: FloatingCounterSize) {
        viewModelScope.launch {
            preferencesRepository.setFloatingCounterSize(size.key)
        }
    }

    fun setFloatingCounterShowMascot(show: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setFloatingCounterShowMascot(show)
        }
    }

    fun setFloatingCounterAnimation(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setFloatingCounterAnimation(enabled)
        }
    }

    fun resetFloatingCounterPosition() {
        viewModelScope.launch {
            preferencesRepository.setFloatingCounterPosition(24, 220)
            _uiState.update {
                it.copy(exportSuccessMessage = "Posisi Floating Counter berhasil direset ke pojok kiri atas.")
            }
        }
    }

    fun setReducedMotion(reduced: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setReducedMotion(reduced)
        }
    }

    fun toggleAppSelection(packageName: String) {
        viewModelScope.launch {
            val current = _uiState.value.selectedApps.toMutableSet()
            if (current.contains(packageName)) {
                current.remove(packageName)
                preferencesRepository.removeSelectedApp(packageName)
            } else {
                current.add(packageName)
                preferencesRepository.addSelectedApp(packageName)
            }
            _uiState.update { it.copy(selectedApps = current) }
        }
    }

    fun toggleTracking(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setTrackingEnabled(enabled)
            if (enabled) {
                try { MonitoringService.start(context) } catch (_: Exception) {}
            } else {
                try { MonitoringService.stop(context) } catch (_: Exception) {}
            }
        }
    }

    fun setAiCloudEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setAiCloudEnabled(enabled)
            preferencesRepository.setAiCloudConsent(enabled)
        }
    }

    fun runServiceDiagnostics() {
        checkPermissions()
        val snap = trackingStateMachine.snapshot.value
        val accessConfigured = PermissionUtils.isAccessibilityServiceEnabled(context)
        val serviceRunning = ScrollAccessibilityService.isRunning
        val overlayGranted = PermissionUtils.isOverlayPermissionGranted(context) || accessConfigured

        val report = buildString {
            appendLine("🔍 HASIL DIAGNOSTIK SISTEM PRATA:")
            appendLine("• Status State Machine: ${snap.systemState}")
            appendLine("• Status Deduplikasi: ${snap.dedupState}")
            appendLine("• Izin Accessibility Sistem: ${if (accessConfigured) "AKTIF ✅" else "BELUM AKTIF ❌"}")
            appendLine("• Koneksi Service Instance: ${if (serviceRunning) "TERHUBUNG ✅" else "MENUNGGU / SIAGA ⚠️"}")
            appendLine("• Kapabilitas Floating Overlay: ${if (overlayGranted) "SIAP (TYPE_ACCESSIBILITY_OVERLAY) ✅" else "PERLU IZIN ❌"}")
            appendLine("• Mode Pembatasan Aktif: ${snap.enforcementPolicy.title}")
            appendLine("• Izin Keluar Otomatis (GLOBAL_ACTION_HOME): ${if (_uiState.value.autoExitConsentGranted) "DIIZINKAN ✅" else "NONAKTIF"}")
            appendLine("• Sinkronisasi Hitungan Hari Ini: ${snap.todayShortCount} / ${snap.dailyLimit} konten")
        }.trim()

        _uiState.update { it.copy(diagnosticReport = report) }
    }

    fun exportData(format: String) {
        val req = OneTimeWorkRequestBuilder<DataExportWorker>()
            .setInputData(workDataOf(DataExportWorker.KEY_FORMAT to format))
            .build()
        WorkManager.getInstance(context).enqueue(req)
        val label = when (format.uppercase()) {
            "PDF" -> "Laporan PDF sedang dibuat di folder files/exports/ aplikasi."
            "BACKUP" -> "Cadangan Backup JSON lengkap berhasil disimpan di perangkat."
            else -> "Data berhasil diekspor dalam format $format ke folder files/exports/."
        }
        _uiState.update { it.copy(exportSuccessMessage = label) }
    }

    fun restoreFromLatestBackup() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val exportDir = File(context.filesDir, "exports")
                val backupFile = File(exportDir, "prata_braincare_backup_latest.json")
                    .takeIf { it.exists() }
                    ?: exportDir.listFiles()?.filter { it.name.endsWith(".json") }?.maxByOrNull { it.lastModified() }

                if (backupFile == null || !backupFile.exists()) {
                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(exportSuccessMessage = "Belum ada file Backup JSON ditemukan. Tekan 'Backup Data' terlebih dahulu.")
                        }
                    }
                    return@launch
                }

                val json = JSONObject(backupFile.readText())
                val goalsObj = json.optJSONObject("userGoals")
                if (goalsObj != null) {
                    val limit = goalsObj.optInt("dailyLimit", 100)
                    val perApp = goalsObj.optString("perAppLimits", "{}")
                    preferencesRepository.updateDailyLimit(limit)
                    preferencesRepository.updatePerAppLimits(perApp)
                    statsRepository.updateDailyLimit(DateUtils.today(), limit)
                }

                val statsArray = json.optJSONArray("dailyStats")
                var restoredCount = 0
                if (statsArray != null) {
                    for (i in 0 until statsArray.length()) {
                        val item = statsArray.getJSONObject(i)
                        val date = item.optString("date")
                        if (date.isNotBlank()) {
                            val existing = statsRepository.getOrCreateDailyStats(date)
                            statsRepository.updateDailyStats(
                                existing.copy(
                                    totalShortContent = item.optInt("totalShortContent", existing.totalShortContent),
                                    totalUsageMs = item.optLong("totalUsageMs", existing.totalUsageMs),
                                    totalSessions = item.optInt("totalSessions", existing.totalSessions),
                                    focusMinutes = item.optInt("focusMinutes", existing.focusMinutes),
                                    streakDay = item.optInt("streakDay", existing.streakDay),
                                    limitReached = item.optBoolean("limitReached", existing.limitReached),
                                    limitValue = item.optInt("limitValue", 100)
                                )
                            )
                            restoredCount++
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    loadSettings()
                    _uiState.update {
                        it.copy(exportSuccessMessage = "Restore berhasil! Dipulihkan $restoredCount catatan harian dari ${backupFile.name}.")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(exportSuccessMessage = "Gagal memulihkan cadangan: ${e.localizedMessage}")
                    }
                }
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch(Dispatchers.IO) {
            database.clearAllTables()
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(dataClearedMessage = "Seluruh riwayat dan data lokal berhasil dihapus.")
                }
                loadSettings()
            }
        }
    }

    fun dismissMessages() {
        _uiState.update {
            it.copy(
                exportSuccessMessage = null,
                dataClearedMessage = null,
                diagnosticReport = null
            )
        }
    }

    private data class Quintuple<A, B, C, D, E>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D,
        val fifth: E
    )
}
