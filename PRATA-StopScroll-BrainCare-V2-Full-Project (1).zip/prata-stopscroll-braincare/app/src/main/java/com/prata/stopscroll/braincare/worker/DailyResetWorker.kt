package com.prata.stopscroll.braincare.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.prata.stopscroll.braincare.di.ServiceEntryPoint
import com.prata.stopscroll.braincare.util.DateUtils
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.flow.firstOrNull

/**
 * Timezone-aware daily reset worker (Requirement G).
 * Finalizes yesterday's statistics and challenge streaks without deleting historical records,
 * resets temporary override flags, and initializes today's limit record.
 */
class DailyResetWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val entryPoint = EntryPointAccessors.fromApplication(
                applicationContext,
                ServiceEntryPoint::class.java
            )

            val statsRepo = entryPoint.statsRepository()
            val usageRepo = entryPoint.usageRepository()
            val challengeRepo = entryPoint.challengeRepository()
            val prefsRepo = entryPoint.preferencesRepository()
            val behaviorAnalyzer = entryPoint.behaviorAnalyzer()

            val yesterday = DateUtils.daysAgo(1)
            val today = DateUtils.today()

            // 1. Finalize yesterday's daily statistics from authoritative detections table
            val yesterdayCount = usageRepo.getShortContentCountForDate(yesterday)
            val yesterdayDuration = usageRepo.getTotalDurationByDate(yesterday).firstOrNull() ?: 0L
            val yesterdaySessions = usageRepo.getSessionCountByDate(yesterday).firstOrNull() ?: 0
            val yesterdayLimit = statsRepo.getOrCreateDailyLimit(yesterday)
            val yesterdayStats = statsRepo.getOrCreateDailyStats(yesterday)

            val limitMet = yesterdayCount <= yesterdayLimit.totalLimit
            val prevStreak = statsRepo.getDailyStatsRange(DateUtils.daysAgo(2), DateUtils.daysAgo(2))
                .firstOrNull()?.firstOrNull()?.streakDay ?: 0
            val newDailyStreak = if (limitMet) prevStreak + 1 else 0

            statsRepo.updateDailyStats(
                yesterdayStats.copy(
                    totalShortContent = yesterdayCount,
                    totalUsageMs = maxOf(yesterdayStats.totalUsageMs, yesterdayDuration),
                    totalSessions = maxOf(yesterdayStats.totalSessions, yesterdaySessions),
                    limitReached = yesterdayCount >= yesterdayLimit.totalLimit,
                    limitValue = yesterdayLimit.totalLimit,
                    streakDay = newDailyStreak
                )
            )

            // 2. Update active challenge progress
            val activeChallenge = challengeRepo.getActiveChallenge()
            if (activeChallenge != null) {
                val challengeLimitMet = yesterdayCount <= activeChallenge.targetDailyLimit
                if (challengeLimitMet) {
                    challengeRepo.recordDayCompleted(activeChallenge.id)
                } else {
                    challengeRepo.recordDayFailed(activeChallenge.id)
                }
            }

            // 3. Clear any temporary snooze from yesterday and initialize today's daily limit & stats
            prefsRepo.setSnoozeUntilTimestampMs(0L)
            val configuredGoalLimit = prefsRepo.getOrCreateGoals().dailyLimit
            val todayLimit = statsRepo.getOrCreateDailyLimit(today, configuredGoalLimit)
            val todayActualCount = usageRepo.getShortContentCountForDate(today)
            statsRepo.setDailyCount(today, todayActualCount)
            statsRepo.getOrCreateDailyStats(today)

            // 4. Sync state machine for the new day
            entryPoint.trackingStateMachine().syncLimitsAndCounts(
                todayShortCount = todayActualCount,
                dailyLimit = todayLimit.totalLimit,
                userOverrodeToday = false
            )

            // 5. Run insight generation & cleanup records older than retention window
            behaviorAnalyzer.analyzeAndGenerateInsights()
            val retentionDays = prefsRepo.dataRetentionDays.firstOrNull() ?: 90
            statsRepo.cleanupOldData(retentionDays)
            usageRepo.cleanupOldData(retentionDays)

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
