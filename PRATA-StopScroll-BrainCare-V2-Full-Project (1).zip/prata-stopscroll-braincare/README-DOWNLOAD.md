# PRATA StopScroll BrainCare V2

**Nama Aplikasi**: PRATA StopScroll BrainCare  
**Package Name**: `com.prata.stopscroll.braincare`  
**Versi**: `2.0.0` (`versionCode = 2`)  
**Teknologi**: Kotlin 2.0.21, Jetpack Compose (BOM 2024.12.01), Material 3, Room 2.6.1, DataStore 1.1.1, Hilt 2.51.1, WorkManager 2.10.0, AccessibilityService

## 1. Membangun APK V2 melalui GitHub Actions (`.github/workflows/build-apk.yml`)
Proyek ini telah dilengkapi workflow CI/CD siap pakai di `.github/workflows/build-apk.yml` yang mengunduh dependency melalui jaringan runner GitHub, menjalankan seluruh unit test (`testDebugUnitTest`), membangun `assembleDebug`, dan mengunggah artifact **`PRATA-StopScroll-BrainCare-APK`**.

### Langkah Menjalankan di GitHub:
1. Buat repository baru di GitHub (atau gunakan repository proyek Anda).
2. Di dalam folder `prata-stopscroll-braincare`, hubungkan dan kirim commit V2 ke branch `main`:
   ```bash
   git remote add origin https://github.com/<username>/<repo>.git
   git branch -M main
   git push -u origin main
   ```
3. Buka tab **Actions** pada repository GitHub Anda:
   - Workflow **Build PRATA StopScroll BrainCare V2 APK** akan langsung berjalan otomatis saat push ke `main`, atau dapat dipicu manual dengan mengeklik **Run workflow** (`workflow_dispatch`).
4. Setelah workflow berstatus hijau (**Success**), gulir ke bagian **Artifacts** di halaman ringkasan workflow run tersebut, lalu unduh:
   - **`PRATA-StopScroll-BrainCare-APK`** (berisi `prata-stopscroll-braincare-debug.apk` hasil kompilasi source code V2 terbaru)
   - **`PRATA-StopScroll-BrainCare-Test-Reports`** (berisi laporan HTML & XML hasil pengujian unit test)

## 2. Membangun APK Secara Lokal (Android Studio / CLI)
Jika Anda memiliki **JDK 17** dan **Android SDK (Platform 35, Build-Tools 35.0.0)** di komputer lokal dengan koneksi internet:
- **Linux / macOS**:
  ```bash
  chmod +x gradlew
  ./gradlew testDebugUnitTest assembleDebug
  ```
- **Windows**:
  ```bat
  gradlew.bat testDebugUnitTest assembleDebug
  ```
Hasil APK akan otomatis tersedia di:
`app/build/outputs/apk/debug/prata-stopscroll-braincare-debug.apk` (dan `app/build/outputs/apk/debug/app-debug.apk`).
